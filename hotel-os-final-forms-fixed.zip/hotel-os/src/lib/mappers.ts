// ── Supabase row ⇄ domain model mapping ──────────────────────
// Centralized snake_case ↔ camelCase conversion. UI components
// never see database field names.

import type {
  Guest,
  Hotel,
  HotelService,
  HousekeepingTask,
  LocalizedText,
  Payment,
  Profile,
  Reservation,
  ReservationService,
  Room,
  RoomStatusHistory,
  RoomType,
  UUID,
} from '@/types';

type Row = Record<string, unknown>;

const s = (v: unknown): string => (v == null ? '' : String(v));
const sn = (v: unknown): string | null => (v == null ? null : String(v));
const n = (v: unknown): number => (v == null ? 0 : Number(v));
const b = (v: unknown): boolean => v === true;

function loc(v: unknown, fallback = ''): LocalizedText {
  if (v && typeof v === 'object') {
    const o = v as Record<string, unknown>;
    return { fr: s(o.fr ?? fallback), ar: s(o.ar ?? fallback), en: s(o.en ?? fallback) };
  }
  return { fr: fallback, ar: fallback, en: fallback };
}

/** Deterministic avatar color derived from a user id (no DB column needed). */
function colorFromId(id: string): string {
  const palette = ['#0f766e', '#7c3aed', '#b45309', '#0369a1', '#be185d', '#15803d'];
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return palette[h % palette.length];
}

export function mapHotel(r: Row): Hotel {
  return {
    id: s(r.id),
    name: s(r.name),
    slug: s(r.slug),
    logoUrl: sn(r.logo_url),
    coverUrl: sn(r.cover_url),
    address: s(r.address),
    city: s(r.city),
    country: s(r.country),
    phone: s(r.phone),
    email: s(r.email),
    currency: s(r.currency) || 'MAD',
    timezone: s(r.timezone) || 'Africa/Casablanca',
    defaultLanguage: (s(r.default_language) || 'fr') as Hotel['defaultLanguage'],
    enabledLanguages: Array.isArray(r.enabled_languages) && r.enabled_languages.length
      ? (r.enabled_languages as Hotel['enabledLanguages'])
      : ['fr', 'ar', 'en'],
    checkInTime: s(r.check_in_time) || '15:00',
    checkOutTime: s(r.check_out_time) || '12:00',
    createdAt: s(r.created_at),
  };
}

export function hotelUpdatePayload(patch: Partial<Omit<Hotel, 'id'>>): Row {
  const p: Row = {};
  if (patch.name !== undefined) p.name = patch.name;
  if (patch.slug !== undefined) p.slug = patch.slug;
  if (patch.logoUrl !== undefined) p.logo_url = patch.logoUrl;
  if (patch.coverUrl !== undefined) p.cover_url = patch.coverUrl;
  if (patch.address !== undefined) p.address = patch.address;
  if (patch.city !== undefined) p.city = patch.city;
  if (patch.country !== undefined) p.country = patch.country;
  if (patch.phone !== undefined) p.phone = patch.phone;
  if (patch.email !== undefined) p.email = patch.email;
  if (patch.currency !== undefined) p.currency = patch.currency;
  if (patch.timezone !== undefined) p.timezone = patch.timezone;
  if (patch.defaultLanguage !== undefined) p.default_language = patch.defaultLanguage;
  if (patch.enabledLanguages !== undefined) p.enabled_languages = patch.enabledLanguages;
  if (patch.checkInTime !== undefined) p.check_in_time = patch.checkInTime;
  if (patch.checkOutTime !== undefined) p.check_out_time = patch.checkOutTime;
  return p;
}

export function mapProfile(r: Row): Profile {
  const id = s(r.id);
  const email = s(r.email);
  const [fallbackFirst, fallbackLast] = email.split('@')[0].split(/[._-]/);
  return {
    id,
    hotelId: s(r.hotel_id),
    email,
    firstName: s(r.first_name) || fallbackFirst || 'User',
    lastName: s(r.last_name) || fallbackLast || '',
    role: (s(r.role) || 'receptionist') as Profile['role'],
    active: r.active === undefined ? true : b(r.active),
    avatarColor: s(r.avatar_color) || colorFromId(id),
    createdAt: s(r.created_at),
  };
}

export function profileInsertPayload(hotelId: UUID, data: Omit<Profile, 'id' | 'hotelId' | 'createdAt'>): Row {
  return {
    hotel_id: hotelId,
    email: data.email,
    first_name: data.firstName,
    last_name: data.lastName,
    role: data.role,
    active: data.active,
    avatar_color: data.avatarColor,
  };
}

export function profileUpdatePayload(patch: Partial<Omit<Profile, 'id' | 'hotelId'>>): Row {
  const p: Row = {};
  if (patch.email !== undefined) p.email = patch.email;
  if (patch.firstName !== undefined) p.first_name = patch.firstName;
  if (patch.lastName !== undefined) p.last_name = patch.lastName;
  if (patch.role !== undefined) p.role = patch.role;
  if (patch.active !== undefined) p.active = patch.active;
  if (patch.avatarColor !== undefined) p.avatar_color = patch.avatarColor;
  return p;
}

export function mapRoomType(r: Row): RoomType {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    name: loc(r.name),
    description: loc(r.description),
    basePrice: n(r.base_price),
    maxGuests: n(r.max_guests),
    beds: Array.isArray(r.beds) ? (r.beds as RoomType['beds']) : [],
    size: n(r.size),
    amenities: Array.isArray(r.amenities) ? (r.amenities as string[]) : [],
    images: Array.isArray(r.images) ? (r.images as string[]) : [],
    active: r.active === undefined ? true : b(r.active),
    createdAt: s(r.created_at),
  };
}

export function roomTypePayload(data: {
  name: LocalizedText; description: LocalizedText; basePrice: number; maxGuests: number;
  beds: RoomType['beds']; size: number; amenities: string[]; images: string[]; active: boolean;
}): Row {
  return {
    name: data.name,
    description: data.description,
    base_price: data.basePrice,
    max_guests: data.maxGuests,
    beds: data.beds,
    size: data.size,
    amenities: data.amenities,
    images: data.images,
    active: data.active,
  };
}

export function roomTypePatch(patch: Partial<Omit<RoomType, 'id' | 'hotelId'>>): Row {
  const src = patch as Row;
  const p: Row = {};
  if (src.name !== undefined) p.name = src.name;
  if (src.description !== undefined) p.description = src.description;
  if (src.basePrice !== undefined) p.base_price = src.basePrice;
  if (src.maxGuests !== undefined) p.max_guests = src.maxGuests;
  if (src.beds !== undefined) p.beds = src.beds;
  if (src.size !== undefined) p.size = src.size;
  if (src.amenities !== undefined) p.amenities = src.amenities;
  if (src.images !== undefined) p.images = src.images;
  if (src.active !== undefined) p.active = src.active;
  return p;
}

export function mapRoom(r: Row): Room {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    // The deployed schema names the column room_number; accept both.
    number: s(r.room_number ?? r.number),
    roomTypeId: s(r.room_type_id),
    floor: n(r.floor),
    status: (s(r.status) || 'available') as Room['status'],
    notes: s(r.notes),
    createdAt: s(r.created_at),
  };
}

export function mapGuest(r: Row): Guest {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    firstName: s(r.first_name),
    lastName: s(r.last_name),
    email: s(r.email),
    phone: s(r.phone),
    nationality: s(r.nationality),
    documentType: (s(r.document_type) || 'passport') as Guest['documentType'],
    documentNumber: s(r.document_number),
    dateOfBirth: sn(r.date_of_birth),
    notes: s(r.notes),
    createdAt: s(r.created_at),
  };
}

export function guestPayload(data: Omit<Guest, 'id' | 'hotelId' | 'createdAt'>): Row {
  return {
    first_name: data.firstName,
    last_name: data.lastName,
    email: data.email,
    phone: data.phone,
    nationality: data.nationality,
    document_type: data.documentType,
    document_number: data.documentNumber,
    date_of_birth: data.dateOfBirth,
    notes: data.notes,
  };
}

export function mapReservation(r: Row): Reservation {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    reference: s(r.booking_reference ?? r.reference),
    guestId: s(r.guest_id),
    roomId: s(r.room_id),
    checkIn: s(r.check_in).slice(0, 10),
    checkOut: s(r.check_out).slice(0, 10),
    adults: n(r.adults),
    children: n(r.children),
    status: (s(r.status) || 'pending') as Reservation['status'],
    source: (s(r.source) || 'direct') as Reservation['source'],
    totalAmount: n(r.total_amount),
    paidAmount: n(r.paid_amount),
    currency: s(r.currency) || 'MAD',
    specialRequests: s(r.special_requests),
    createdAt: s(r.created_at),
    updatedAt: s(r.updated_at),
  };
}

export function reservationInsertPayload(
  hotelId: UUID,
  data: Omit<Reservation, 'id' | 'hotelId' | 'createdAt' | 'updatedAt' | 'reference'>,
  reference: string,
): Row {
  return {
    hotel_id: hotelId,
    booking_reference: reference,
    guest_id: data.guestId,
    room_id: data.roomId,
    check_in: data.checkIn,
    check_out: data.checkOut,
    adults: data.adults,
    children: data.children,
    status: data.status,
    source: data.source,
    total_amount: data.totalAmount,
    paid_amount: data.paidAmount,
    currency: data.currency,
    special_requests: data.specialRequests,
  };
}

export function reservationPatch(patch: Partial<Omit<Reservation, 'id' | 'hotelId'>>): Row {
  const src = patch as Row;
  const p: Row = {};
  if (src.guestId !== undefined) p.guest_id = src.guestId;
  if (src.roomId !== undefined) p.room_id = src.roomId;
  if (src.checkIn !== undefined) p.check_in = src.checkIn;
  if (src.checkOut !== undefined) p.check_out = src.checkOut;
  if (src.adults !== undefined) p.adults = src.adults;
  if (src.children !== undefined) p.children = src.children;
  if (src.status !== undefined) p.status = src.status;
  if (src.source !== undefined) p.source = src.source;
  if (src.totalAmount !== undefined) p.total_amount = src.totalAmount;
  if (src.paidAmount !== undefined) p.paid_amount = src.paidAmount;
  if (src.currency !== undefined) p.currency = src.currency;
  if (src.specialRequests !== undefined) p.special_requests = src.specialRequests;
  p.updated_at = new Date().toISOString();
  return p;
}

export function mapPayment(r: Row): Payment {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    reservationId: s(r.reservation_id),
    amount: n(r.amount),
    method: (s(r.method) || 'card') as Payment['method'],
    status: (s(r.status) || 'pending') as Payment['status'],
    transactionReference: s(r.transaction_reference),
    notes: s(r.notes),
    paidAt: s(r.paid_at),
    createdAt: s(r.created_at),
  };
}

export function paymentPayload(
  hotelId: UUID,
  data: Omit<Payment, 'id' | 'hotelId' | 'createdAt'>,
): Row {
  return {
    hotel_id: hotelId,
    reservation_id: data.reservationId,
    amount: data.amount,
    method: data.method,
    status: data.status,
    transaction_reference: data.transactionReference,
    notes: data.notes,
    paid_at: data.paidAt,
  };
}

export function mapService(r: Row): HotelService {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    name: loc(r.name),
    description: loc(r.description),
    price: n(r.price),
    active: r.active === undefined ? true : b(r.active),
    createdAt: s(r.created_at),
  };
}

export function servicePayload(data: {
  name: LocalizedText; description: LocalizedText; price: number; active: boolean;
}): Row {
  return { name: data.name, description: data.description, price: data.price, active: data.active };
}

export function mapReservationService(r: Row): ReservationService {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    reservationId: s(r.reservation_id),
    serviceId: s(r.service_id),
    quantity: n(r.quantity),
    unitPrice: n(r.unit_price ?? r.price),
    notes: s(r.notes),
    createdAt: s(r.created_at),
  };
}

export function mapHousekeepingTask(r: Row): HousekeepingTask {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    roomId: s(r.room_id),
    assignedTo: sn(r.assigned_to),
    taskType: (s(r.task_type) || 'cleaning') as HousekeepingTask['taskType'],
    status: (s(r.status) || 'pending') as HousekeepingTask['status'],
    notes: s(r.notes),
    completedAt: sn(r.completed_at),
    createdAt: s(r.created_at),
  };
}

export function housekeepingPayload(data: Omit<HousekeepingTask, 'id' | 'hotelId' | 'createdAt'>): Row {
  return {
    room_id: data.roomId,
    assigned_to: data.assignedTo,
    task_type: data.taskType,
    status: data.status,
    notes: data.notes,
    completed_at: data.completedAt,
  };
}

export function mapRoomStatusHistory(r: Row): RoomStatusHistory {
  return {
    id: s(r.id),
    hotelId: s(r.hotel_id),
    roomId: s(r.room_id),
    fromStatus: sn(r.from_status) as RoomStatusHistory['fromStatus'],
    toStatus: (s(r.to_status) || 'available') as RoomStatusHistory['toStatus'],
    changedBy: sn(r.changed_by),
    reason: s(r.reason),
    changedAt: s(r.changed_at),
  };
}
