// ── Supabase repositories ─────────────────────────────────────
// Implementations of the repository interfaces backed by
// PostgREST (supabase-js). RLS is the security boundary: every
// query is scoped to the authenticated user's hotel via
// hotel_id filters, and the anon key never bypasses policies.

import type {
  Guest,
  Hotel,
  HotelService,
  HousekeepingTask,
  Payment,
  Profile,
  Reservation,
  ReservationFilters,
  ReservationService,
  Room,
  RoomFilters,
  RoomStatus,
  RoomStatusHistory,
  RoomType,
  UUID,
} from '@/types';
import { HotelError } from '@/types';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { guard } from '@/lib/errors';
import {
  guestPayload,
  hotelUpdatePayload,
  housekeepingPayload,
  mapGuest,
  mapHotel,
  mapHousekeepingTask,
  mapPayment,
  mapProfile,
  mapReservation,
  mapReservationService,
  mapRoom,
  mapRoomStatusHistory,
  mapRoomType,
  mapService,
  paymentPayload,
  profileInsertPayload,
  profileUpdatePayload,
  reservationInsertPayload,
  reservationPatch,
  roomTypePatch,
  roomTypePayload,
  servicePayload,
} from '@/lib/mappers';
import { bookingReference } from '@/utils/format';
import type {
  GuestRepository,
  HotelRepository,
  HousekeepingRepository,
  PaymentRepository,
  ReservationRepository,
  RoomRepository,
  RoomTypeRepository,
  ServiceRepository,
  UserRepository,
} from './interfaces';

function client() {
  if (!supabase || !isSupabaseConfigured) {
    throw new HotelError('supabase_not_configured');
  }
  return supabase;
}

async function fail(e: unknown): Promise<never> {
  await guard(Promise.reject(e));
  throw new HotelError('generic');
}

/* ── hotels ── */
export const supabaseHotelRepository: HotelRepository = {
  async list() {
    const { data, error } = await client().from('hotels').select('*').order('name');
    if (error) return fail(error);
    return (data ?? []).map(mapHotel);
  },
  async getById(id) {
    const { data, error } = await client().from('hotels').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapHotel(data) : null;
  },
  async getBySlug(slug) {
    const { data, error } = await client().from('hotels').select('*').eq('slug', slug).maybeSingle();
    if (error) return fail(error);
    return data ? mapHotel(data) : null;
  },
  async update(id, patch) {
    const { data, error } = await client()
      .from('hotels')
      .update(hotelUpdatePayload(patch))
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapHotel(data);
  },
};

/* ── room types ── */
export const supabaseRoomTypeRepository: RoomTypeRepository = {
  async list(hotelId) {
    const { data, error } = await client()
      .from('room_types')
      .select('*')
      .eq('hotel_id', hotelId)
      .order('base_price');
    if (error) return fail(error);
    return (data ?? []).map(mapRoomType);
  },
  async get(id) {
    const { data, error } = await client().from('room_types').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapRoomType(data) : null;
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('room_types')
      .insert({ hotel_id: hotelId, ...roomTypePayload(data) })
      .select()
      .single();
    if (error) return fail(error);
    return mapRoomType(row);
  },
  async update(id, patch) {
    const { data, error } = await client()
      .from('room_types')
      .update(roomTypePatch(patch))
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapRoomType(data);
  },
  async remove(id) {
    const { error } = await client().from('room_types').delete().eq('id', id);
    if (error) return fail(error);
  },
};

/* ── rooms ── */
export const supabaseRoomRepository: RoomRepository = {
  async list(hotelId, filters) {
    let q = client().from('rooms').select('*').eq('hotel_id', hotelId).order('number');
    if (filters) {
      const { search, floor, status, roomTypeId } = filters;
      if (search) q = q.or(`number.ilike.%${search}%,notes.ilike.%${search}%`);
      if (floor !== undefined && floor !== 'all') q = q.eq('floor', floor);
      if (status && status !== 'all') q = q.eq('status', status);
      if (roomTypeId && roomTypeId !== 'all') q = q.eq('room_type_id', roomTypeId);
    }
    const { data, error } = await q;
    if (error) return fail(error);
    return (data ?? []).map(mapRoom);
  },
  async get(id) {
    const { data, error } = await client().from('rooms').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapRoom(data) : null;
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('rooms')
      .insert({
        hotel_id: hotelId,
        room_number: data.number,
        room_type_id: data.roomTypeId,
        floor: data.floor,
        status: data.status,
        notes: data.notes,
      })
      .select()
      .single();
    if (error) return fail(error);
    return mapRoom(row);
  },
  async update(id, patch) {
    const src = patch as Record<string, unknown>;
    const p: Record<string, unknown> = {};
    if (src.number !== undefined) p.number = src.number;
    if (src.roomTypeId !== undefined) p.room_type_id = src.roomTypeId;
    if (src.floor !== undefined) p.floor = src.floor;
    if (src.status !== undefined) p.status = src.status;
    if (src.notes !== undefined) p.notes = src.notes;
    const { data, error } = await client().from('rooms').update(p).eq('id', id).select().single();
    if (error) return fail(error);
    return mapRoom(data);
  },
  async setStatus(id, status, changedBy, reason) {
    const sb = client();
    const { data: room, error: fetchError } = await sb.from('rooms').select('*').eq('id', id).single();
    if (fetchError) return fail(fetchError);
    const from = (room.status ?? null) as RoomStatus | null;

    const { data, error } = await sb.from('rooms').update({ status }).eq('id', id).select().single();
    if (error) return fail(error);

    // History is best-effort: never block a status change on it.
    await sb
      .from('room_status_history')
      .insert({
        hotel_id: room.hotel_id,
        room_id: id,
        from_status: from,
        to_status: status,
        changed_by: changedBy,
        reason,
      })
      .then(() => undefined, () => undefined);
    return mapRoom(data);
  },
  async remove(id) {
    const { error } = await client().from('rooms').delete().eq('id', id);
    if (error) return fail(error);
  },
  async statusHistory(roomId) {
    const { data, error } = await client()
      .from('room_status_history')
      .select('*')
      .eq('room_id', roomId)
      .order('changed_at', { ascending: false });
    if (error) return fail(error);
    return (data ?? []).map(mapRoomStatusHistory);
  },
};

/* ── guests ── */
export const supabaseGuestRepository: GuestRepository = {
  async list(hotelId, search) {
    let q = client().from('guests').select('*').eq('hotel_id', hotelId).order('last_name');
    if (search) {
      const term = `%${search}%`;
      q = q.or(`first_name.ilike.${term},last_name.ilike.${term},email.ilike.${term},phone.ilike.${term}`);
    }
    const { data, error } = await q;
    if (error) return fail(error);
    return (data ?? []).map(mapGuest);
  },
  async get(id) {
    const { data, error } = await client().from('guests').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapGuest(data) : null;
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('guests')
      .insert({ hotel_id: hotelId, ...guestPayload(data) })
      .select()
      .single();
    if (error) return fail(error);
    return mapGuest(row);
  },
  async update(id, patch) {
    const src = patch as Record<string, unknown>;
    const p: Record<string, unknown> = {};
    if (src.firstName !== undefined) p.first_name = src.firstName;
    if (src.lastName !== undefined) p.last_name = src.lastName;
    if (src.email !== undefined) p.email = src.email;
    if (src.phone !== undefined) p.phone = src.phone;
    if (src.nationality !== undefined) p.nationality = src.nationality;
    if (src.documentType !== undefined) p.document_type = src.documentType;
    if (src.documentNumber !== undefined) p.document_number = src.documentNumber;
    if (src.dateOfBirth !== undefined) p.date_of_birth = src.dateOfBirth;
    if (src.notes !== undefined) p.notes = src.notes;
    const { data, error } = await client().from('guests').update(p).eq('id', id).select().single();
    if (error) return fail(error);
    return mapGuest(data);
  },
};

/* ── reservations ── */
export const supabaseReservationRepository: ReservationRepository = {
  async list(hotelId, filters) {
    let q = client().from('reservations').select('*').eq('hotel_id', hotelId).order('check_in', { ascending: false });
    if (filters) {
      const { search, status, source, dateFrom, dateTo } = filters;
      if (status && status !== 'all') q = q.eq('status', status);
      if (source && source !== 'all') q = q.eq('source', source);
      if (dateFrom) q = q.gt('check_out', dateFrom);
      if (dateTo) q = q.lt('check_in', dateTo);
      if (search) {
        const term = `%${search}%`;
        const ids = new Set<string>();
        const { data: byRef } = await client()
          .from('reservations')
          .select('id')
          .eq('hotel_id', hotelId)
          .ilike('booking_reference', term);
        (byRef ?? []).forEach((r: { id: string }) => ids.add(r.id));
        const { data: matchedGuests } = await client()
          .from('guests')
          .select('id')
          .eq('hotel_id', hotelId)
          .or(`first_name.ilike.${term},last_name.ilike.${term}`);
        if (matchedGuests && matchedGuests.length) {
          const { data: byGuest } = await client()
            .from('reservations')
            .select('id')
            .eq('hotel_id', hotelId)
            .in('guest_id', matchedGuests.map((g: { id: string }) => g.id));
          (byGuest ?? []).forEach((r: { id: string }) => ids.add(r.id));
        }
        if (ids.size === 0) return [];
        q = q.in('id', [...ids]);
      }
    }
    const { data, error } = await q;
    if (error) return fail(error);
    return (data ?? []).map(mapReservation);
  },
  async get(id) {
    const { data, error } = await client().from('reservations').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapReservation(data) : null;
  },
  async create(hotelId, data) {
    const reference = bookingReference();
    const { data: row, error } = await client()
      .from('reservations')
      .insert(reservationInsertPayload(hotelId, data, reference))
      .select()
      .single();
    if (error) return fail(error);
    return mapReservation(row);
  },
  async update(id, patch) {
    const { data, error } = await client()
      .from('reservations')
      .update(reservationPatch(patch))
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapReservation(data);
  },
  async cancel(id) {
    const { data, error } = await client()
      .from('reservations')
      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapReservation(data);
  },
  async servicesOf(reservationId) {
    const { data, error } = await client()
      .from('reservation_services')
      .select('*')
      .eq('reservation_id', reservationId);
    if (error) return fail(error);
    return (data ?? []).map(mapReservationService);
  },
  async addService(hotelId, reservationId, serviceId, quantity, notes) {
    const { data: svc, error: svcError } = await client()
      .from('services')
      .select('price')
      .eq('id', serviceId)
      .single();
    if (svcError) return fail(svcError);
    const unitPrice = Number((svc as { price: number }).price ?? 0);
    const { data, error } = await client()
      .from('reservation_services')
      .insert({ hotel_id: hotelId, reservation_id: reservationId, service_id: serviceId, quantity, unit_price: unitPrice, notes })
      .select()
      .single();
    if (error) return fail(error);
    return mapReservationService(data);
  },
  async paymentsOf(reservationId) {
    const { data, error } = await client()
      .from('payments')
      .select('*')
      .eq('reservation_id', reservationId)
      .order('paid_at', { ascending: false });
    if (error) return fail(error);
    return (data ?? []).map(mapPayment);
  },
};

/* ── payments ── */
export const supabasePaymentRepository: PaymentRepository = {
  async list(hotelId, status) {
    let q = client().from('payments').select('*').eq('hotel_id', hotelId).order('paid_at', { ascending: false });
    if (status && status !== 'all') q = q.eq('status', status);
    const { data, error } = await q;
    if (error) return fail(error);
    return (data ?? []).map(mapPayment);
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('payments')
      .insert(paymentPayload(hotelId, data))
      .select()
      .single();
    if (error) return fail(error);
    return mapPayment(row);
  },
  async update(id, patch) {
    const src = patch as Record<string, unknown>;
    const p: Record<string, unknown> = {};
    if (src.amount !== undefined) p.amount = src.amount;
    if (src.method !== undefined) p.method = src.method;
    if (src.status !== undefined) p.status = src.status;
    if (src.transactionReference !== undefined) p.transaction_reference = src.transactionReference;
    if (src.notes !== undefined) p.notes = src.notes;
    if (src.paidAt !== undefined) p.paid_at = src.paidAt;
    const { data, error } = await client().from('payments').update(p).eq('id', id).select().single();
    if (error) return fail(error);
    return mapPayment(data);
  },
};

/* ── services ── */
export const supabaseServiceRepository: ServiceRepository = {
  async list(hotelId) {
    const { data, error } = await client().from('services').select('*').eq('hotel_id', hotelId).order('price');
    if (error) return fail(error);
    return (data ?? []).map(mapService);
  },
  async get(id) {
    const { data, error } = await client().from('services').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapService(data) : null;
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('services')
      .insert({ hotel_id: hotelId, ...servicePayload(data) })
      .select()
      .single();
    if (error) return fail(error);
    return mapService(row);
  },
  async update(id, patch) {
    const src = patch as Record<string, unknown>;
    const p: Record<string, unknown> = {};
    if (src.name !== undefined) p.name = src.name;
    if (src.description !== undefined) p.description = src.description;
    if (src.price !== undefined) p.price = src.price;
    if (src.active !== undefined) p.active = src.active;
    const { data, error } = await client().from('services').update(p).eq('id', id).select().single();
    if (error) return fail(error);
    return mapService(data);
  },
};

/* ── housekeeping ── */
export const supabaseHousekeepingRepository: HousekeepingRepository = {
  async list(hotelId) {
    const { data, error } = await client()
      .from('housekeeping_tasks')
      .select('*')
      .eq('hotel_id', hotelId)
      .order('created_at', { ascending: false });
    if (error) return fail(error);
    return (data ?? []).map(mapHousekeepingTask);
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('housekeeping_tasks')
      .insert({ hotel_id: hotelId, ...housekeepingPayload(data) })
      .select()
      .single();
    if (error) return fail(error);
    return mapHousekeepingTask(row);
  },
  async update(id, patch) {
    const src = patch as Record<string, unknown>;
    const p: Record<string, unknown> = {};
    if (src.roomId !== undefined) p.room_id = src.roomId;
    if (src.assignedTo !== undefined) p.assigned_to = src.assignedTo;
    if (src.taskType !== undefined) p.task_type = src.taskType;
    if (src.status !== undefined) {
      p.status = src.status;
      p.completed_at = src.status === 'completed' ? new Date().toISOString() : src.status ? null : undefined;
    }
    if (src.notes !== undefined) p.notes = src.notes;
    const { data, error } = await client()
      .from('housekeeping_tasks')
      .update(p)
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapHousekeepingTask(data);
  },
};

/* ── users / profiles ── */
export const supabaseUserRepository: UserRepository = {
  async list(hotelId) {
    const { data, error } = await client().from('profiles').select('*').eq('hotel_id', hotelId);
    if (error) return fail(error);
    return (data ?? []).map(mapProfile);
  },
  async getById(id) {
    const { data, error } = await client().from('profiles').select('*').eq('id', id).maybeSingle();
    if (error) return fail(error);
    return data ? mapProfile(data) : null;
  },
  async getByEmail(email) {
    const { data, error } = await client().from('profiles').select('*').eq('email', email).maybeSingle();
    if (error) return fail(error);
    return data ? mapProfile(data) : null;
  },
  async create(hotelId, data) {
    const { data: row, error } = await client()
      .from('profiles')
      .insert(profileInsertPayload(hotelId, data))
      .select()
      .single();
    if (error) return fail(error);
    return mapProfile(row);
  },
  async update(id, patch) {
    const { data, error } = await client()
      .from('profiles')
      .update(profileUpdatePayload(patch))
      .eq('id', id)
      .select()
      .single();
    if (error) return fail(error);
    return mapProfile(data);
  },
};
