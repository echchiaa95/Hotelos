import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { guestService, paymentService, reservationService, roomService, roomTypeService, serviceService } from '@/services';
import {
  Badge, Button, Card, ConfirmDialog, EmptyBlock, ErrorBlock, Field, LoadingBlock,
  Modal, useToast,
} from '@/components/ui';
import { IconEdit, IconEye, IconPlus, IconTrash } from '@/components/icons';
import { formatDate, formatMoney, formatDateTime, todayISO } from '@/utils/format';
import type { Reservation, ReservationSource, ReservationStatus } from '@/types';
import { HotelError } from '@/types';

const STATUSES: (ReservationStatus | 'all')[] = ['all', 'pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show'];
const SOURCES: (ReservationSource | 'all')[] = ['all', 'direct', 'booking_com', 'expedia', 'airbnb', 'phone', 'whatsapp', 'walk_in', 'other'];

interface FormState {
  guestId: string;
  roomId: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  status: ReservationStatus;
  source: ReservationSource;
  specialRequests: string;
}

export default function Reservations() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [params] = useSearchParams();
  const [search, setSearch] = useState(params.get('search') ?? '');
  const [status, setStatus] = useState<ReservationStatus | 'all'>('all');
  const [source, setSource] = useState<ReservationSource | 'all'>('all');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [editing, setEditing] = useState<Reservation | null | 'new'>(null);
  const [viewing, setViewing] = useState<Reservation | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Reservation | null>(null);

  const filters = useMemo(() => ({ search, status, source, dateFrom: from || undefined, dateTo: to || undefined }), [search, status, source, from, to]);
  const list = useAsync(() => (hotelId ? reservationService.list(hotelId, filters) : Promise.resolve([])), [hotelId, filters]);

  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const types = useAsync(() => (hotelId ? roomTypeService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const guestName = (id: string) => {
    const g = guests.data?.find((x) => x.id === id);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };
  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';

  const doCancel = useMutation(async (id: string) => {
    await reservationService.cancel(id);
  }, () => { toast.push('success', t('reservations.cancelled')); setCancelTarget(null); list.reload(); });

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('reservations.title')}</h1>
          <p className="sub">{list.data ? t('common.items', { count: list.data.length }) : ''}</p>
        </div>
        <div className="page-actions">
          <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('reservations.add')}</Button>
        </div>
      </div>

      <div className="toolbar">
        <input className="input" style={{ minWidth: 220 }} placeholder={t('common.searchPlaceholder')} value={search} onChange={(e) => setSearch(e.target.value)} aria-label={t('common.search')} />
        <select className="select" value={status} onChange={(e) => setStatus(e.target.value as never)} aria-label={t('common.status')}>
          {STATUSES.map((s) => <option key={s} value={s}>{s === 'all' ? t('common.allStatuses') : t(`statuses.reservation.${s}` as never)}</option>)}
        </select>
        <select className="select" value={source} onChange={(e) => setSource(e.target.value as never)} aria-label={t('reservations.source')}>
          {SOURCES.map((s) => <option key={s} value={s}>{s === 'all' ? t('common.all') : t(`sources.${s}` as never)}</option>)}
        </select>
        <input className="input" type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label={t('common.from')} />
        <input className="input" type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label={t('common.to')} />
      </div>

      <div className="chip-row">
        {STATUSES.map((s) => (
          <button key={s} className={`chip ${status === s ? 'active' : ''}`} onClick={() => setStatus(s)}>
            {s === 'all' ? t('common.all') : t(`statuses.reservation.${s}` as never)}
          </button>
        ))}
      </div>

      {list.status === 'loading' && <Card><LoadingBlock /></Card>}
      {list.status === 'error' && <Card><ErrorBlock code={list.error} onRetry={list.reload} /></Card>}
      {list.status === 'empty' && <Card><EmptyBlock title={t('common.noResults')} /></Card>}
      {list.status === 'success' && list.data && (
        <div className="mobile-cards" aria-label={t('reservations.title')}>
          {list.data.map((r) => (
            <div className="m-card" key={r.id}>
              <div className="row">
                <span className="main">{r.reference}</span>
                <Badge status={r.status} label={t(`statuses.reservation.${r.status}` as never)} />
              </div>
              <div className="sub">{guestName(r.guestId)} · {t('common.room')} {roomNumber(r.roomId)}</div>
              <div className="sub">{formatDate(r.checkIn, locale)} → {formatDate(r.checkOut, locale)} · {t(`sources.${r.source}` as never)}</div>
              <div className="row">
                <span className="money">{formatMoney(r.totalAmount, r.currency, locale)}</span>
                <span className="sub">{t('common.paid')}: {formatMoney(r.paidAmount, r.currency, locale)}</span>
              </div>
              <div className="actions">
                <Button size="sm" onClick={() => setViewing(r)}>{t('common.view')}</Button>
                <Button size="sm" onClick={() => setEditing(r)}>{t('common.edit')}</Button>
                {(r.status === 'pending' || r.status === 'confirmed') && (
                  <Button size="sm" variant="danger" onClick={() => setCancelTarget(r)}>{t('common.cancel')}</Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {list.status === 'success' && list.data && (
        <div className="table-wrap hide-mobile">
          <table className="table">
            <thead>
              <tr>
                <th>{t('reservations.reference')}</th>
                <th>{t('common.guest')}</th>
                <th>{t('common.room')}</th>
                <th>{t('reservations.checkIn')}</th>
                <th>{t('reservations.checkOut')}</th>
                <th>{t('reservations.source')}</th>
                <th>{t('common.amount')}</th>
                <th>{t('common.status')}</th>
                <th style={{ textAlign: 'end' }}>{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {list.data.map((r) => (
                <tr key={r.id}>
                  <td className="cell-main">{r.reference}</td>
                  <td>{guestName(r.guestId)}</td>
                  <td className="num">{roomNumber(r.roomId)}</td>
                  <td>{formatDate(r.checkIn, locale)}</td>
                  <td>{formatDate(r.checkOut, locale)}</td>
                  <td><span className="muted">{t(`sources.${r.source}` as never)}</span></td>
                  <td>
                    <div className="num">{formatMoney(r.totalAmount, r.currency, locale)}</div>
                    <div className="cell-sub">{t('common.paid')}: {formatMoney(r.paidAmount, r.currency, locale)}</div>
                  </td>
                  <td><Badge status={r.status} label={t(`statuses.reservation.${r.status}` as never)} /></td>
                  <td>
                    <div className="row-actions">
                      <Button size="sm" className="btn-icon" onClick={() => setViewing(r)} aria-label={t('common.view')}><IconEye /></Button>
                      <Button size="sm" className="btn-icon" onClick={() => setEditing(r)} aria-label={t('common.edit')}><IconEdit /></Button>
                      {(r.status === 'pending' || r.status === 'confirmed') && (
                        <Button size="sm" className="btn-icon" onClick={() => setCancelTarget(r)} aria-label={t('reservations.cancel')}><IconTrash /></Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing !== null && (
        <ReservationForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          guests={guests.data ?? []}
          rooms={rooms.data ?? []}
          types={types.data ?? []}
          currency={hotel?.currency ?? 'MAD'}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); list.reload(); }}
        />
      )}

      {viewing && (
        <ReservationDetail
          reservation={viewing}
          guestName={guestName(viewing.guestId)}
          roomNumber={roomNumber(viewing.roomId)}
          onClose={() => setViewing(null)}
        />
      )}

      {cancelTarget && (
        <ConfirmDialog
          title={t('reservations.cancel')}
          message={t('reservations.cancelConfirm')}
          danger
          onCancel={() => setCancelTarget(null)}
          onConfirm={() => doCancel.execute(cancelTarget.id)}
        />
      )}
    </div>
  );
}

/* ── Create / Edit form ── */
function ReservationForm({ hotelId, initial, guests, rooms, types, currency, onClose, onSaved }: {
  hotelId: string;
  initial: Reservation | null;
  guests: import('@/types').Guest[];
  rooms: import('@/types').Room[];
  types: import('@/types').RoomType[];
  currency: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t, locale } = useTranslation();
  const toast = useToast();
  const [f, setF] = useState<FormState>({
    guestId: initial?.guestId ?? '',
    roomId: initial?.roomId ?? '',
    checkIn: initial?.checkIn ?? todayISO(),
    checkOut: initial?.checkOut ?? '',
    adults: initial?.adults ?? 2,
    children: initial?.children ?? 0,
    status: initial?.status ?? 'confirmed',
    source: initial?.source ?? 'direct',
    specialRequests: initial?.specialRequests ?? '',
  });
  const [conflict, setConflict] = useState(false);
  const set = (k: keyof FormState, v: unknown) => setF((s) => ({ ...s, [k]: v }));

  const selectedRoom = rooms.find((r) => r.id === f.roomId);
  const roomType = types.find((x) => x.id === selectedRoom?.roomTypeId);
  const nights = f.checkIn && f.checkOut ? Math.max(0, Math.round((new Date(f.checkOut).getTime() - new Date(f.checkIn).getTime()) / 86400000)) : 0;
  const total = roomType ? roomType.basePrice * nights : 0;

  const save = useMutation(async () => {
    setConflict(false);
    const payload = {
      guestId: f.guestId, roomId: f.roomId, checkIn: f.checkIn, checkOut: f.checkOut,
      adults: f.adults, children: f.children, status: f.status, source: f.source,
      totalAmount: total, paidAmount: initial?.paidAmount ?? 0, currency,
      specialRequests: f.specialRequests,
    };
    try {
      if (initial) await reservationService.update(initial.id, payload);
      else await reservationService.create(hotelId, payload);
    } catch (e) {
      if (e instanceof HotelError && e.code === 'room_no_longer_available') {
        setConflict(true);
        throw e;
      }
      throw e;
    }
  }, () => {
    toast.push('success', t(initial ? 'reservations.updated' : 'reservations.created'));
    onSaved();
  });

  const valid = f.guestId && f.roomId && f.checkIn && f.checkOut && nights > 0;

  return (
    <Modal
      title={t(initial ? 'reservations.edit' : 'reservations.add')}
      wide
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" disabled={!valid} loading={save.pending} onClick={() => save.execute()}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="stack">
        {conflict && <div className="login-error" role="alert">{t('reservations.conflictDetected')}</div>}
        {save.error === 'room_no_longer_available' && !conflict && <div className="login-error" role="alert">{t('errors.roomNoLongerAvailable')}</div>}
        <div className="form-grid">
          <Field label={t('reservations.selectGuest')}>
            <select className="select" value={f.guestId} onChange={(e) => set('guestId', e.target.value)}>
              <option value="">—</option>
              {guests.map((g) => <option key={g.id} value={g.id}>{g.firstName} {g.lastName}</option>)}
            </select>
          </Field>
          <Field label={t('reservations.selectRoom')}>
            <select className="select" value={f.roomId} onChange={(e) => set('roomId', e.target.value)}>
              <option value="">—</option>
              {rooms.map((r) => {
                const type = types.find((x) => x.id === r.roomTypeId);
                return <option key={r.id} value={r.id}>{r.number} · {type?.name[locale]}</option>;
              })}
            </select>
          </Field>
          <Field label={t('reservations.checkIn')}>
            <input className="input" type="date" value={f.checkIn} onChange={(e) => set('checkIn', e.target.value)} />
          </Field>
          <Field label={t('reservations.checkOut')}>
            <input className="input" type="date" value={f.checkOut} min={f.checkIn} onChange={(e) => set('checkOut', e.target.value)} />
          </Field>
          <Field label={t('reservations.adults')}>
            <input className="input" type="number" min={1} value={f.adults} onChange={(e) => set('adults', Number(e.target.value))} />
          </Field>
          <Field label={t('reservations.children')}>
            <input className="input" type="number" min={0} value={f.children} onChange={(e) => set('children', Number(e.target.value))} />
          </Field>
          <Field label={t('common.status')}>
            <select className="select" value={f.status} onChange={(e) => set('status', e.target.value)}>
              {(['pending', 'confirmed', 'checked_in', 'checked_out', 'cancelled', 'no_show'] as const).map((s) => (
                <option key={s} value={s}>{t(`statuses.reservation.${s}` as never)}</option>
              ))}
            </select>
          </Field>
          <Field label={t('reservations.source')}>
            <select className="select" value={f.source} onChange={(e) => set('source', e.target.value)}>
              {SOURCES.filter((s) => s !== 'all').map((s) => (
                <option key={s} value={s}>{t(`sources.${s}` as never)}</option>
              ))}
            </select>
          </Field>
          <Field label={t('reservations.specialRequests')} full>
            <textarea className="textarea" value={f.specialRequests} onChange={(e) => set('specialRequests', e.target.value)} />
          </Field>
        </div>
        <div className="flex-between card" style={{ padding: '12px 16px', background: 'var(--surface-2)' }}>
          <span className="muted small">{roomType ? `${roomType.name[locale]} · ${nights} ${nights > 1 ? t('common.nights') : t('common.night')}` : '—'}</span>
          <span className="money">{formatMoney(total, currency, locale)}</span>
        </div>
      </div>
    </Modal>
  );
}

/* ── View detail with services/payments ── */
function ReservationDetail({ reservation: r, guestName, roomNumber, onClose }: {
  reservation: Reservation; guestName: string; roomNumber: string; onClose: () => void;
}) {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [attachOpen, setAttachOpen] = useState(false);

  const services = useAsync(() => reservationService.servicesOf(r.id), [r.id]);
  const payments = useAsync(() => reservationService.paymentsOf(r.id), [r.id]);
  const catalog = useAsync(() => serviceService.list(hotelId), [hotelId]);
  const catalogMap = new Map((catalog.data ?? []).map((s) => [s.id, s]));
  const servicesTotal = (services.data ?? []).reduce((s, x) => s + x.quantity * x.unitPrice, 0);
  const balance = r.totalAmount + servicesTotal - r.paidAmount;

  const attach = useMutation(
    async (serviceId: string, qty: number) => {
      await reservationService.addService(hotelId, r.id, serviceId, qty, '');
    },
    () => { toast.push('success', t('services.attached')); setAttachOpen(false); services.reload(); },
  );

  return (
    <Modal title={t('reservations.view')} wide onClose={onClose}>
      <div className="stack">
        <div className="flex-between">
          <div>
            <strong style={{ fontSize: 16 }}>{r.reference}</strong>
            <p className="muted small">{guestName} · {t('common.room')} {roomNumber}</p>
          </div>
          <Badge status={r.status} label={t(`statuses.reservation.${r.status}` as never)} />
        </div>
        <dl className="kv card" style={{ padding: 14 }}>
          <dt>{t('reservations.stay')}</dt><dd>{formatDate(r.checkIn, locale)} → {formatDate(r.checkOut, locale)}</dd>
          <dt>{t('reservations.guestsLabel')}</dt><dd>{t('common.guestCount', { adults: r.adults, children: r.children })}</dd>
          <dt>{t('reservations.source')}</dt><dd>{t(`sources.${r.source}` as never)}</dd>
          <dt>{t('reservations.totalAmount')}</dt><dd className="money">{formatMoney(r.totalAmount, r.currency, locale)}</dd>
          <dt>{t('reservations.services')}</dt><dd className="money">{formatMoney(servicesTotal, r.currency, locale)}</dd>
          <dt>{t('common.paid')}</dt><dd className="money">{formatMoney(r.paidAmount, r.currency, locale)}</dd>
          <dt>{t('reservations.balance')}</dt><dd className={`money ${balance > 0 ? 'neg' : 'pos'}`}>{formatMoney(Math.max(0, balance), r.currency, locale)}</dd>
          {r.specialRequests && (<><dt>{t('reservations.specialRequests')}</dt><dd>{r.specialRequests}</dd></>)}
        </dl>

        <div className="flex-between">
          <strong className="small">{t('reservations.services')}</strong>
          {(r.status === 'checked_in' || r.status === 'confirmed') && user && (
            <Button size="sm" onClick={() => setAttachOpen(true)}><IconPlus /> {t('reservations.addService')}</Button>
          )}
        </div>
        {services.data?.length === 0 && <p className="muted small">{t('common.none')}</p>}
        {(services.data ?? []).map((s) => {
          const svc = catalogMap.get(s.serviceId);
          return (
            <div key={s.id} className="flex-between" style={{ fontSize: 13 }}>
              <span>{svc?.name[locale] ?? '—'} × {s.quantity}</span>
              <span className="money">{formatMoney(s.quantity * s.unitPrice, r.currency, locale)}</span>
            </div>
          );
        })}

        <strong className="small">{t('reservations.payments')}</strong>
        {payments.data?.length === 0 && <p className="muted small">{t('common.none')}</p>}
        {(payments.data ?? []).map((p) => (
          <div key={p.id} className="flex-between" style={{ fontSize: 13 }}>
            <span>{t(`methods.${p.method}` as never)} · {formatDateTime(p.paidAt, locale)}</span>
            <span className="flex" style={{ gap: 8 }}>
              <span className="money">{formatMoney(p.amount, r.currency, locale)}</span>
              <Badge status={p.status} label={t(`statuses.payment.${p.status}` as never)} />
            </span>
          </div>
        ))}
      </div>

      {attachOpen && (
        <Modal title={t('services.attachToReservation')} onClose={() => setAttachOpen(false)}>
          <div className="stack">
            {(catalog.data ?? []).filter((s) => s.active).map((s) => (
              <div key={s.id} className="flex-between card" style={{ padding: '10px 14px' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{s.name[locale]}</div>
                  <div className="muted small">{formatMoney(s.price, r.currency, locale)}</div>
                </div>
                <Button size="sm" variant="primary" loading={attach.pending} onClick={() => attach.execute(s.id, 1)}>
                  {t('services.attach')}
                </Button>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </Modal>
  );
}
