# HotelOS — Hotel Property Management System

A production-ready, multi-tenant **Hotel PMS** frontend built with **React + TypeScript + Vite**, designed for **Supabase** as the backend. Runs fully in **demo mode** (realistic in-memory data) with zero configuration, and connects to Supabase by flipping one environment variable — **no UI changes required**.

> HotelOS is a PMS, **not** a hotel website builder. It also ships a lightweight public **booking portal** (`/book/:hotelSlug`) that hotels can share via WhatsApp, Instagram, QR codes, or their existing site.

---

## Features

- **Multi-tenant**: every entity carries `hotel_id`; the whole UI operates on the selected hotel, enforced by PostgreSQL Row Level Security.
- **Modules**: Dashboard, Reservations, Availability search, Calendar (day/week/month timeline), Rooms, Room Types, Guests, guided Check-in / Check-out, Housekeeping (kanban), Payments, Services, Reports (charts + CSV export), Users & Roles, Integrations, Hotel Settings.
- **Multilingual**: French (default), Arabic (full RTL), English — every UI string comes from `src/i18n/locales/`, adding a language is a one-file change.
- **Roles & permissions**: `owner / manager / receptionist / housekeeping / accountant` via a central `hasPermission()` matrix — never hardcoded in components.
- **Dual data source** (`VITE_DATA_SOURCE`):
  - `mock` → in-memory demo repositories (offline, default).
  - `supabase` → live repositories over PostgREST + the `search_available_rooms` RPC. The database (exclusion constraint) is the authority against double bookings; conflicts surface as a translated `room_no_longer_available` message.
- **Architecture**: typed models mirror the schema (`hotels, profiles, room_types, rooms, guests, reservations, payments, services, reservation_services, housekeeping_tasks, room_status_history`); services depend on repository **interfaces** only; a single wiring point (`src/repositories/index.ts`) switches implementations; centralized snake_case⇄camelCase mappers keep DB names out of the UI.
- **Future channel integrations**: `src/integrations` defines a `ChannelProvider` contract (Booking.com, Expedia, Airbnb, direct, phone, WhatsApp) with mock implementations — real sync will run in Supabase Edge Functions, never in the browser.

## Tech stack

React 18 · TypeScript (strict) · Vite · React Router 6 · @supabase/supabase-js · dependency-free SVG charts · custom design system with RTL support.

## Getting started

```bash
npm install
npm run dev        # demo mode, no backend needed
npm run build      # type-check (tsc) + production build
npm run preview    # preview the production build
```

### Demo accounts (mock mode only, password for all: `demo123`)

| Email | Role |
| --- | --- |
| `owner@hotelos.demo` | Owner (full access) |
| `manager@hotelos.demo` | Manager |
| `reception@hotelos.demo` | Receptionist |
| `housekeep@hotelos.demo` | Housekeeping |
| `accounting@hotelos.demo` | Accountant |

### Public booking portal

`http://localhost:5173/book/riad-atlas-palace` (mock hotel slug)

## Environment variables

Copy `.env.example` → `.env`:

```bash
VITE_SUPABASE_URL=          # public project URL
VITE_SUPABASE_ANON_KEY=     # public anon/publishable key (RLS-protected)
VITE_DATA_SOURCE=mock       # `mock` or `supabase`
VITE_BASE_PATH=/            # set to /your-repo/ for GitHub Pages project sites
```

**Never** put a service-role key or any secret in frontend env variables. `.env` is git-ignored.

## Connecting Supabase (one-time)

1. Create the tables (if not already present): `hotels, profiles, room_types, rooms, guests, reservations, payments, services, reservation_services, housekeeping_tasks, room_status_history` (UUID PKs, `hotel_id` FKs).
2. Enable RLS on every table; scope policies per hotel (`auth.uid()` → `profiles.hotel_id`).
3. Add the exclusion constraint on `reservations` (room + daterange) for double-booking protection, and the RPC `search_available_rooms(p_hotel_id uuid, p_check_in date, p_check_out date, p_guests int)` used by `availabilityService`.
4. **Grants & policies for `hotels`/`profiles`** — run `supabase/fix-42501-grants-and-policies.sql` from the SQL Editor (fixes 42501 and scopes reads precisely: authenticated users see only their own profile + hotel; anon sees the public hotel directory required by the booking portal).
5. Implement user invitations via a secure Edge Function (the browser must never create auth users — `profiles` writes are for role/active management only).

## Architecture

```
src/
├── types/            domain models (mirror the Supabase schema)
├── i18n/             provider + fr / ar / en locales
├── mock/             demo dataset (isolated, resettable)
├── repositories/     interfaces + mock impls + supabase impls + wiring
├── services/         business logic (UI talks to services only)
├── integrations/     ChannelProvider contract + mock providers
├── contexts/         Auth (mock/supabase adapters), active Hotel
├── hooks/            useAsync (loading/success/empty/error), useMutation
├── components/       ui kit, charts, icons
├── layouts/          app shell (sidebar + header, mobile drawer)
└── pages/            all routes (lazy-loaded)
```

## GitHub Pages deployment

```bash
VITE_BASE_PATH=/your-repo-name/ npm run build
# deploy dist/ to gh-pages (public/404.html keeps deep links working)
```

## License

MIT (demo data is fictional).


## GitHub Pages

This repository includes an automatic GitHub Pages workflow. The production build uses the `/hotel-os/` base path and the Supabase publishable browser key. No service-role or secret key is included.

After pushing to the `main` branch, enable GitHub Pages with **Settings → Pages → Source: GitHub Actions**. The workflow will build and deploy automatically.
