import React, { useEffect, useMemo, useRef, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useAuth } from '@/contexts/AuthContext';
import { useHotel } from '@/contexts/HotelContext';
import { hasPermission, NAV_VISIBILITY } from '@/utils/permissions';
import { notificationRepository } from '@/repositories';
import { useAsync } from '@/hooks/useAsync';
import {
  Avatar, Button, LanguageSwitcher,
} from '@/components/ui';
import {
  IconBell, IconBed, IconBroom, IconCalendar, IconCard, IconCheckIn, IconCheckOut,
  IconDashboard, IconGear, IconGuests, IconMenu, IconPlug, IconReport, IconRooms,
  IconSearch, IconUsers, IconGlobe,
} from '@/components/icons';

const NAV: { path: string; key: string; icon: React.ReactNode; section?: string }[] = [
  { path: '/app/dashboard', key: 'dashboard', icon: <IconDashboard /> },
  { path: '/app/reservations', key: 'reservations', icon: <IconCalendar />, section: 'front' },
  { path: '/app/calendar', key: 'calendar', icon: <IconCalendar />, section: 'front' },
  { path: '/app/check-in', key: 'checkIn', icon: <IconCheckIn />, section: 'front' },
  { path: '/app/check-out', key: 'checkOut', icon: <IconCheckOut />, section: 'front' },
  { path: '/app/rooms', key: 'rooms', icon: <IconRooms />, section: 'hotel' },
  { path: '/app/room-types', key: 'roomTypes', icon: <IconBed />, section: 'hotel' },
  { path: '/app/housekeeping', key: 'housekeeping', icon: <IconBroom />, section: 'hotel' },
  { path: '/app/services', key: 'services', icon: <IconGlobe />, section: 'hotel' },
  { path: '/app/guests', key: 'guests', icon: <IconGuests />, section: 'guests' },
  { path: '/app/payments', key: 'payments', icon: <IconCard />, section: 'guests' },
  { path: '/app/reports', key: 'reports', icon: <IconReport />, section: 'insights' },
  { path: '/app/users', key: 'users', icon: <IconUsers />, section: 'insights' },
  { path: '/app/integrations', key: 'integrations', icon: <IconPlug />, section: 'insights' },
  { path: '/app/settings', key: 'settings', icon: <IconGear />, section: 'insights' },
];

export default function AppLayout() {
  const { t, locale } = useTranslation();
  const { user, signOut } = useAuth();
  const { hotels, hotel, setHotelId } = useHotel();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  const { data: notifications, reload } = useAsync(
    () => (hotel ? notificationRepository.list(hotel.id) : Promise.resolve([])),
    [hotel?.id],
  );

  useEffect(() => setSidebarOpen(false), [location.pathname]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const visibleNav = useMemo(() => {
    if (!user) return [];
    return NAV.filter((item) => {
      const perm = NAV_VISIBILITY[item.path];
      return perm ? hasPermission(user.role, perm) : true;
    });
  }, [user]);

  const unread = (notifications ?? []).filter((n) => !n.read).length;

  const sections: Record<string, string | undefined> = {
    front: undefined, hotel: undefined, guests: undefined, insights: undefined,
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`} aria-label={t('appName')}>
        <div className="sidebar-brand">
          <span className="sidebar-brand-mark">H</span>
          HotelOS
        </div>
        <nav className="sidebar-nav">
          {visibleNav.map((item, i) => {
            const prev = visibleNav[i - 1];
            const showSection = item.section && prev?.section !== item.section;
            return (
              <React.Fragment key={item.path}>
                {showSection && <div className="sidebar-section">—</div>}
                <NavLink to={item.path} className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
                  {item.icon}
                  {t(`nav.${item.key}` as never)}
                </NavLink>
              </React.Fragment>
            );
          })}
        </nav>
        <div className="sidebar-foot">
          <div className="sidebar-demo">
            <span className="pulse" aria-hidden />
            {t('common.demoBadge')} · v1.0
          </div>
        </div>
      </aside>
      {sidebarOpen && <div className="sidebar-backdrop show" onClick={() => setSidebarOpen(false)} />}

      <div className="main">
        <header className="header">
          <button className="btn btn-ghost btn-icon header-burger" onClick={() => setSidebarOpen(true)} aria-label="menu">
            <IconMenu />
          </button>

          {hotels.length > 1 ? (
            <select
              className="select header-hotel-select"
              value={hotel?.id ?? ''}
              onChange={(e) => setHotelId(e.target.value)}
              aria-label={t('common.selectHotel')}
            >
              {hotels.map((h) => (
                <option key={h.id} value={h.id}>{h.name}</option>
              ))}
            </select>
          ) : (
            <strong style={{ fontSize: 15 }}>{hotel?.name}</strong>
          )}

          <div className="header-search">
            <IconSearch />
            <input
              className="input"
              placeholder={t('common.searchPlaceholder')}
              aria-label={t('common.search')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                  navigate(`/app/reservations?search=${encodeURIComponent(e.currentTarget.value.trim())}`);
                  e.currentTarget.value = '';
                }
              }}
            />
          </div>

          <div className="header-spacer" />
          <LanguageSwitcher compact />

          <div className="dropdown" ref={notifRef}>
            <button className="btn btn-ghost btn-icon" onClick={() => setNotifOpen((o) => !o)} aria-label={t('common.notifications')}>
              <IconBell />
              {unread > 0 && <span className="badge" style={{ position: 'absolute', insetBlockStart: 2, insetInlineEnd: 2, padding: '1px 5px', fontSize: 9 }}>{unread}</span>}
            </button>
            {notifOpen && (
              <div className="dropdown-menu" style={{ minWidth: 300 }}>
                <div className="flex-between" style={{ padding: '10px 14px', borderBlockEnd: '1px solid var(--border)' }}>
                  <strong style={{ fontSize: 13 }}>{t('common.notifications')}</strong>
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={async () => { if (hotel) { await notificationRepository.markAllRead(hotel.id); reload(); } }}
                  >
                    {t('common.markAllRead')}
                  </button>
                </div>
                {(notifications ?? []).length === 0 && <p className="muted small" style={{ padding: 14 }}>{t('common.noNotifications')}</p>}
                {(notifications ?? []).map((n) => (
                  <div key={n.id} className={`notif-item ${n.read ? 'read' : 'unread'}`}>
                    <span className="dot" aria-hidden />
                    <span>{n.title[locale] ?? n.title.fr}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="dropdown" ref={userRef}>
            <button className="btn btn-ghost" onClick={() => setUserOpen((o) => !o)} style={{ gap: 9 }}>
              <Avatar name={`${user?.firstName} ${user?.lastName}`} color={user?.avatarColor ?? '#475569'} size="sm" />
              <span style={{ fontSize: 13, fontWeight: 600 }}>{user?.firstName}</span>
            </button>
            {userOpen && (
              <div className="dropdown-menu">
                <div style={{ padding: '12px 14px', borderBlockEnd: '1px solid var(--border)' }}>
                  <strong style={{ fontSize: 13.5 }}>{user?.firstName} {user?.lastName}</strong>
                  <p className="muted small">{user?.email}</p>
                  <span className="badge" style={{ marginBlockStart: 5 }}>{t(`roles.${user?.role}` as never)}</span>
                </div>
                <button className="dropdown-item" onClick={async () => { await signOut(); navigate('/login'); }}>
                  {t('common.logout')}
                </button>
              </div>
            )}
          </div>
        </header>

        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
