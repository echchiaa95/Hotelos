import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync } from '@/hooks/useAsync';
import { guestService, paymentService, reservationService } from '@/services';
import { Badge, Button, Card, LoadingBlock, StatCard } from '@/components/ui';
import { PaymentModal } from './CheckOut';
import { formatDateTime, formatMoney } from '@/utils/format';

export default function Payments() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [addOpen, setAddOpen] = useState(false);

  const payments = useAsync(() => (hotelId ? paymentService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const reservations = useAsync(() => (hotelId ? reservationService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const refOf = (rid: string) => reservations.data?.find((r) => r.id === rid)?.reference ?? '—';
  const guestOf = (rid: string) => {
    const r = reservations.data?.find((x) => x.id === rid);
    const g = guests.data?.find((x) => x.id === r?.guestId);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };

  const list = payments.data ?? [];
  const paid = list.filter((p) => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const pending = list.filter((p) => p.status === 'pending').reduce((s, p) => s + p.amount, 0);
  const refunded = list.filter((p) => p.status === 'refunded').reduce((s, p) => s + p.amount, 0);

  return (
    <div className="stack">
      <div className="page-head">
        <div><h1>{t('payments.title')}</h1></div>
        <Button variant="primary" onClick={() => setAddOpen(true)}>+ {t('payments.add')}</Button>
      </div>
      <Card title={t('payments.summary')}>
        <div className="stat-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
          <StatCard label={t('payments.totalPaid')} value={formatMoney(paid, currency, locale)} tone="accent" />
          <StatCard label={t('payments.outstanding')} value={formatMoney(pending, currency, locale)} />
          <StatCard label={t('payments.refunded')} value={formatMoney(refunded, currency, locale)} />
        </div>
      </Card>
      {payments.status === 'loading' && <LoadingBlock />}
      {payments.status === 'success' && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('reservations.reference')}</th>
                <th>{t('common.guest')}</th>
                <th>{t('payments.method')}</th>
                <th>{t('common.amount')}</th>
                <th>{t('payments.paidAt')}</th>
                <th>{t('common.status')}</th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id}>
                  <td className="cell-main">{refOf(p.reservationId)}</td>
                  <td>{guestOf(p.reservationId)}</td>
                  <td>{t(`methods.${p.method}`)}</td>
                  <td className="num">{formatMoney(p.amount, currency, locale)}</td>
                  <td className="muted">{formatDateTime(p.paidAt, locale)}</td>
                  <td><Badge status={p.status} label={t(`statuses.payment.${p.status}`)} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {addOpen && (
        <PaymentModal
          hotelId={hotelId}
          reservationId={(reservations.data ?? [])[0]?.id ?? ''}
          currency={currency}
          onClose={() => setAddOpen(false)}
          onDone={() => { setAddOpen(false); payments.reload(); }}
        />
      )}
    </div>
  );
}
