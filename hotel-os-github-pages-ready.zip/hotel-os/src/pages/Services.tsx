import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { serviceService } from '@/services';
import { Badge, Button, Card, Field, LoadingBlock, Modal, useToast } from '@/components/ui';
import { IconEdit, IconPlus } from '@/components/icons';
import { formatMoney } from '@/utils/format';
import type { HotelService, LocalizedText } from '@/types';

export default function Services() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [editing, setEditing] = useState<HotelService | null | 'new'>(null);

  const services = useAsync(() => (hotelId ? serviceService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const toggle = useMutation(async (id: string) => {
    await serviceService.toggleActive(id);
  }, () => services.reload());

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('services.title')}</h1>
        <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('services.add')}</Button>
      </div>
      {services.status === 'loading' && <LoadingBlock />}
      <div className="integ-grid">
        {(services.data ?? []).map((s) => (
          <Card key={s.id} className="integ-card">
            <div className="flex-between">
              <strong style={{ fontSize: 15 }}>{s.name[locale]}</strong>
              <Badge status={s.active ? 'available' : 'out_of_service'} label={s.active ? t('common.active') : t('common.inactive')} />
            </div>
            <p className="muted small">{s.description[locale]}</p>
            <div className="flex-between">
              <span className="money">{formatMoney(s.price, currency, locale)}</span>
              <div className="flex">
                <Button size="sm" className="btn-icon" onClick={() => setEditing(s)} aria-label={t('common.edit')}><IconEdit /></Button>
                <Button size="sm" onClick={() => toggle.execute(s.id)}>
                  {s.active ? t('common.inactive') : t('common.active')}
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
      {editing !== null && (
        <ServiceForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); services.reload(); toast.push('success', t('services.serviceSaved')); }}
        />
      )}
    </div>
  );
}

function ServiceForm({ hotelId, initial, onClose, onSaved }: {
  hotelId: string;
  initial: HotelService | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [f, setF] = useState({
    name: initial?.name ?? ({ fr: '', ar: '', en: '' } as LocalizedText),
    description: initial?.description ?? ({ fr: '', ar: '', en: '' } as LocalizedText),
    price: initial?.price ?? 100,
    active: initial?.active ?? true,
  });
  const save = useMutation(async () => {
    if (initial) await serviceService.update(initial.id, f);
    else await serviceService.create(hotelId, f);
  }, onSaved);
  const setLoc = (field: 'name' | 'description', lang: 'fr' | 'ar' | 'en', v: string) =>
    setF((s) => ({ ...s, [field]: { ...s[field], [lang]: v } }));
  return (
    <Modal
      title={t(initial ? 'services.edit' : 'services.add')}
      wide
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button
            variant="primary"
            disabled={!(f.name.fr && f.name.ar && f.name.en)}
            loading={save.pending}
            onClick={() => save.execute()}
          >
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label={t('services.nameFr')}><input className="input" value={f.name.fr} onChange={(e) => setLoc('name', 'fr', e.target.value)} /></Field>
        <Field label={t('services.nameAr')}><input className="input" dir="rtl" value={f.name.ar} onChange={(e) => setLoc('name', 'ar', e.target.value)} /></Field>
        <Field label={t('services.nameEn')}><input className="input" value={f.name.en} onChange={(e) => setLoc('name', 'en', e.target.value)} /></Field>
        <Field label={t('common.price')}><input className="input" type="number" min={0} value={f.price} onChange={(e) => setF({ ...f, price: Number(e.target.value) })} /></Field>
        <Field label={t('services.descFr')} full><textarea className="textarea" value={f.description.fr} onChange={(e) => setLoc('description', 'fr', e.target.value)} /></Field>
        <Field label={t('services.descAr')} full><textarea className="textarea" dir="rtl" value={f.description.ar} onChange={(e) => setLoc('description', 'ar', e.target.value)} /></Field>
        <Field label={t('services.descEn')} full><textarea className="textarea" value={f.description.en} onChange={(e) => setLoc('description', 'en', e.target.value)} /></Field>
      </div>
      <label className="checkbox-row mt">
        <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />
        {t('common.active')}
      </label>
    </Modal>
  );
}
