// Service barrel — pages import services only from here.
export { hotelService } from './hotelService';
export { roomService } from './roomService';
export { roomTypeService } from './roomTypeService';
export { guestService } from './guestService';
export { reservationService } from './reservationService';
export { paymentService } from './paymentService';
export { housekeepingService } from './housekeepingService';
export { serviceService } from './serviceService';
export { availabilityService } from './availabilityService';
export { reportService } from './reportService';
export { userService } from './userService';
export { authService } from './authService';
