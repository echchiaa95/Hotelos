-- ─────────────────────────────────────────────────────────────
-- HotelOS — Fix 42501 (permission denied) + precise RLS scoping
-- Run ONCE in: Supabase Dashboard → SQL Editor
--
-- What this does:
--   1. GRANTs: minimal, read-only. `hotels` readable by anon
--      (required by the PUBLIC booking portal /book/:slug) and by
--      authenticated users. `profiles` readable ONLY by
--      authenticated users — never anon.
--   2. RLS on profiles: a user reads ONLY their own row.
--   3. RLS on hotels: an authenticated user reads ONLY the hotel
--      tied to their profile (profiles.hotel_id); anon reads the
--      public directory. The `auth.role() = 'anon'` guard is
--      REQUIRED because `authenticated` inherits `anon` grants in
--      Supabase — without it, the public policy would leak all
--      hotels to authenticated users too.
--
-- Idempotent: safe to re-run (DROP POLICY IF EXISTS first).
-- Does NOT touch data, does NOT recreate tables, does NOT disable RLS.
-- ─────────────────────────────────────────────────────────────

-- 1) Grants ------------------------------------------------------------
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON public.hotels TO anon, authenticated;
GRANT SELECT ON public.profiles TO authenticated;

-- 2) profiles: own-row only -------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profiles_select_own ON public.profiles;
CREATE POLICY profiles_select_own
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- 3) hotels: scoped for authenticated, public directory for anon ------
ALTER TABLE public.hotels ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS hotels_select_authenticated_own ON public.hotels;
CREATE POLICY hotels_select_authenticated_own
  ON public.hotels
  FOR SELECT
  TO authenticated
  USING (id = (SELECT hotel_id FROM public.profiles WHERE id = auth.uid()));

DROP POLICY IF EXISTS hotels_select_anon_public ON public.hotels;
CREATE POLICY hotels_select_anon_public
  ON public.hotels
  FOR SELECT
  TO anon
  USING (auth.role() = 'anon');

-- Verification queries (optional, run after):
--   select * from pg_policies where tablename in ('hotels','profiles');
--   select * from hotels;          -- as anon: all rows (directory)
--   select * from hotels;          -- as authenticated: only own hotel
