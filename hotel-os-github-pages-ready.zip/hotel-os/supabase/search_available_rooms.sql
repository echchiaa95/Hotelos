-- ─────────────────────────────────────────────────────────────
-- HotelOS — search_available_rooms RPC
-- Signature VERIFIED against the live project (called successfully
-- with these exact parameter names via PostgREST):
--   search_available_rooms(p_hotel_id uuid, p_check_in date,
--                          p_check_out date, p_guests integer)
--
-- If your database already contains this function, you do NOT need
-- to run this file — it is provided for reproducibility / fresh
-- setups. Idempotent: drops and recreates only this function.
--
-- Notes:
--  * SECURITY DEFINER lets the PUBLIC booking portal (anon) search
--    availability without gaining any read access to reservations.
--    The function returns only non-sensitive data (room number,
--    room-type name/description/price). `SET search_path = public`
--    prevents search-path hijacking.
--  * The DATABASE is the authority against double bookings via the
--    exclusion constraint on reservations (see bottom section).
-- ─────────────────────────────────────────────────────────────

DROP FUNCTION IF EXISTS public.search_available_rooms(uuid, date, date, integer);

CREATE OR REPLACE FUNCTION public.search_available_rooms(
  p_hotel_id uuid,
  p_check_in date,
  p_check_out date,
  p_guests integer
)
RETURNS TABLE (
  room_id      uuid,
  number       text,
  floor        integer,
  status       text,
  hotel_id     uuid,
  room_type_id uuid,
  name         jsonb,
  description  jsonb,
  base_price   numeric,
  max_guests   integer,
  beds         jsonb,
  size         numeric,
  amenities    jsonb,
  images       jsonb,
  total_price  numeric,
  nights       integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    r.id            AS room_id,
    r.number        AS number,
    r.floor         AS floor,
    r.status        AS status,
    r.hotel_id      AS hotel_id,
    t.id            AS room_type_id,
    t.name          AS name,
    t.description   AS description,
    t.base_price    AS base_price,
    t.max_guests    AS max_guests,
    t.beds          AS beds,
    t.size          AS size,
    t.amenities     AS amenities,
    t.images        AS images,
    t.base_price * (p_check_out - p_check_in) AS total_price,
    (p_check_out - p_check_in)::integer       AS nights
  FROM public.rooms r
  JOIN public.room_types t ON t.id = r.room_type_id
  WHERE r.hotel_id = p_hotel_id
    AND t.active = true
    AND t.max_guests >= p_guests
    AND r.status <> 'out_of_service'
    -- Blocked if ANY active reservation overlaps [p_check_in, p_check_out)
    AND NOT EXISTS (
      SELECT 1
      FROM public.reservations res
      WHERE res.room_id = r.id
        AND res.status IN ('pending', 'confirmed', 'checked_in')
        AND res.check_in < p_check_out
        AND res.check_out > p_check_in
    )
  ORDER BY t.base_price, r.number;
$$;

-- Executable by anonymous visitors (booking portal) and by
-- authenticated users. The function, not the caller, reads the
-- underlying tables.
GRANT EXECUTE ON FUNCTION public.search_available_rooms(uuid, date, date, integer)
  TO anon, authenticated;

-- ─────────────────────────────────────────────────────────────
-- Double-booking protection (run ONCE if not already present).
-- The frontend converts violations of this constraint into the
-- translated message "room_no_longer_available".
-- NOTE: requires the btree_gist extension:
--   CREATE EXTENSION IF NOT EXISTS btree_gist;
-- ─────────────────────────────────────────────────────────────
-- ALTER TABLE public.reservations
--   ADD CONSTRAINT reservations_no_overlap
--   EXCLUDE USING gist (
--     room_id WITH =,
--     daterange(check_in, check_out, '[)') WITH &&
--   )
--   WHERE (status IN ('pending', 'confirmed', 'checked_in'));
