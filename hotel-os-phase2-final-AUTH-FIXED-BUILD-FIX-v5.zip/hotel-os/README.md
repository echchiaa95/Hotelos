# HotelOS — Hotel Property Management System

A production-ready, multi-tenant **Hotel PMS** frontend built with **React + TypeScript + Vite**, designed for **Supabase** as the backend. Runs fully in **demo mode** (realistic in-memory data) with zero configuration, and connects to Supabase by flipping one environment variable — **no UI changes required**.

> HotelOS is a PMS, **not** a hotel website builder. It also ships a lightweight public **booking portal** (`/book/:hotelSlug`) that hotels can share via WhatsApp, Instagram, QR codes, or their existing site.

---

## Features

- **Multi-tenant**: every entity carries `hotel_id`; the whole UI operates on the selected hotel, enforced by PostgreSQL Row Level Security.
- **Modules**: Dashboard, Reservations, Availability search, Calendar (day/week/month timeline), Rooms, Room Types, Guests, guided Check-in / Check-out, Housekeeping (kanban), Payments, Services, Reports (charts + CSV export), Users & Roles, Integrations, Hotel Settings.
- **Multilingual**: French (default), Arabic (full RTL), English — every UI string comes from `src/i18n/locales/`, adding a language is a one-file change.
- **Roles & permissions**: `owner / manager / receptionist / housekeeping / accountant` via a central `hasPermission()` matrix — never hardcoded in components.
- **Dual data source** (`VITE_DATA_SOURCE`):
  - `mock` → in-memory demo repositories (offline, default).
  - `supabase` → live repositories over PostgREST + the `search_available_rooms` RPC. The database (exclusion constraint) is the authority against double bookings; conflicts surface as a translated `room_no_longer_available` message.
- **Architecture**: typed models mirror the schema (`hotels, profiles, room_types, rooms, guests, reservations, payments, services, reservation_services, housekeeping_tasks, room_status_history`); services depend on repository **interfaces** only; a single wiring point (`src/repositories/index.ts`) switches implementations; centralized snake_case⇄camelCase mappers keep DB names out of the UI.
- **Future channel integrations**: `src/integrations` defines a `ChannelProvider` contract (Booking.com, Expedia, Airbnb, direct, phone, WhatsApp) with mock implementations — real sync will run in Supabase Edge Functions, never in the browser.

## Tech stack

React 18 · TypeScript (strict) · Vite · React Router 6 · @supabase/supabase-js · dependency-free SVG charts · custom design system with RTL support.

## Getting started

```bash
npm install
npm run dev        # demo mode, no backend needed
npm run build      # type-check (tsc) + production build
npm run preview    # preview the production build
```

### Demo accounts (mock mode only, password for all: `demo123`)

| Email | Role |
| --- | --- |
| `owner@hotelos.demo` | Owner (full access) |
| `manager@hotelos.demo` | Manager |
| `reception@hotelos.demo` | Receptionist |
| `housekeep@hotelos.demo` | Housekeeping |
| `accounting@hotelos.demo` | Accountant |

### Public booking portal

`http://localhost:5173/book/riad-atlas-palace` (mock hotel slug)

## Environment variables

Copy `.env.example` → `.env`:

```bash
VITE_SUPABASE_URL=          # public project URL
VITE_SUPABASE_ANON_KEY=     # public anon/publishable key (RLS-protected)
VITE_DATA_SOURCE=mock       # `mock` or `supabase`
VITE_BASE_PATH=/            # set to /your-repo/ for GitHub Pages project sites
```

**Never** put a service-role key or any secret in frontend env variables. `.env` is git-ignored.

## Connecting Supabase (one-time)

1. Create the tables (if not already present): `hotels, profiles, room_types, rooms, guests, reservations, payments, services, reservation_services, housekeeping_tasks, room_status_history` (UUID PKs, `hotel_id` FKs).
2. Enable RLS on every table; scope policies per hotel (`auth.uid()` → `profiles.hotel_id`).
3. Add the exclusion constraint on `reservations` (room + daterange) for double-booking protection (see the commented block at the bottom of `supabase/search_available_rooms.sql`; needs `btree_gist`).
4. Run in the SQL Editor, **in this order** (none of these has been executed by the author against a live DB — run the verification queries at the end of the first file):
   1. `supabase/fix-42501-grants-and-policies.sql` — grants, explicit hotel-scoped RLS on every PMS table via `current_hotel_id()`, profile column protection (role/active/hotel_id), cross-hotel integrity triggers, `get_public_hotel_by_slug`, `update_hotel_settings`.
   2. `supabase/search_available_rooms.sql` — public availability RPC (validated, no guest/reservation data).
   3. `supabase/create_public_booking.sql` — the ONLY way the public portal creates a guest + reservation (anon has no table access).
5. **Users:** the browser cannot create Auth users. Deploy the Edge Function `supabase/functions/create-hotel-user` (`supabase functions deploy create-hotel-user`, keep *Verify JWT* on). Until it is deployed, "Add user" shows an explicit *unavailable* error — it never fakes success. `SUPABASE_SERVICE_ROLE_KEY` exists only inside the function's environment.
6. **Hotel settings:** saved through `update_hotel_settings` (active owner/manager of that hotel only). There is no UPDATE grant on `hotels`.

## Deployment (GitHub Pages, ZIP upload)

Repository root contains `hotel-os-phase2-final.zip` and `.github/workflows/deploy.yml`. On every push to `main` the workflow unzips, finds `hotel-os/package.json`, runs `npm ci && npm run build` with `VITE_BASE_PATH=/Hotelos/` and the public Supabase URL/publishable key, and deploys `dist`. Repository *Settings → Pages → Source* must be **GitHub Actions**. Replace the ZIP to redeploy.

## Architecture

```
src/
├── types/            domain models (mirror the Supabase schema)
├── i18n/             provider + fr / ar / en locales
├── mock/             demo dataset (isolated, resettable)
├── repositories/     interfaces + mock impls + supabase impls + wiring
├── services/         business logic (UI talks to services only)
├── integrations/     ChannelProvider contract + mock providers
├── contexts/         Auth (mock/supabase adapters), active Hotel
├── hooks/            useAsync (loading/success/empty/error), useMutation
├── components/       ui kit, charts, icons
├── layouts/          app shell (sidebar + header, mobile drawer)
└── pages/            all routes (lazy-loaded)
```

## GitHub Pages deployment

```bash
VITE_BASE_PATH=/your-repo-name/ npm run build
# deploy dist/ to gh-pages (public/404.html keeps deep links working)
```

## License

MIT (demo data is fictional).


## GitHub Pages

This repository includes an automatic GitHub Pages workflow. The production build uses the `/hotel-os/` base path and the Supabase publishable browser key. No service-role or secret key is included.

After pushing to the `main` branch, enable GitHub Pages with **Settings → Pages → Source: GitHub Actions**. The workflow will build and deploy automatically.


## Password recovery / GitHub Pages

HotelOS production authentication uses Supabase Auth with the public publishable key.
Configure these Supabase Authentication URLs:

- Site URL: `https://echchiaa95.github.io/Hotelos/`
- Redirect URL: `https://echchiaa95.github.io/Hotelos/reset-password`

The application sends password-recovery emails with the `/reset-password` redirect and
provides a real password update screen. Do not put a Supabase service-role key in the
frontend or GitHub Pages build.
