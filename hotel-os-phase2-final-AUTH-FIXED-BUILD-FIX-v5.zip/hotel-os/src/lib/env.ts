// ── Data source configuration ─────────────────────────────────
// `mock`    → in-memory demo repositories (default, works offline)
// `supabase`→ live Supabase project (RLS-protected, public key only)

export type DataSource = 'mock' | 'supabase';

const raw = String(import.meta.env.VITE_DATA_SOURCE ?? '').trim().toLowerCase();

// GitHub Pages is the production HotelOS deployment. Keep the production
// app on the real Supabase backend even if a deployment accidentally omits
// VITE_DATA_SOURCE during the static build. Local development remains mock
// unless VITE_DATA_SOURCE=supabase is explicitly supplied.
const isProductionSite =
  typeof window !== 'undefined' &&
  window.location.hostname === 'echchiaa95.github.io' &&
  window.location.pathname.startsWith('/Hotelos');

export const DATA_SOURCE: DataSource =
  raw === 'supabase' || isProductionSite ? 'supabase' : 'mock';

export const isSupabaseMode = DATA_SOURCE === 'supabase';
