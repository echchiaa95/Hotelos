// ── Error normalization ───────────────────────────────────────
// Converts Supabase/PostgREST/network errors into application
// HotelError codes with i18n-friendly messages. Raw technical
// details stay in the console (development), never in the UI.

import { HotelError } from '@/types';

function errInfo(e: unknown): { message: string; code: string; status?: number } {
  if (e && typeof e === 'object') {
    const o = e as { message?: string; code?: string; status?: number };
    return { message: String(o.message ?? ''), code: String(o.code ?? ''), status: o.status };
  }
  return { message: String(e ?? ''), code: '' };
}

export function normalizeError(e: unknown): HotelError {
  if (e instanceof HotelError) return e;

  const { message, code, status } = errInfo(e);
  const hay = `${code} ${message}`;

  // Database exclusion constraint / overlapping reservation
  if (code === '23P01' || /exclusion constraint|overlapping|conflicts with/i.test(hay)) {
    return new HotelError('room_no_longer_available');
  }
  // Auth / session problems
  if (status === 401 || code === 'PGRST301' || /jwt|unauthorized|not authenticated/i.test(hay)) {
    return new HotelError('unauthorized');
  }
  // RLS denial / missing table grant (Postgres 42501)
  if (status === 403 || code === '42501' || /row-level security|rls|forbidden|permission denied/i.test(hay)) {
    return new HotelError('forbidden');
  }
  // Offline / DNS / CORS fetch failures
  if (/failed to fetch|networkerror|fetch failed|network request failed/i.test(hay)) {
    return new HotelError('network');
  }
  // RPC input validation (RAISE ... ERRCODE 22023)
  if (code === '22023') {
    return new HotelError('invalid_request');
  }
  // Bad UUID
  if (/invalid input syntax for type uuid|invalid uuid/i.test(hay)) {
    return new HotelError('invalid_uuid');
  }
  // "No rows found" from PostgREST
  if (code === 'PGRST116') {
    return new HotelError('not_found');
  }
  // Unique violation (non-exclusion) → treat as conflict
  if (code === '23505' || /duplicate key/i.test(hay)) {
    return new HotelError('conflict');
  }
  return new HotelError('generic');
}

/** Await a promise, rethrowing any failure as a normalized HotelError. */
export async function guard<T>(p: Promise<T>): Promise<T> {
  try {
    return await p;
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('[HotelOS] repository error:', e);
    throw normalizeError(e);
  }
}

export function mapAuthError(e: unknown): HotelError {
  const { message } = errInfo(e);
  if (/invalid login credentials|invalid password|email not confirmed/i.test(message)) {
    return new HotelError('invalid_credentials');
  }
  // Password recovery has several Auth-specific failures that should not be
  // disguised as a generic application error. Keep the technical details in
  // the console, but expose a stable application error code to the UI.
  if (/redirect.*url|redirect_to|redirect uri|not in the allow list|invalid redirect/i.test(message)) {
    return new HotelError('invalid_request');
  }
  if (/rate limit|too many requests|email rate limit|over_email_send_rate_limit/i.test(message)) {
    return new HotelError('rate_limited');
  }
  if (/email.*not found|user.*not found/i.test(message)) {
    return new HotelError('not_found');
  }
  return normalizeError(e);
}
