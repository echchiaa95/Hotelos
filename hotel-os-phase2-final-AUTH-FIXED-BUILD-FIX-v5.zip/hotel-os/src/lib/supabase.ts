// ── Supabase browser client ────────────────────────────────────
// Only the public/publishable key is used in the browser. NEVER put a
// service-role key in this file or in any Vite environment variable used by
// the GitHub Pages build.

import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const PRODUCTION_URL = 'https://mfccirkculdetvjpfdiq.supabase.co';
// Publishable keys are intentionally safe to expose in browser applications.
// The value below is only a fallback for the static GitHub Pages deployment;
// VITE_SUPABASE_PUBLISHABLE_KEY still takes precedence when supplied.
const PRODUCTION_PUBLISHABLE_KEY =
  'sb_publishable_8m86pqA9vG4DhVU4mXI9Q_2SinBZWj';

const envUrl = String(import.meta.env.VITE_SUPABASE_URL ?? '').trim();
const envPublishableKey = String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ?? '').trim();
const envAnonKey = String(import.meta.env.VITE_SUPABASE_ANON_KEY ?? '').trim();

const useProductionFallback =
  typeof window !== 'undefined' &&
  window.location.hostname === 'echchiaa95.github.io' &&
  window.location.pathname.startsWith('/Hotelos');

const url = envUrl || (useProductionFallback ? PRODUCTION_URL : '');
const publicKey =
  envPublishableKey ||
  envAnonKey ||
  (useProductionFallback ? PRODUCTION_PUBLISHABLE_KEY : '');

export const isSupabaseConfigured: boolean = Boolean(url && publicKey);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(url, publicKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;
