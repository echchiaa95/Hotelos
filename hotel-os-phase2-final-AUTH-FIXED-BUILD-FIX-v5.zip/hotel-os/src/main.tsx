import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { I18nProvider } from './i18n';
import { AuthProvider } from './contexts/AuthContext';
import { HotelProvider } from './contexts/HotelContext';
import { ToastProvider } from './components/ui';
import './styles/global.css';
import './styles/responsive.css';
import './styles/polish.css';
import { initTheme } from './hooks/useTheme';

// Restore a deep SPA route after GitHub Pages serves 404.html. This is
// especially important for Supabase password-recovery links because the
// access/refresh tokens are returned in the URL hash.
(function restoreGithubPagesRoute() {
  if (typeof window === 'undefined') return;
  const params = new URLSearchParams(window.location.search);
  const redirect = params.get('redirect');
  if (!redirect || !redirect.startsWith('/')) return;
  const base = String(import.meta.env.VITE_BASE_PATH || '/').replace(/\/+$/, '/');
  const clean = redirect.replace(/^\/+/, '');
  window.history.replaceState({}, '', base + clean);
})();

initTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <I18nProvider>
      <BrowserRouter basename={import.meta.env.VITE_BASE_PATH || '/'}>
        <AuthProvider>
          <HotelProvider>
            <ToastProvider>
              <App />
            </ToastProvider>
          </HotelProvider>
        </AuthProvider>
      </BrowserRouter>
    </I18nProvider>
  </React.StrictMode>,
);
