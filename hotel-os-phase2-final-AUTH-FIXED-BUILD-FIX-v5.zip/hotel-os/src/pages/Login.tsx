import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useAuth } from '@/contexts/AuthContext';
import { requestPasswordReset } from '@/services/authService';
import { Button, Field, LanguageSwitcher, Modal } from '@/components/ui';
import { DATA_SOURCE } from '@/lib/env';
import { HotelError } from '@/types';
import { IconEye } from '@/components/icons';

export default function Login() {
  const { t } = useTranslation();
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await signIn(email.trim(), password, remember);
      navigate('/app/dashboard');
    } catch {
      setError(t('auth.invalidCredentials'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <div className="login-hero-badge">
          <span className="sidebar-brand-mark">H</span> HotelOS
        </div>
        <h2>{t('tagline')}</h2>
        <p>{t('auth.subtitle')}</p>
        <div className="login-hero-dots"><span /><span /><span /></div>
      </div>

      <div className="login-panel">
        <div className="login-lang"><LanguageSwitcher /></div>
        <h1>{t('auth.title')}</h1>
        <p>{t('auth.subtitle')}</p>

        <form className="login-form" onSubmit={submit}>
          {error && <div className="login-error" role="alert">{error}</div>}
          <Field label={t('auth.email')}>
            <input
              className="input"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@hotel.com"
              data-testid="login-email"
            />
          </Field>
          <Field label={t('auth.password')}>
            <div style={{ position: 'relative' }}>
              <input
                className="input"
                type={showPwd ? 'text' : 'password'}
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ paddingInlineEnd: 40 }}
                data-testid="login-password"
              />
              <button
                type="button"
                className="btn btn-ghost btn-sm btn-icon"
                style={{ position: 'absolute', insetBlockStart: 4, insetInlineEnd: 4 }}
                onClick={() => setShowPwd((s) => !s)}
                aria-label={showPwd ? t('auth.hidePassword') : t('auth.showPassword')}
                title={showPwd ? t('auth.hidePassword') : t('auth.showPassword')}
              >
                <IconEye />
              </button>
            </div>
          </Field>
          <div className="login-meta">
            <label className="checkbox-row">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              {t('auth.rememberMe')}
            </label>
            <button type="button" onClick={() => { setForgotOpen(true); setForgotSent(false); }}>{t('auth.forgotPassword')}</button>
          </div>
          <Button variant="primary" loading={loading} type="submit" style={{ paddingBlock: 10 }} data-testid="login-submit">
            {loading ? t('auth.signingIn') : t('auth.signIn')}
          </Button>
        </form>

        {DATA_SOURCE !== 'supabase' && (
        <div className="login-demo">
          <strong>{t('auth.demoHint')}</strong>
          <code>owner@hotelos.demo · manager@hotelos.demo · reception@hotelos.demo</code>
          <code>housekeep@hotelos.demo · accounting@hotelos.demo</code>
          <code>{t('auth.demoAccounts')}</code>
        </div>
        )}
      </div>

      {forgotOpen && (
        <Modal
          title={t('auth.forgotTitle')}
          onClose={() => setForgotOpen(false)}
          footer={
            <>
              <Button onClick={() => setForgotOpen(false)}>{t('common.cancel')}</Button>
              <Button
                variant="primary"
                loading={forgotLoading}
                disabled={!forgotEmail.includes('@') || forgotLoading}
                onClick={async () => {
                  setForgotLoading(true);
                  setForgotError(null);
                  try {
                    await requestPasswordReset(forgotEmail);
                    setForgotSent(true);
                  } catch (e) {
                    console.error('[HotelOS] Password reset UI error:', e);
                    if (e instanceof HotelError) {
                      if (e.code === 'supabase_not_configured') {
                        setForgotError(t('errors.supabase_not_configured'));
                      } else if (e.code === 'rate_limited') {
                        setForgotError(t('errors.rate_limited'));
                      } else if (e.code === 'invalid_request') {
                        setForgotError(t('auth.forgotError') + ' ' + String(e.message || ''));
                      } else {
                        setForgotError(t('auth.forgotError'));
                      }
                    } else {
                      setForgotError(t('auth.forgotError'));
                    }
                  } finally {
                    setForgotLoading(false);
                  }
                }}
              >
                {forgotLoading ? t('auth.forgotSending') : t('auth.forgotSubmit')}
              </Button>
            </>
          }
        >
          {forgotSent ? (
            <p>{t('auth.forgotSuccess')}</p>
          ) : (

            <div className="stack" style={{ gap: 12 }}>
              <p className="muted">{t('auth.forgotDescription')}</p>
              {forgotError && <div className="login-error" role="alert">{forgotError}</div>}
              <Field label={t('auth.email')}>
                <input className="input" type="email" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} />
              </Field>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}
