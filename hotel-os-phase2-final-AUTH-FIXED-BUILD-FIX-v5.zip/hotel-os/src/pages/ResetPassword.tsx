import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { Button, Field, LanguageSwitcher } from '@/components/ui';
import { IconEye } from '@/components/icons';
import { supabase } from '@/lib/supabase';
import { updatePassword } from '@/services/authService';

export default function ResetPassword() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [ready, setReady] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    if (!supabase) {
      setChecking(false);
      setError(t('auth.resetUnavailable'));
      return;
    }

    // A recovery email normally establishes a temporary session from the
    // URL fragment. Listen for PASSWORD_RECOVERY and also check the current
    // session so this page works after a refresh.
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      if (event === 'PASSWORD_RECOVERY' || session) {
        setReady(true);
        setError(null);
      }
      setChecking(false);
    });

    supabase.auth.getSession()
      .then(({ data: sessionData }) => {
        if (!mounted) return;
        if (sessionData.session) {
          setReady(true);
          setError(null);
        }
      })
      .catch(() => undefined)
      .finally(() => {
        if (mounted) setChecking(false);
      });

    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, [t]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError(t('auth.resetPasswordTooShort'));
      return;
    }
    if (password !== confirmation) {
      setError(t('auth.resetPasswordMismatch'));
      return;
    }

    setLoading(true);
    try {
      await updatePassword(password);
      setSuccess(true);
      // The recovery session remains valid until Supabase clears it.
      // Sign out before returning to login so the user must authenticate
      // with the newly chosen password.
      await supabase?.auth.signOut();
    } catch {
      setError(t('auth.resetError'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <div className="login-hero-badge">
          <span className="sidebar-brand-mark">H</span> HotelOS
        </div>
        <h2>{t('tagline')}</h2>
        <p>{t('auth.subtitle')}</p>
        <div className="login-hero-dots"><span /><span /><span /></div>
      </div>

      <div className="login-panel">
        <div className="login-lang"><LanguageSwitcher /></div>

        {!success ? (
          <>
            <h1>{t('auth.resetTitle')}</h1>
            <p>{t('auth.resetDescription')}</p>

            {checking && <div className="muted">{t('auth.resetChecking')}</div>}

            {!checking && !ready && (
              <div className="login-error" role="alert">
                {error || t('auth.resetInvalidLink')}
              </div>
            )}

            {!checking && ready && (
              <form className="login-form" onSubmit={submit}>
                {error && <div className="login-error" role="alert">{error}</div>}

                <Field label={t('auth.newPassword')}>
                  <div style={{ position: 'relative' }}>
                    <input
                      className="input"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="new-password"
                      minLength={8}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      style={{ paddingInlineEnd: 40 }}
                    />
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm btn-icon"
                      style={{ position: 'absolute', insetBlockStart: 4, insetInlineEnd: 4 }}
                      onClick={() => setShowPassword((v) => !v)}
                      aria-label={showPassword ? t('auth.hidePassword') : t('auth.showPassword')}
                    >
                      <IconEye />
                    </button>
                  </div>
                </Field>

                <Field label={t('auth.confirmPassword')}>
                  <div style={{ position: 'relative' }}>
                    <input
                      className="input"
                      type={showConfirmation ? 'text' : 'password'}
                      autoComplete="new-password"
                      minLength={8}
                      required
                      value={confirmation}
                      onChange={(e) => setConfirmation(e.target.value)}
                      style={{ paddingInlineEnd: 40 }}
                    />
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm btn-icon"
                      style={{ position: 'absolute', insetBlockStart: 4, insetInlineEnd: 4 }}
                      onClick={() => setShowConfirmation((v) => !v)}
                      aria-label={showConfirmation ? t('auth.hidePassword') : t('auth.showPassword')}
                    >
                      <IconEye />
                    </button>
                  </div>
                </Field>

                <Button variant="primary" loading={loading} type="submit" style={{ paddingBlock: 10 }}>
                  {loading ? t('auth.resetSaving') : t('auth.resetSave')}
                </Button>
              </form>
            )}

            <button
              type="button"
              className="btn btn-ghost"
              style={{ marginTop: 12, width: '100%' }}
              onClick={() => navigate('/login')}
            >
              {t('auth.backToLogin')}
            </button>
          </>
        ) : (
          <>
            <h1>{t('auth.resetSuccessTitle')}</h1>
            <p>{t('auth.resetSuccess')}</p>
            <Button
              variant="primary"
              style={{ marginTop: 16, width: '100%' }}
              onClick={() => navigate('/login', { replace: true })}
            >
              {t('auth.signIn')}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
