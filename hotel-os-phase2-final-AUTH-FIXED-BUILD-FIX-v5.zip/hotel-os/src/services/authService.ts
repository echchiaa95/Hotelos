// ── Authentication service ────────────────────────────────────
// The UI only talks to the AuthAdapter interface. Two adapters:
//
//   mock     → demo login against the in-memory users table
//   supabase → Supabase Auth (signInWithPassword / signOut /
//              getSession / onAuthStateChange) + profile loading
//
// Selected by VITE_DATA_SOURCE. After a Supabase login the adapter
// loads the matching `profiles` row and verifies it is active; the
// profile (with hotel_id and role) is what the rest of the app
// consumes through AuthContext.

import type { Profile } from '@/types';
import { HotelError } from '@/types';
import { DATA_SOURCE } from '@/lib/env';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { guard, mapAuthError } from '@/lib/errors';
import { mapProfile } from '@/lib/mappers';
import { userRepository, hotelRepository } from '@/repositories';

export interface Session {
  user: Profile;
  remember: boolean;
}

export interface AuthAdapter {
  signIn(email: string, password: string, remember: boolean): Promise<Profile>;
  signOut(): Promise<void>;
  getSession(): Promise<Profile | null>;
  /** Supabase only: fires on sign-in / sign-out / token refresh. */
  onAuthStateChange?(cb: (user: Profile | null) => void): { unsubscribe: () => void } | undefined;
}

/* ── Mock adapter (demo mode, unchanged behavior) ── */
const DEMO_PASSWORD = 'demo123';
const STORAGE_KEY = 'hotelos.session';

const mockAuthAdapter: AuthAdapter = {
  async signIn(email, password, remember) {
    await new Promise((r) => setTimeout(r, 700));
    const profile = await userRepository.getByEmail(email);
    if (!profile || !profile.active || password !== DEMO_PASSWORD) {
      throw new HotelError('invalid_credentials');
    }
    const session: Session = { user: profile, remember };
    (remember ? localStorage : sessionStorage).setItem(STORAGE_KEY, JSON.stringify(session));
    return profile;
  },
  async signOut() {
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
  },
  async getSession() {
    const raw = localStorage.getItem(STORAGE_KEY) ?? sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    try {
      return (JSON.parse(raw) as Session).user ?? null;
    } catch {
      return null;
    }
  },
};

/* ── Supabase adapter ── */
async function loadProfile(authUserId: string): Promise<Profile> {
  if (!supabase || !isSupabaseConfigured) {
    throw new HotelError('supabase_not_configured');
  }
  const { data: profileRow, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', authUserId)
    .maybeSingle();
  if (error) {
    await guard(Promise.reject(error));
    throw new HotelError('generic');
  }
  if (!profileRow) {
    throw new HotelError('missing_profile');
  }
  const profile = mapProfile(profileRow);
  if (!profile.active) {
    throw new HotelError('inactive_profile');
  }
  // Multi-tenancy anchor: the hotel must exist and be reachable.
  const hotel = await hotelRepository.getById(profile.hotelId);
  if (!hotel) {
    throw new HotelError('not_found');
  }
  return profile;
}

const supabaseAuthAdapter: AuthAdapter = {
  async signIn(email, password) {
    if (!supabase || !isSupabaseConfigured) {
      throw new HotelError('supabase_not_configured');
    }
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data.user) {
      throw mapAuthError(error ?? new Error('invalid credentials'));
    }
    return loadProfile(data.user.id);
  },
  async signOut() {
    if (!supabase) return;
    await guard(supabase.auth.signOut());
  },
  async getSession() {
    if (!supabase || !isSupabaseConfigured) return null;
    const { data } = await supabase.auth.getSession();
    if (!data.session?.user) return null;
    try {
      return await loadProfile(data.session.user.id);
    } catch (e) {
      // Token exists but the profile is gone/inactive — treat as logged out.
      if (e instanceof HotelError && (e.code === 'missing_profile' || e.code === 'inactive_profile')) {
        await supabase.auth.signOut().catch(() => undefined);
        return null;
      }
      throw e;
    }
  },
  onAuthStateChange(cb) {
    if (!supabase) return undefined;
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session?.user) {
        cb(null);
        return;
      }
      loadProfile(session.user.id)
        .then((p) => cb(p))
        .catch(() => cb(null));
    });
    return data.subscription;
  },
};


/** Build an absolute recovery URL that respects the Vite/GitHub Pages base path. */
export function getPasswordResetRedirectUrl(): string {
  // Always use the deployed GitHub Pages URL in production. This prevents
  // password-recovery emails from accidentally pointing to localhost.
  const configured = String(import.meta.env.VITE_AUTH_REDIRECT_URL || '').trim();
  if (configured) return configured;

  if (window.location.hostname === 'echchiaa95.github.io') {
    return 'https://echchiaa95.github.io/Hotelos/reset-password';
  }

  const basePath = String(import.meta.env.VITE_BASE_PATH || '/')
    .replace(/^\/?/, '/')
    .replace(/(?<!\/)$/, '/');
  return new URL(`${basePath}reset-password`, window.location.origin).toString();
}

/** Send a Supabase Auth password-recovery email. */
export async function requestPasswordReset(email: string): Promise<void> {
  if (DATA_SOURCE !== 'supabase' || !supabase || !isSupabaseConfigured) {
    // Password recovery is a real Supabase operation only in production mode.
    throw new HotelError('supabase_not_configured');
  }

  const redirectTo = getPasswordResetRedirectUrl();
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo,
    });

    console.info('[HotelOS] Password reset request completed:', {
      ok: !error,
      status: error?.status,
      code: error?.code,
      redirectTo,
    });

    if (error) {
      console.error('[HotelOS] Password reset request failed:', {
        message: error.message,
        status: error.status,
        code: error.code,
        redirectTo,
      });
      throw mapAuthError(error);
    }
  } catch (error) {
    // Preserve our normalized HotelError. Network/Auth exceptions are mapped
    // so the UI never confuses a real Supabase response with missing config.
    if (error instanceof HotelError) throw error;
    console.error('[HotelOS] Password reset transport error:', error);
    throw mapAuthError(error);
  }
}

/** Update the password after Supabase has established a recovery session. */
export async function updatePassword(password: string): Promise<void> {
  if (DATA_SOURCE !== 'supabase' || !supabase || !isSupabaseConfigured) {
    throw new HotelError('supabase_not_configured');
  }

  const { error } = await supabase.auth.updateUser({ password });
  if (error) throw mapAuthError(error);
}

export const authService: AuthAdapter =
  DATA_SOURCE === 'supabase' ? supabaseAuthAdapter : mockAuthAdapter;
