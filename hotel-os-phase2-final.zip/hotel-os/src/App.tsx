import React, { Suspense, lazy } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import AppLayout from './layouts/AppLayout';
import ErrorBoundary from './components/ErrorBoundary';
import { LoadingBlock } from './components/ui';
import Login from './pages/Login';

const Dashboard = lazy(() => import('./pages/Dashboard'));
const Reservations = lazy(() => import('./pages/Reservations'));
const Calendar = lazy(() => import('./pages/Calendar'));
const Rooms = lazy(() => import('./pages/Rooms'));
const RoomTypes = lazy(() => import('./pages/RoomTypes'));
const Guests = lazy(() => import('./pages/Guests'));
const CheckIn = lazy(() => import('./pages/CheckIn'));
const CheckOut = lazy(() => import('./pages/CheckOut'));
const Housekeeping = lazy(() => import('./pages/Housekeeping'));
const Payments = lazy(() => import('./pages/Payments'));
const Services = lazy(() => import('./pages/Services'));
const Reports = lazy(() => import('./pages/Reports'));
const Users = lazy(() => import('./pages/Users'));
const Settings = lazy(() => import('./pages/Settings'));
const Integrations = lazy(() => import('./pages/Integrations'));
const BookingPortal = lazy(() => import('./pages/BookingPortal'));

function RequireAuth({ children }: { children: React.ReactElement }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <LoadingBlock />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  return children;
}

export default function App() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingBlock />}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/book/:hotelSlug" element={<BookingPortal />} />
          <Route
            path="/app"
            element={
              <RequireAuth>
                <AppLayout />
              </RequireAuth>
            }
          >
            <Route index element={<Navigate to="/app/dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="reservations" element={<Reservations />} />
            <Route path="calendar" element={<Calendar />} />
            <Route path="rooms" element={<Rooms />} />
            <Route path="room-types" element={<RoomTypes />} />
            <Route path="guests" element={<Guests />} />
            <Route path="check-in" element={<CheckIn />} />
            <Route path="check-out" element={<CheckOut />} />
            <Route path="housekeeping" element={<Housekeeping />} />
            <Route path="payments" element={<Payments />} />
            <Route path="services" element={<Services />} />
            <Route path="reports" element={<Reports />} />
            <Route path="users" element={<Users />} />
            <Route path="settings" element={<Settings />} />
            <Route path="integrations" element={<Integrations />} />
          </Route>
          <Route path="*" element={<Navigate to="/app/dashboard" replace />} />
        </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}
