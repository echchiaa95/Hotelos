import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from '@/i18n';

export interface PaletteItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  run: () => void;
}

interface Props {
  open: boolean;
  onClose: () => void;
  items: PaletteItem[];
  /** Called with the typed text when the user picks "search reservations". */
  onSearch: (q: string) => void;
}

/** Ctrl/⌘+K quick navigation + reservation search. */
export default function CommandPalette({ open, onClose, items, onSearch }: Props) {
  const { t } = useTranslation();
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ('');
      setActive(0);
      window.setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [open]);

  const rows = useMemo<PaletteItem[]>(() => {
    const n = q.trim().toLowerCase();
    const list = n ? items.filter((x) => x.label.toLowerCase().includes(n)) : items;
    return n
      ? [...list, { id: '__search', label: `${t('common.search')}: ${q.trim()}`, run: () => onSearch(q.trim()) }]
      : list;
  }, [q, items, onSearch, t]);

  if (!open) return null;

  const pick = (r?: PaletteItem) => {
    if (!r) return;
    onClose();
    r.run();
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
    else if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => Math.min(a + 1, rows.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter') { e.preventDefault(); pick(rows[active]); }
  };

  return (
    <div className="palette-backdrop" onMouseDown={onClose}>
      <div className="palette" role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
        <input
          ref={inputRef}
          className="palette-input"
          value={q}
          onChange={(e) => { setQ(e.target.value); setActive(0); }}
          onKeyDown={onKeyDown}
          placeholder={t('common.searchPlaceholder')}
          aria-label={t('common.search')}
        />
        <div className="palette-list" role="listbox">
          {rows.map((r, i) => (
            <button
              key={r.id}
              role="option"
              aria-selected={i === active}
              className={`palette-row ${i === active ? 'active' : ''}`}
              onMouseEnter={() => setActive(i)}
              onClick={() => pick(r)}
            >
              {r.icon}
              <span>{r.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
