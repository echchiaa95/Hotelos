import React from 'react';
import { useTranslation } from '@/i18n';
import { Button } from '@/components/ui';

interface Props {
  children: React.ReactNode;
}
interface State {
  error: Error | null;
  info: React.ErrorInfo | null;
}

/**
 * Production-safe error boundary. A crash in any page renders a useful
 * error screen (never a blank white page) with Retry + Go to Dashboard.
 * The actual error message is only shown in development, inside a
 * collapsible <details> section.
 */
export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null, info: null };

  static getDerivedStateFromError(error: Error): State {
    return { error, info: null };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    this.setState({ info });
    // eslint-disable-next-line no-console
    console.error('[HotelOS] Uncaught render error:', error, info);
  }

  render() {
    if (this.state.error) {
      return <ErrorScreen error={this.state.error} info={this.state.info} />;
    }
    return this.props.children;
  }
}

function ErrorScreen({ error, info }: { error: Error; info: React.ErrorInfo | null }) {
  const { t } = useTranslationSafe();
  const isDev = import.meta.env.DEV;
  return (
    <div className="state-block error" style={{ padding: 60, maxWidth: 560, margin: '60px auto' }}>
      <span className="icon" aria-hidden>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" width="26" height="26">
          <path d="M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
        </svg>
      </span>
      <h4>{t('common.errorTitle')}</h4>
      <p>{t('errors.generic')}</p>
      <div className="flex" style={{ gap: 10, marginBlockStart: 14 }}>
        <Button
          variant="primary"
          onClick={() => window.location.assign(`${import.meta.env.VITE_BASE_PATH || ''}/app/dashboard`)}
        >
          {t('dashboard.title')}
        </Button>
        <Button onClick={() => window.location.reload()}>{t('common.search') === 'Search' ? 'Retry' : t('common.search')}</Button>
      </div>
      {isDev && (
        <details style={{ marginBlockStart: 18, textAlign: 'start', maxWidth: 480 }}>
          <summary className="muted small" style={{ cursor: 'pointer' }}>Error details (dev only)</summary>
          <pre className="small" style={{ whiteSpace: 'pre-wrap', color: 'var(--red)', marginBlockStart: 8 }}>
            {String(error?.stack || error?.message || error)}
            {info?.componentStack ? `\n${info.componentStack}` : ''}
          </pre>
        </details>
      )}
    </div>
  );
}

/** useTranslation may itself fail if the boundary sits above I18nProvider. */
function useTranslationSafe() {
  try {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return useTranslation();
  } catch {
    return {
      locale: 'fr' as const,
      dir: 'ltr' as const,
      setLocale: () => undefined,
      availableLocales: ['fr', 'ar', 'en'] as const,
      t: (key: string, vars?: Record<string, string | number>) => {
        const fallback: Record<string, string> = {
          'common.errorTitle': 'Something went wrong',
          'errors.generic': 'An unexpected error occurred. Please try again.',
          'dashboard.title': 'Dashboard',
          'common.search': 'Retry',
        };
        let s = fallback[key] ?? key;
        if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, String(v));
        return s;
      },
    };
  }
}
