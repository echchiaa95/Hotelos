import React from 'react';
import { useTranslation } from '@/i18n';
import { formatDateShort } from '@/utils/format';

/* Lightweight dependency-free SVG charts (no heavy chart lib —
   keeps the GitHub Pages bundle small). */

const COLORS = ['#0f766e', '#2563eb', '#7c3aed', '#b45309', '#15803d', '#be185d', '#475569', '#0891b2'];

export function LineChart({ data, height = 180, formatValue }: {
  data: { label: string; value: number }[];
  height?: number;
  formatValue?: (v: number) => string;
}) {
  const { locale } = useTranslation();
  if (data.length === 0) return null;
  const w = 560;
  const h = height;
  const pad = { top: 12, bottom: 22, left: 8, right: 8 };
  const max = Math.max(...data.map((d) => d.value), 1);
  const innerW = w - pad.left - pad.right;
  const innerH = h - pad.top - pad.bottom;
  const x = (i: number) => pad.left + (i / Math.max(1, data.length - 1)) * innerW;
  const y = (v: number) => pad.top + innerH - (v / max) * innerH;
  const points = data.map((d, i) => `${x(i)},${y(d.value)}`).join(' ');
  const area = `${pad.left},${pad.top + innerH} ${points} ${pad.left + innerW},${pad.top + innerH}`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 'auto' }} role="img" aria-label="chart">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0f766e" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#0f766e" stopOpacity="0.02" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((f) => (
        <line key={f} x1={pad.left} x2={w - pad.right} y1={pad.top + innerH * f} y2={pad.top + innerH * f} stroke="#eceff3" strokeWidth="1" />
      ))}
      <polygon points={area} fill="url(#lg)" />
      <polyline points={points} fill="none" stroke="#0f766e" strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
      {data.map((d, i) => (
        <g key={i}>
          <circle cx={x(i)} cy={y(d.value)} r="2.6" fill="#0f766e" />
          <title>{`${d.label}: ${formatValue ? formatValue(d.value) : d.value}`}</title>
        </g>
      ))}
      {data.map((d, i) =>
        i % Math.ceil(data.length / 7) === 0 ? (
          <text key={`t${i}`} x={x(i)} y={h - 6} fontSize="9" fill="#8a94a1" textAnchor="middle">
            {d.label}
          </text>
        ) : null,
      )}
    </svg>
  );
}

export function BarChart({ data, height = 180, formatValue }: {
  data: { label: string; value: number }[];
  height?: number;
  formatValue?: (v: number) => string;
}) {
  if (data.length === 0) return null;
  const w = 560;
  const h = height;
  const pad = { top: 14, bottom: 22, left: 8, right: 8 };
  const max = Math.max(...data.map((d) => d.value), 1);
  const innerW = w - pad.left - pad.right;
  const innerH = h - pad.top - pad.bottom;
  const bw = Math.min(34, (innerW / data.length) * 0.6);

  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 'auto' }} role="img" aria-label="chart">
      {[0.25, 0.5, 0.75].map((f) => (
        <line key={f} x1={pad.left} x2={w - pad.right} y1={pad.top + innerH * f} y2={pad.top + innerH * f} stroke="#eceff3" strokeWidth="1" />
      ))}
      {data.map((d, i) => {
        const cx = pad.left + ((i + 0.5) / data.length) * innerW;
        const bh = (d.value / max) * innerH;
        return (
          <g key={i}>
            <rect x={cx - bw / 2} y={pad.top + innerH - bh} width={bw} height={Math.max(2, bh)} rx="4" fill="#2563eb" opacity="0.9" />
            <text x={cx} y={h - 6} fontSize="9" fill="#8a94a1" textAnchor="middle">{d.label}</text>
            <title>{`${d.label}: ${formatValue ? formatValue(d.value) : d.value}`}</title>
          </g>
        );
      })}
    </svg>
  );
}

export function DonutChart({ data, size = 170 }: {
  data: { label: string; value: number }[];
  size?: number;
}) {
  const { locale } = useTranslation();
  const total = data.reduce((s, d) => s + d.value, 0);
  if (total === 0) return null;
  const r = 62;
  const cx = size / 2;
  const stroke = 22;
  let acc = 0;

  return (
    <div className="flex" style={{ gap: 18, flexWrap: 'wrap' }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="chart">
        <circle cx={cx} cy={cx} r={r} fill="none" stroke="#eef1f4" strokeWidth={stroke} />
        {data.map((d, i) => {
          const frac = d.value / total;
          const dash = frac * 2 * Math.PI * r;
          const gap = 2 * Math.PI * r - dash;
          const rot = (acc / total) * 360 - 90;
          acc += d.value;
          return (
            <circle
              key={i}
              cx={cx} cy={cx} r={r}
              fill="none"
              stroke={COLORS[i % COLORS.length]}
              strokeWidth={stroke}
              strokeDasharray={`${Math.max(0, dash - 1.5)} ${gap + 1.5}`}
              transform={`rotate(${rot} ${cx} ${cx})`}
              strokeLinecap="butt"
            >
              <title>{`${d.label}: ${d.value}`}</title>
            </circle>
          );
        })}
        <text x={cx} y={cx - 2} textAnchor="middle" fontSize="22" fontWeight="800" fill="#16202e">{total}</text>
        <text x={cx} y={cx + 16} textAnchor="middle" fontSize="9.5" fill="#8a94a1">total</text>
      </svg>
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 6, alignContent: 'center' }}>
        {data.map((d, i) => (
          <li key={i} className="flex" style={{ fontSize: 12.5, gap: 8 }}>
            <span style={{ width: 10, height: 10, borderRadius: 3, background: COLORS[i % COLORS.length], flexShrink: 0 }} />
            <span>{d.label}</span>
            <strong style={{ marginInlineStart: 'auto' }}>{d.value}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Convert day points → chart points with localized short dates. */
export function dayPoints(points: { date: string; value: number }[], locale: 'fr' | 'ar' | 'en') {
  return points.map((p) => ({ label: formatDateShort(p.date, locale), value: p.value }));
}
