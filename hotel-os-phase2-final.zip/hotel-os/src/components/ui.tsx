import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useTranslation } from '@/i18n';
import type { RoomStatus, ReservationStatus, PaymentStatus, HousekeepingStatus } from '@/types';

/* ── Button ── */
interface BtnProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'danger' | 'ghost';
  size?: 'sm' | 'md';
  loading?: boolean;
}
export function Button({ variant = 'outline', size = 'md', loading, children, disabled, className = '', ...rest }: BtnProps) {
  return (
    <button className={`btn btn-${variant} ${size === 'sm' ? 'btn-sm' : ''} ${className}`} disabled={disabled || loading} {...rest}>
      {loading && <span className="spinner" aria-hidden />}
      {children}
    </button>
  );
}

/* ── Badge ── */
type BadgeStatus = RoomStatus | ReservationStatus | PaymentStatus | HousekeepingStatus;
export function Badge({ status, label }: { status: BadgeStatus | string; label: string }) {
  return (
    <span className={`badge ${status}`}>
      <span className="dot" aria-hidden />
      {label}
    </span>
  );
}

/* ── Card ── */
export function Card({ title, actions, children, pad = true, className = '' }: {
  title?: string; actions?: React.ReactNode; children: React.ReactNode; pad?: boolean; className?: string;
}) {
  return (
    <section className={`card ${className}`}>
      {title && (
        <header className="card-head">
          <h3>{title}</h3>
          {actions}
        </header>
      )}
      <div className={pad ? 'card-pad' : ''}>{children}</div>
    </section>
  );
}

/* ── Stat card ── */
export function StatCard({ label, value, foot, tone, bar, barColor }: {
  label: string; value: React.ReactNode; foot?: React.ReactNode; tone?: 'accent'; bar?: number; barColor?: string;
}) {
  return (
    <div className={`stat-card ${tone ?? ''} ${bar !== undefined ? 'bar' : ''}`}>
      <span className="label">{label}</span>
      <span className="value">{value}</span>
      {bar !== undefined && (
        <span className="mini-bar" aria-hidden>
          <span style={{ width: `${Math.min(100, bar)}%`, background: barColor ?? 'var(--accent)' }} />
        </span>
      )}
      {foot && <span className="foot">{foot}</span>}
    </div>
  );
}

/* ── Form field ── */
export function Field({ label, hint, error, children, full, required, optional }: {
  label?: string; hint?: string; error?: string | null; children: React.ReactNode; full?: boolean;
  required?: boolean; optional?: boolean;
}) {
  const { t } = useTranslation();
  return (
    <div className={`field ${full ? 'full' : ''}`}>
      {label && (
        <label>
          {label}
          {required && <span className="req" aria-hidden="true"> *</span>}
          {optional && <span className="opt"> ({t('common.optional')})</span>}
        </label>
      )}
      {children}
      {error ? <span className="field-error" role="alert">{error}</span> : hint ? <span className="hint">{hint}</span> : null}
    </div>
  );
}

/* ── Modal ── */
export function Modal({ title, onClose, children, footer, wide }: {
  title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean;
}) {
  const titleId = useRef(`modal-title-${Math.random().toString(36).slice(2, 8)}`).current;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <header className="modal-head">
          <h3 id={titleId}>{title}</h3>
          <button className="btn btn-ghost btn-sm btn-icon" onClick={onClose} aria-label="×">✕</button>
        </header>
        <div className="modal-body">{children}</div>
        {footer && <footer className="modal-foot">{footer}</footer>}
      </div>
    </div>
  );
}

/* ── Async states ── */
export function LoadingBlock({ label }: { label?: string }) {
  const { t } = useTranslation();
  return (
    <div className="state-block" role="status">
      <span className="spinner dark" aria-hidden />
      <p>{label ?? t('common.loading')}</p>
    </div>
  );
}

export function EmptyBlock({ title, subtitle }: { title?: string; subtitle?: string }) {
  const { t } = useTranslation();
  return (
    <div className="state-block">
      <span className="icon" aria-hidden>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M3 9h18M5 9V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v2M4 9v10h16V9M10 13h4" />
        </svg>
      </span>
      <h4>{title ?? t('common.emptyTitle')}</h4>
      {subtitle && <p>{subtitle}</p>}
    </div>
  );
}

export function ErrorBlock({ code, onRetry }: { code?: string | null; onRetry?: () => void }) {
  const { t } = useTranslation();
  return (
    <div className="state-block error">
      <span className="icon" aria-hidden>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
        </svg>
      </span>
      <h4>{t('common.errorTitle')}</h4>
      <p>{code ? t(`errors.${code}` as never) : t('errors.generic')}</p>
      {onRetry && <Button size="sm" onClick={onRetry}>{t('common.search') === 'Search' ? 'Retry' : t('common.search')}</Button>}
    </div>
  );
}

/* ── Confirm dialog ── */
export function ConfirmDialog({ title, message, onConfirm, onCancel, danger }: {
  title: string; message: string; onConfirm: () => void; onCancel: () => void; danger?: boolean;
}) {
  const { t } = useTranslation();
  return (
    <Modal
      title={title}
      onClose={onCancel}
      footer={
        <>
          <Button onClick={onCancel}>{t('common.cancel')}</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm}>{t('common.confirm')}</Button>
        </>
      }
    >
      <p className="muted">{message}</p>
    </Modal>
  );
}

/* ── Toasts ── */
interface Toast { id: number; kind: 'success' | 'error'; text: string; }
const ToastCtx = createContext<{ push: (kind: 'success' | 'error', text: string) => void } | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);
  const push = useCallback((kind: 'success' | 'error', text: string) => {
    const id = ++idRef.current;
    setToasts((ts) => [...ts, { id, kind, text }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 3800);
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="toast-wrap" aria-live="polite">
        {toasts.map((x) => (
          <div key={x.id} className={`toast ${x.kind}`}>
            {x.kind === 'success' ? <span className="tick">✓</span> : <span>✕</span>}
            <span>{x.text}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

/* ── Avatar ── */
export function Avatar({ name, color, size }: { name: string; color: string; size?: 'sm' | 'md' | 'lg' }) {
  const parts = name.trim().split(/\s+/);
  const ini = (parts[0]?.[0] ?? '') + (parts[1]?.[0] ?? '');
  return (
    <span className={`avatar ${size ?? ''}`} style={{ background: color }} aria-hidden>
      {ini.toUpperCase()}
    </span>
  );
}

/* ── Language switcher ── */
export function LanguageSwitcher({ compact }: { compact?: boolean }) {
  const { locale, setLocale, availableLocales, t } = useTranslation();
  return (
    <div className="seg" role="group" aria-label={t('common.language')}>
      {availableLocales.map((l) => (
        <button
          key={l}
          className={locale === l ? 'active' : ''}
          onClick={() => setLocale(l)}
          aria-pressed={locale === l}
        >
          {compact ? { fr: 'FR', ar: 'ع', en: 'EN' }[l] : { fr: 'FR', ar: 'العربية', en: 'EN' }[l]}
        </button>
      ))}
    </div>
  );
}
