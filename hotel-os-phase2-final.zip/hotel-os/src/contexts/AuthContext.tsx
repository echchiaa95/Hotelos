import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Profile } from '@/types';
import { authService } from '@/services/authService';

interface AuthContextValue {
  user: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string, remember: boolean) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    authService
      .getSession()
      .then((u) => { if (!cancelled) setUser(u); })
      .finally(() => { if (!cancelled) setLoading(false); });

    // Supabase mode: keep the UI in sync with token refresh / sign-out.
    const subscription = authService.onAuthStateChange?.((u) => {
      if (!cancelled) setUser(u);
    });
    return () => {
      cancelled = true;
      subscription?.unsubscribe();
    };
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      async signIn(email, password, remember) {
        const u = await authService.signIn(email, password, remember);
        setUser(u);
      },
      async signOut() {
        await authService.signOut();
        setUser(null);
      },
    }),
    [user, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
