import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Hotel, UUID } from '@/types';
import { hotelService } from '@/services/hotelService';
import { DATA_SOURCE } from '@/lib/env';
import { useAuth } from './AuthContext';

/**
 * Active-hotel context: every hotel-scoped query in the app is
 * executed against `hotel.id`. In production, RLS guarantees a
 * user can only read/write rows of hotels they belong to — the
 * frontend never trusts a `hotel_id` sent by the browser.
 */
interface HotelContextValue {
  hotels: Hotel[];
  hotel: Hotel | null;
  setHotelId: (id: UUID) => void;
  loading: boolean;
  reload: () => Promise<void>;
  updateHotel: (patch: Partial<Omit<Hotel, 'id'>>) => Promise<void>;
}

const HotelContext = createContext<HotelContextValue | null>(null);
const STORAGE_KEY = 'hotelos.hotelId';

export function HotelProvider({ children }: { children: React.ReactNode }) {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [hotelId, setHotelIdState] = useState<UUID | null>(localStorage.getItem(STORAGE_KEY));
  const [loading, setLoading] = useState(true);
  const { user, loading: authLoading } = useAuth();

  const load = async () => {
    setLoading(true);
    try {
      const list = await hotelService.list();
      setHotels(list);
      setHotelIdState((current) => {
        if (current && list.some((h) => h.id === current)) return current;
        return list[0]?.id ?? null;
      });
    } finally {
      setLoading(false);
    }
  };

  // Supabase mode: never query hotels before the user is authenticated —
  // hotel data lives behind RLS and an anonymous query would (correctly)
  // be denied. The public booking portal calls hotelService directly and
  // relies on the anon SELECT grant + public directory policy.
  const mayLoad = DATA_SOURCE !== 'supabase' || (!authLoading && !!user);

  useEffect(() => {
    if (mayLoad) load();
    else setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mayLoad]);

  const setHotelId = (id: UUID) => {
    setHotelIdState(id);
    localStorage.setItem(STORAGE_KEY, id);
  };

  const value = useMemo<HotelContextValue>(() => {
    const hotel = hotels.find((h) => h.id === hotelId) ?? null;
    return {
      hotels,
      hotel,
      setHotelId,
      loading,
      reload: load,
      async updateHotel(patch) {
        if (!hotel) return;
        await hotelService.update(hotel.id, patch);
        await load();
      },
    };
  }, [hotels, hotelId, loading]);

  return <HotelContext.Provider value={value}>{children}</HotelContext.Provider>;
}

export function useHotel() {
  const ctx = useContext(HotelContext);
  if (!ctx) throw new Error('useHotel must be used within HotelProvider');
  return ctx;
}
