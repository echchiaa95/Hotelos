import { useCallback, useEffect, useRef, useState } from 'react';
import type { AsyncState } from '@/types';
import { HotelError } from '@/types';

/**
 * Generic async data hook: every async operation in the UI goes
 * through loading → success | empty | error states.
 */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [state, setState] = useState<AsyncState<T>>({ status: 'loading', data: null, error: null });
  const fnRef = useRef(fn);
  fnRef.current = fn;

  // `run` has a STABLE identity (empty deps) so it can never become part
  // of a render loop; the effect below re-runs only when actual dep
  // VALUES change (React compares `deps` element-wise each render).
  const run = useCallback(async () => {
    setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const data = await fnRef.current();
      const empty = Array.isArray(data) && data.length === 0;
      setState({ status: empty ? 'empty' : 'success', data, error: null });
    } catch (e) {
      const code = e instanceof HotelError ? e.code : 'generic';
      setState({ status: 'error', data: null, error: code });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-run only when actual dep VALUES change (element-wise comparison).
  // Callers pass primitives / memoized objects, so identity is stable.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    run();
  }, deps);

  return { ...state, reload: run };
}

/** Wraps a mutation with pending / error feedback. */
export function useMutation<A extends unknown[]>(
  fn: (...args: A) => Promise<unknown>,
  onDone?: () => void,
) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const execute = useCallback(
    async (...args: A) => {
      setPending(true);
      setError(null);
      try {
        await fn(...args);
        onDone?.();
        return true;
      } catch (e) {
        setError(e instanceof HotelError ? e.code : 'generic');
        return false;
      } finally {
        setPending(false);
      }
    },
    [fn, onDone],
  );

  return { execute, pending, error, setError };
}
