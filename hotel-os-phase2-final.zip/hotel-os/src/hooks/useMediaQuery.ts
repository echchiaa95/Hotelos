import { useEffect, useState } from 'react';

/**
 * SSR-safe media query hook. `useIsMobile()` drives the intentional
 * mobile layouts (cards instead of tables, drawer nav, day-view
 * calendar) — the UI never "scales down" the desktop layout.
 */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.matchMedia(query).matches : false,
  );

  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = (e: MediaQueryListEvent) => setMatches(e.matches);
    setMatches(mql.matches);
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, [query]);

  return matches;
}

/** Mobile breakpoint: 320px – 767px */
export const useIsMobile = () => useMediaQuery('(max-width: 767px)');

/** Tablet breakpoint: 768px – 1023px */
export const useIsTablet = () => useMediaQuery('(min-width: 768px) and (max-width: 1023px)');
