import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Locale } from '@/types';
import { fr } from './locales/fr';
import { ar } from './locales/ar';
import { en } from './locales/en';

export type Messages = typeof fr;

const LOCALES: Record<Locale, Messages> = { fr, ar, en };

export const LOCALE_LABELS: Record<Locale, string> = { fr: 'FR', ar: 'العربية', en: 'EN' };
export const LOCALE_NAMES: Record<Locale, string> = { fr: 'Français', ar: 'العربية', en: 'English' };

function resolve(messages: Messages, path: string): string | undefined {
  let node: unknown = messages;
  for (const part of path.split('.')) {
    if (node && typeof node === 'object' && part in (node as Record<string, unknown>)) {
      node = (node as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }
  return typeof node === 'string' ? node : undefined;
}

interface I18nContextValue {
  locale: Locale;
  dir: 'ltr' | 'rtl';
  setLocale: (l: Locale) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
  availableLocales: Locale[];
}

const I18nContext = createContext<I18nContextValue | null>(null);

const STORAGE_KEY = 'hotelos.locale';

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored === 'fr' || stored === 'ar' || stored === 'en' ? stored : 'fr';
  });

  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
    localStorage.setItem(STORAGE_KEY, locale);
  }, [locale, dir]);

  const value = useMemo<I18nContextValue>(() => {
    const messages = LOCALES[locale];
    const t = (key: string, vars?: Record<string, string | number>): string => {
      let str = resolve(messages, key) ?? resolve(fr, key) ?? key;
      if (vars) {
        for (const [k, v] of Object.entries(vars)) {
          str = str.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
        }
      }
      return str;
    };
    return { locale, dir, setLocale: setLocaleState, t, availableLocales: ['fr', 'ar', 'en'] };
  }, [locale, dir]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useTranslation() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useTranslation must be used within I18nProvider');
  return ctx;
}
