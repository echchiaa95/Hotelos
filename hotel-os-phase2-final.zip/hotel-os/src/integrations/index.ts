// ── Channel registry ──────────────────────────────────────────
// Mock channel providers for demo mode. None of these claim a
// live connection to Booking.com / Expedia / Airbnb — the real
// sync runs server-side via Supabase Edge Functions later.

import type { ChannelProvider } from './types';

function mockProvider(
  id: string,
  name: string,
  color: string,
  descriptionKey: string,
  connected = false,
): ChannelProvider {
  const notReady = async (): Promise<never> => {
    throw new Error('integration_not_configured');
  };
  return {
    id, name, color, connected, descriptionKey,
    getReservations: notReady,
    getAvailability: notReady,
    updateAvailability: notReady,
    createReservation: notReady,
    cancelReservation: notReady,
  };
}

const providers: ChannelProvider[] = [
  mockProvider('direct', 'Direct', '#0f766e', 'integrations.directDesc', true),
  mockProvider('phone', 'Phone', '#0369a1', 'integrations.phoneDesc', true),
  mockProvider('whatsapp', 'WhatsApp', '#15803d', 'integrations.whatsappDesc'),
  mockProvider('booking_com', 'Booking.com', '#2563eb', 'integrations.bookingComDesc'),
  mockProvider('expedia', 'Expedia', '#b45309', 'integrations.expediaDesc'),
  mockProvider('airbnb', 'Airbnb', '#b91c1c', 'integrations.airbnbDesc'),
];

export const channelRegistry = {
  list: () => providers,
  get: (id: string) => providers.find((p) => p.id === id),
};

export type { ChannelProvider };
