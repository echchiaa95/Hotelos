// ── Channel provider interface ────────────────────────────────
// Every booking channel (Booking.com, Expedia, Airbnb, direct,
// phone, WhatsApp) implements this same contract. Mock versions
// live here for development; real implementations will run in
// Supabase Edge Functions (server-side) with provider API keys
// stored as encrypted secrets — never in the browser.

export interface ChannelProvider {
  id: string;
  name: string;
  color: string;
  connected: boolean;
  descriptionKey: string;
  getReservations(range: { from: string; to: string }): Promise<unknown[]>;
  getAvailability(range: { from: string; to: string }): Promise<unknown>;
  updateAvailability(): Promise<void>;
  createReservation(payload: unknown): Promise<unknown>;
  cancelReservation(externalId: string): Promise<void>;
}
