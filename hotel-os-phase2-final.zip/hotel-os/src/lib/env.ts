// ── Data source configuration ─────────────────────────────────
// `mock`    → in-memory demo repositories (default, works offline)
// `supabase`→ live Supabase project (RLS-protected, public key only)

export type DataSource = 'mock' | 'supabase';

const raw = (import.meta.env.VITE_DATA_SOURCE as string | undefined) ?? 'mock';

export const DATA_SOURCE: DataSource = raw === 'supabase' ? 'supabase' : 'mock';

export const isSupabaseMode = DATA_SOURCE === 'supabase';
