// ── Supabase client (architecture placeholder) ────────────────
// The browser client is created ONLY when public env vars exist.
// RLS remains the authorization layer: the frontend never sees
// the service-role key and never bypasses row-level policies.
//
// Future repositories (src/repositories/supabase/*) will use this
// client and map 1:1 to tables: hotels, profiles, room_types,
// rooms, guests, reservations, payments, services,
// reservation_services, housekeeping_tasks, room_status_history —
// plus the RPC `search_available_rooms` for availability.

import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabaseConfigured: boolean = Boolean(url && anonKey);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(url!, anonKey!)
  : null;
