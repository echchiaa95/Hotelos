// ── Mock database ─────────────────────────────────────────────
// In-memory demo dataset, isolated from any production data.
// Mirrors the future Supabase schema (hotels, profiles, room_types,
// rooms, guests, reservations, payments, services,
// reservation_services, housekeeping_tasks, room_status_history).
// All dates are generated relative to "today" so the demo always
// shows a living hotel: arrivals today, departures, active stays…

import type {
  Guest,
  Hotel,
  HousekeepingTask,
  HotelService,
  LocalizedText,
  Payment,
  Profile,
  Reservation,
  ReservationService,
  Room,
  RoomStatus,
  RoomStatusHistory,
  RoomType,
} from '@/types';
import { addDays, bookingReference, todayISO, uuid } from '@/utils/format';

function d(offset: number): string {
  return addDays(todayISO(), offset);
}

/** Local-time ISO timestamp (consistent with todayISO local-date semantics). */
function nowISO(): string {
  const n = new Date();
  const pad = (x: number) => String(x).padStart(2, '0');
  return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}T${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
}

export interface AppNotification {
  id: string;
  hotelId: string;
  title: LocalizedText;
  read: boolean;
  createdAt: string;
}

export interface MockDB {
  hotels: Hotel[];
  profiles: Profile[];
  roomTypes: RoomType[];
  rooms: Room[];
  guests: Guest[];
  reservations: Reservation[];
  payments: Payment[];
  services: HotelService[];
  reservationServices: ReservationService[];
  housekeepingTasks: HousekeepingTask[];
  roomStatusHistory: RoomStatusHistory[];
  notifications: AppNotification[];
}

const HID = '11111111-1111-4111-8111-111111111111';

function buildSeed(): MockDB {
  const hotels: Hotel[] = [
    {
      id: HID,
      name: 'Riad Atlas Palace',
      slug: 'riad-atlas-palace',
      logoUrl: null,
      coverUrl: null,
      address: '12 Rue de la Kasbah',
      city: 'Marrakech',
      country: 'Maroc',
      phone: '+212 5 24 00 00 00',
      email: 'contact@riadatlaspalace.ma',
      currency: 'MAD',
      timezone: 'Africa/Casablanca',
      defaultLanguage: 'fr',
      enabledLanguages: ['fr', 'ar', 'en'],
      checkInTime: '15:00',
      checkOutTime: '12:00',
      createdAt: d(-400),
    },
  ];

  const profiles: Profile[] = [
    { id: uuid(), hotelId: HID, email: 'owner@hotelos.demo', firstName: 'Yassine', lastName: 'El Amrani', role: 'owner', active: true, avatarColor: '#0f766e', createdAt: d(-400) },
    { id: uuid(), hotelId: HID, email: 'manager@hotelos.demo', firstName: 'Salma', lastName: 'Bennis', role: 'manager', active: true, avatarColor: '#7c3aed', createdAt: d(-380) },
    { id: uuid(), hotelId: HID, email: 'reception@hotelos.demo', firstName: 'Karim', lastName: 'Tazi', role: 'receptionist', active: true, avatarColor: '#b45309', createdAt: d(-350) },
    { id: uuid(), hotelId: HID, email: 'housekeep@hotelos.demo', firstName: 'Fatima', lastName: 'Zahra Alaoui', role: 'housekeeping', active: true, avatarColor: '#0369a1', createdAt: d(-350) },
    { id: uuid(), hotelId: HID, email: 'accounting@hotelos.demo', firstName: 'Omar', lastName: 'Chraibi', role: 'accountant', active: true, avatarColor: '#be185d', createdAt: d(-300) },
  ];
  const [owner, manager, receptionist, housekeeper] = profiles;

  const roomTypes: RoomType[] = [
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Chambre Simple', ar: 'غرفة فردية', en: 'Single Room' },
      description: {
        fr: 'Chambre cosy et lumineuse, idéale pour les voyageurs solitaires.',
        ar: 'غرفة مريحة ومشرقة، مثالية للمسافرين المنفردين.',
        en: 'A cosy, bright room, ideal for solo travellers.',
      },
      basePrice: 450, maxGuests: 1, beds: [{ type: 'single', count: 1 }], size: 18,
      amenities: ['wifi', 'tv', 'ac', 'shower', 'desk'], images: [], active: true, createdAt: d(-390),
    },
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Chambre Double', ar: 'غرفة مزدوجة', en: 'Double Room' },
      description: {
        fr: 'Chambre élégante avec lit queen-size, décorée dans un style moderne marocain.',
        ar: 'غرفة أنيقة مع سرير كوين، بأسلوب مغربي عصري.',
        en: 'Elegant room with a queen bed, decorated in a modern Moroccan style.',
      },
      basePrice: 650, maxGuests: 2, beds: [{ type: 'queen', count: 1 }], size: 22,
      amenities: ['wifi', 'tv', 'ac', 'shower', 'coffee', 'safe'], images: [], active: true, createdAt: d(-390),
    },
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Chambre Twin', ar: 'غرفة بسريرين', en: 'Twin Room' },
      description: {
        fr: 'Deux lits simples parfaits pour amis ou collègues.',
        ar: 'سريران مفردان مثاليان للأصدقاء أو الزملاء.',
        en: 'Two single beds, perfect for friends or colleagues.',
      },
      basePrice: 680, maxGuests: 2, beds: [{ type: 'twin', count: 2 }], size: 24,
      amenities: ['wifi', 'tv', 'ac', 'shower', 'desk', 'hairdryer'], images: [], active: true, createdAt: d(-390),
    },
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Chambre Familiale', ar: 'غرفة عائلية', en: 'Family Room' },
      description: {
        fr: 'Espace généreux pour toute la famille, avec coin salon.',
        ar: 'مساحة واسعة لكل العائلة، مع ركن للجلوس.',
        en: 'Generous space for the whole family, with a lounge corner.',
      },
      basePrice: 950, maxGuests: 4, beds: [{ type: 'double', count: 1 }, { type: 'single', count: 1 }], size: 32,
      amenities: ['wifi', 'tv', 'ac', 'shower', 'coffee', 'safe', 'balcony'], images: [], active: true, createdAt: d(-390),
    },
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Chambre Deluxe Vue Mer', ar: 'غرفة ديلوكس بإطلالة على البحر', en: 'Deluxe Sea View Room' },
      description: {
        fr: 'Chambre premium avec balcon et vue imprenable sur l’océan.',
        ar: 'غرفة فاخرة مع شرفة وإطلالة بانورامية على المحيط.',
        en: 'Premium room with a balcony and breathtaking ocean view.',
      },
      basePrice: 1100, maxGuests: 2, beds: [{ type: 'king', count: 1 }], size: 28,
      amenities: ['wifi', 'tv', 'ac', 'bathtub', 'minibar', 'safe', 'seaView', 'balcony', 'coffee'], images: [], active: true, createdAt: d(-385),
    },
    {
      id: uuid(), hotelId: HID,
      name: { fr: 'Suite Junior', ar: 'جناح جونيور', en: 'Junior Suite' },
      description: {
        fr: 'Suite spacieuse avec salon séparé et baignoire balnéo.',
        ar: 'جناح واسع مع صالون منفصل وحوض استحمام سبا.',
        en: 'Spacious suite with a separate lounge and spa bathtub.',
      },
      basePrice: 1400, maxGuests: 3, beds: [{ type: 'king', count: 1 }], size: 40,
      amenities: ['wifi', 'tv', 'ac', 'bathtub', 'minibar', 'safe', 'seaView', 'balcony', 'coffee', 'roomService'], images: [], active: true, createdAt: d(-385),
    },
  ];
  const [rtSingle, rtDouble, rtTwin, rtFamily, rtDeluxe, rtSuite] = roomTypes;

  const mkRoom = (number: string, floor: number, roomTypeId: string, status: RoomStatus, notes = ''): Room => ({
    id: uuid(), hotelId: HID, number, roomTypeId, floor, status, notes, createdAt: d(-390),
  });

  const rooms: Room[] = [
    mkRoom('101', 1, rtSingle.id, 'reserved'),
    mkRoom('102', 1, rtDouble.id, 'available'),
    mkRoom('103', 1, rtDouble.id, 'reserved'),
    mkRoom('104', 1, rtTwin.id, 'cleaning'),
    mkRoom('105', 1, rtSingle.id, 'maintenance', 'Fuite robinetterie salle de bain'),
    mkRoom('201', 1, rtDouble.id, 'available'),
    mkRoom('202', 2, rtTwin.id, 'occupied'),
    mkRoom('203', 2, rtFamily.id, 'cleaning'),
    mkRoom('204', 2, rtDouble.id, 'occupied'),
    mkRoom('205', 2, rtSingle.id, 'out_of_service', 'Rénovation prévue'),
    mkRoom('301', 3, rtDeluxe.id, 'available'),
    mkRoom('302', 3, rtSuite.id, 'occupied'),
    mkRoom('303', 3, rtDeluxe.id, 'occupied'),
    mkRoom('304', 3, rtFamily.id, 'reserved'),
  ];

  const g = (firstName: string, lastName: string, nationality: string, email: string, phone: string, extra: Partial<Guest> = {}): Guest => ({
    id: uuid(), hotelId: HID, firstName, lastName, email, phone, nationality,
    documentType: 'passport', documentNumber: '', dateOfBirth: null, notes: '', createdAt: d(-200),
    ...extra,
  });

  const guests: Guest[] = [
    g('Sofia', 'Martin', 'France', 'sofia.martin@email.com', '+33 6 12 34 56 78', { documentNumber: '15CV88231', dateOfBirth: '1988-04-12' }),
    g('Lucas', 'Moreau', 'France', 'lucas.moreau@email.com', '+33 7 98 76 54 32', { documentNumber: '16FD22014', dateOfBirth: '1990-11-03' }),
    g('Diego', 'Fernández', 'Espagne', 'diego.fernandez@email.com', '+34 612 34 56 78', { documentNumber: 'XKL442011', dateOfBirth: '1985-02-27' }),
    g('Emma', 'Johnson', 'Royaume-Uni', 'emma.j@email.com', '+44 7700 900123', { documentNumber: '533220188', dateOfBirth: '1992-07-19' }),
    g('Lena', 'Schmidt', 'Allemagne', 'lena.schmidt@email.com', '+49 151 23456789', { documentNumber: 'L01X00T44', dateOfBirth: '1987-09-30' }),
    g('Omar', 'Benjelloun', 'Maroc', 'omar.bj@email.com', '+212 6 61 23 45 67', { documentType: 'national_id', documentNumber: 'BK458231', dateOfBirth: '1991-01-15' }),
    g('Aiko', 'Tanaka', 'Japon', 'aiko.tanaka@email.com', '+81 90 1234 5678', { documentNumber: 'TR8811223', dateOfBirth: '1994-05-08' }),
    g('Marco', 'Rossi', 'Italie', 'marco.rossi@email.com', '+39 333 123 4567', { documentNumber: 'YA9920031', dateOfBirth: '1983-12-01' }),
    g('Fatima', 'Alaoui', 'Maroc', 'fatima.alaoui@email.com', '+212 6 62 34 56 78', { documentType: 'national_id', documentNumber: 'CD112340', dateOfBirth: '1996-03-22' }),
    g('Jack', 'Wilson', 'États-Unis', 'jack.wilson@email.com', '+1 415 555 0132', { documentNumber: 'X20019983', dateOfBirth: '1979-08-14' }),
    g('Clara', 'Dubois', 'France', 'clara.dubois@email.com', '+33 6 45 67 89 01', { documentNumber: '18GH33445', dateOfBirth: '1995-10-05' }),
  ];

  const reservations: Reservation[] = [];
  const payments: Payment[] = [];
  const reservationServices: ReservationService[] = [];

  const mkReservation = (
    checkIn: string, checkOut: string, guest: Guest, room: Room, status: Reservation['status'],
    source: Reservation['source'], opts: { nights?: number; paidRatio?: number; createdOffset?: number; requests?: string } = {},
  ): Reservation => {
    const rt = roomTypes.find((t) => t.id === room.roomTypeId)!;
    const nights = opts.nights ?? Math.max(1, Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000));
    const total = rt.basePrice * nights;
    const paid = Math.round(total * (opts.paidRatio ?? (status === 'checked_out' || status === 'checked_in' ? 1 : 0.3)));
    const r: Reservation = {
      id: uuid(), hotelId: HID, reference: bookingReference(), guestId: guest.id, roomId: room.id,
      checkIn, checkOut, adults: Math.min(2, rt.maxGuests), children: rt.maxGuests > 2 ? 1 : 0,
      status, source, totalAmount: total, paidAmount: paid, currency: 'MAD',
      specialRequests: opts.requests ?? '',
      createdAt: d(opts.createdOffset ?? -20), updatedAt: d(opts.createdOffset ?? -20),
    };
    reservations.push(r);
    if (paid > 0) {
      payments.push({
        id: uuid(), hotelId: HID, reservationId: r.id, amount: paid,
        method: source === 'booking_com' || source === 'expedia' || source === 'airbnb' ? 'online' : 'card',
        status: 'paid', transactionReference: `TX-${Math.floor(100000 + Math.random() * 899999)}`,
        notes: '', paidAt: d(opts.createdOffset ?? -20), createdAt: d(opts.createdOffset ?? -20),
      });
    }
    return r;
  };

  const roomByNumber = (n: string) => rooms.find((r) => r.number === n)!;

  // ── Historical stays (last 14 days) → feeds revenue/occupancy trends ──
  const histGuests = [guests[0], guests[2], guests[4], guests[6], guests[7], guests[9], guests[10], guests[1], guests[3], guests[5], guests[8]];
  const histRooms = ['102', '201', '301', '104', '203', '303', '204', '101', '304', '202', '302', '103', '105', '205'];
  const histSources: Reservation['source'][] = ['direct', 'booking_com', 'expedia', 'direct', 'airbnb', 'phone', 'booking_com', 'whatsapp', 'direct', 'expedia', 'booking_com', 'walk_in', 'direct', 'other'];
  for (let i = 0; i < 14; i++) {
    mkReservation(d(-i - 1), d(-i), histGuests[i % histGuests.length], roomByNumber(histRooms[i]), 'checked_out', histSources[i], { paidRatio: 1, createdOffset: -i - 8 });
  }
  // a few longer historical stays
  mkReservation(d(-9), d(-6), guests[1], roomByNumber('302'), 'checked_out', 'booking_com', { paidRatio: 1, createdOffset: -15 });
  mkReservation(d(-7), d(-4), guests[3], roomByNumber('203'), 'checked_out', 'airbnb', { paidRatio: 1, createdOffset: -12 });
  mkReservation(d(-5), d(-2), guests[5], roomByNumber('301'), 'checked_out', 'expedia', { paidRatio: 1, createdOffset: -10 });

  // ── Currently in-house ──
  mkReservation(d(-2), d(2), guests[6], roomByNumber('202'), 'checked_in', 'booking_com', { requests: 'Lit bébé si possible' });
  mkReservation(d(-1), d(3), guests[7], roomByNumber('303'), 'checked_in', 'direct', { paidRatio: 0.5 });
  mkReservation(d(-3), d(1), guests[8], roomByNumber('204'), 'checked_in', 'expedia');
  mkReservation(d(-1), d(4), guests[9], roomByNumber('302'), 'checked_in', 'direct', { paidRatio: 0.6, requests: 'Étage haut, calme' });

  // ── Arriving today ──
  mkReservation(d(0), d(2), guests[1], roomByNumber('103'), 'confirmed', 'direct', { paidRatio: 0.5, createdOffset: -4 });
  mkReservation(d(0), d(3), guests[2], roomByNumber('304'), 'confirmed', 'booking_com', { paidRatio: 1, createdOffset: -9 });
  mkReservation(d(0), d(1), guests[3], roomByNumber('101'), 'confirmed', 'walk_in', { createdOffset: 0, requests: 'Arrivée tardive après 21h' });

  // ── Upcoming ──
  mkReservation(d(1), d(3), guests[4], roomByNumber('201'), 'confirmed', 'whatsapp', { createdOffset: -2 });
  mkReservation(d(2), d(5), guests[5], roomByNumber('301'), 'confirmed', 'expedia', { createdOffset: -6 });
  mkReservation(d(3), d(6), guests[0], roomByNumber('303'), 'confirmed', 'direct', { paidRatio: 0.4, createdOffset: -3 });
  mkReservation(d(4), d(7), guests[10], roomByNumber('302'), 'confirmed', 'airbnb', { createdOffset: -5 });
  mkReservation(d(5), d(7), guests[6], roomByNumber('202'), 'pending', 'phone', { createdOffset: -1 });
  mkReservation(d(6), d(9), guests[7], roomByNumber('304'), 'pending', 'direct', { createdOffset: -1 });
  mkReservation(d(8), d(10), guests[8], roomByNumber('104'), 'cancelled', 'booking_com', { createdOffset: -11 });
  mkReservation(d(0), d(1), guests[10], roomByNumber('104'), 'no_show', 'phone', { createdOffset: -3 });

  // ── Reservation services attached to stays ──
  const services: HotelService[] = [
    { id: uuid(), hotelId: HID, name: { fr: 'Petit-déjeuner', ar: 'الفطور', en: 'Breakfast' }, description: { fr: 'Buffet continental servi de 7h à 10h30.', ar: 'بوفيه يقدم من 7 إلى 10:30.', en: 'Continental buffet served 7:00–10:30.' }, price: 80, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Room service', ar: 'خدمة الغرف', en: 'Room service' }, description: { fr: 'Plats servis en chambre 24h/24.', ar: 'أطباق تقدم في الغرفة على مدار الساعة.', en: 'Dishes served in room 24/7.' }, price: 120, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Blanchisserie', ar: 'خدمة الغسيل', en: 'Laundry' }, description: { fr: 'Service de blanchisserie express sous 24h.', ar: 'خدمة غسيل سريعة خلال 24 ساعة.', en: 'Express laundry service within 24h.' }, price: 60, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Transfert aéroport', ar: 'نقل من المطار', en: 'Airport transfer' }, description: { fr: 'Navette privée aéroport ⇄ hôtel.', ar: 'سيارة خاصة من وإلى المطار.', en: 'Private airport shuttle.' }, price: 250, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Lit d’appoint', ar: 'سرير إضافي', en: 'Extra bed' }, description: { fr: 'Lit pliant avec linge fourni.', ar: 'سرير قابل للطي مع ملاءات.', en: 'Folding bed with linen provided.' }, price: 150, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Dîner restaurant', ar: 'عشاء في المطعم', en: 'Restaurant dinner' }, description: { fr: 'Menu du soir en trois services.', ar: 'قائمة عشاء من ثلاثة أطباق.', en: 'Three-course dinner menu.' }, price: 180, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Accès Spa', ar: 'دخول السبا', en: 'Spa access' }, description: { fr: 'Hammam, sauna et massage 30 min.', ar: 'حمام وساونا ومساج 30 دقيقة.', en: 'Hammam, sauna and 30-min massage.' }, price: 300, active: true, createdAt: d(-390) },
    { id: uuid(), hotelId: HID, name: { fr: 'Late check-out', ar: 'مغادرة متأخرة', en: 'Late check-out' }, description: { fr: 'Départ tardif jusqu’à 16h.', ar: 'مغادرة متأخرة حتى الساعة 16:00.', en: 'Late departure until 4 pm.' }, price: 100, active: false, createdAt: d(-390) },
  ];

  const inHouse = reservations.filter((r) => r.status === 'checked_in');
  if (inHouse[0]) reservationServices.push({ id: uuid(), hotelId: HID, reservationId: inHouse[0].id, serviceId: services[0].id, quantity: 2, unitPrice: 80, notes: '', createdAt: d(-1) });
  if (inHouse[1]) reservationServices.push({ id: uuid(), hotelId: HID, reservationId: inHouse[1].id, serviceId: services[6].id, quantity: 1, unitPrice: 300, notes: '', createdAt: d(-1) });
  if (inHouse[1]) reservationServices.push({ id: uuid(), hotelId: HID, reservationId: inHouse[1].id, serviceId: services[1].id, quantity: 1, unitPrice: 120, notes: '', createdAt: d(0) });

  // ── Housekeeping tasks ──
  const housekeepingTasks: HousekeepingTask[] = [
    { id: uuid(), hotelId: HID, roomId: roomByNumber('104').id, assignedTo: housekeeper.id, taskType: 'cleaning', status: 'pending', notes: 'Chambre à refaire en priorité', completedAt: null, createdAt: d(0) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('203').id, assignedTo: housekeeper.id, taskType: 'cleaning', status: 'in_progress', notes: '', completedAt: null, createdAt: d(0) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('105').id, assignedTo: manager.id, taskType: 'maintenance', status: 'pending', notes: 'Réparer la fuite, vérifier joint baignoire', completedAt: null, createdAt: d(-1) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('304').id, assignedTo: housekeeper.id, taskType: 'inspection', status: 'pending', notes: 'Contrôle avant arrivée famille (3 enfants)', completedAt: null, createdAt: d(0) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('303').id, assignedTo: housekeeper.id, taskType: 'cleaning', status: 'completed', notes: '', completedAt: d(-1), createdAt: d(-2) },
  ];

  // ── Room status history ──
  const roomStatusHistory: RoomStatusHistory[] = [
    { id: uuid(), hotelId: HID, roomId: roomByNumber('203').id, fromStatus: 'occupied', toStatus: 'cleaning', changedBy: receptionist.id, reason: 'check-out', changedAt: d(-1) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('104').id, fromStatus: 'occupied', toStatus: 'cleaning', changedBy: receptionist.id, reason: 'check-out', changedAt: d(0) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('202').id, fromStatus: 'reserved', toStatus: 'occupied', changedBy: receptionist.id, reason: 'check-in', changedAt: d(-2) },
    { id: uuid(), hotelId: HID, roomId: roomByNumber('105').id, fromStatus: 'available', toStatus: 'maintenance', changedBy: manager.id, reason: 'fuite signalée', changedAt: d(-2) },
  ];

  // Payments collected today (keeps "today's revenue" realistic in the demo)
  payments.push(
    { id: uuid(), hotelId: HID, reservationId: reservations[reservations.length - 1].id, amount: 450, method: 'cash', status: 'paid', transactionReference: 'TX-778120', notes: 'Walk-in', paidAt: nowISO(), createdAt: nowISO() },
    { id: uuid(), hotelId: HID, reservationId: reservations[reservations.length - 2].id, amount: 1950, method: 'online', status: 'paid', transactionReference: 'TX-778121', notes: 'Booking.com virtual card', paidAt: nowISO(), createdAt: nowISO() },
  );

  const notifications: AppNotification[] = [
    { id: uuid(), hotelId: HID, title: { fr: 'Nouvelle réservation Booking.com — Ch. 304', ar: 'حجز جديد من Booking.com — غرفة 304', en: 'New Booking.com reservation — Room 304' }, read: false, createdAt: d(0) },
    { id: uuid(), hotelId: HID, title: { fr: '3 départs prévus aujourd’hui', ar: '3 مغادرات مجدولة اليوم', en: '3 departures scheduled today' }, read: false, createdAt: d(0) },
    { id: uuid(), hotelId: HID, title: { fr: 'Paiement en attente — HOS-2026 réservation téléphone', ar: 'دفعة معلقة — حجز هاتفي', en: 'Pending payment — phone reservation' }, read: true, createdAt: d(-1) },
    { id: uuid(), hotelId: HID, title: { fr: 'Chambre 105 signalée en maintenance', ar: 'تم الإبلاغ عن الصيانة في الغرفة 105', en: 'Room 105 reported for maintenance' }, read: true, createdAt: d(-2) },
  ];

  return {
    hotels, profiles, roomTypes, rooms, guests, reservations, payments,
    services, reservationServices, housekeepingTasks, roomStatusHistory, notifications,
  };
}

let state: MockDB = buildSeed();

export function getDB(): MockDB {
  return state;
}

/** Restore the demo dataset to its initial state. */
export function resetDb(): void {
  state = buildSeed();
}

export const DEMO_HOTEL_ID = HID;
