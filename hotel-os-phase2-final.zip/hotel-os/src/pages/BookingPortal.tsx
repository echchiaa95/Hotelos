import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { availabilityService, hotelService, publicBookingService } from '@/services';
import { Button, Field, LanguageSwitcher, useToast } from '@/components/ui';
import { addDays, formatMoney, nightsBetween, todayISO } from '@/utils/format';
import type { RoomTypeAvailability } from '@/types';

export default function BookingPortal() {
  const { t, locale } = useTranslation();
  const { hotelSlug } = useParams();
  const toast = useToast();
  const hotel = useAsync(() => (hotelSlug ? hotelService.getBySlug(hotelSlug) : Promise.resolve(null)), [hotelSlug]);

  const [q, setQ] = useState({ checkIn: todayISO(), checkOut: addDays(todayISO(), 2), guests: 2 });
  const [results, setResults] = useState<RoomTypeAvailability[] | null>(null);
  const [picked, setPicked] = useState<RoomTypeAvailability | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [g, setG] = useState({ firstName: '', lastName: '', email: '', phone: '', requests: '' });

  const search = useMutation(async () => {
    if (!hotel.data) return;
    const res = await availabilityService.search(hotel.data.id, q);
    setResults(res);
    setPicked(null);
  });

  const confirm = useMutation(async () => {
    if (!hotel.data || !picked) return;
    if (!g.firstName || !g.lastName || !g.email.includes('@')) {
      toast.push('error', t('portal.fillAllFields'));
      return;
    }
    const r = await publicBookingService.create({
      hotel: hotel.data,
      picked,
      checkIn: q.checkIn,
      checkOut: q.checkOut,
      guests: q.guests,
      firstName: g.firstName,
      lastName: g.lastName,
      email: g.email,
      phone: g.phone,
      requests: g.requests,
    });
    setDone(r.reference);
  });

  if (hotel.status === 'loading') {
    return <div className="portal" style={{ padding: 40, textAlign: 'center' }}>…</div>;
  }
  if (!hotel.data) {
    return <div className="portal" style={{ padding: 40, textAlign: 'center' }}>{t('portal.hotelNotFound')}</div>;
  }
  const h = hotel.data;
  const currency = h.currency;
  const nights = nightsBetween(q.checkIn, q.checkOut);

  return (
    <div className="portal">
      <div className="portal-hero">
        <div style={{ display: 'flex', justifyContent: 'flex-end', paddingInline: 16 }}>
          <LanguageSwitcher />
        </div>
        <h1>{h.name}</h1>
        <p>{t('portal.subtitle', { hotel: h.name })}</p>
      </div>
      <div className="portal-body">
        {done ? (
          <div className="card portal-confirm">
            <div className="check">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                <path d="M20 6 9 17l-5-5" />
              </svg>
            </div>
            <h2>{t('portal.confirmedTitle')}</h2>
            <p className="muted">{t('portal.confirmedText')}</p>
            <p style={{ fontSize: 20, fontWeight: 800, color: 'var(--accent)', marginBlock: 10 }}>{done}</p>
            <Button onClick={() => { setDone(null); setResults(null); }}>{t('portal.backToSearch')}</Button>
          </div>
        ) : (
          <>
            <div className="card card-pad">
              <h3 className="mb">{t('portal.searchTitle')}</h3>
              <div className="portal-search">
                <Field label={t('portal.checkIn')}>
                  <input className="input" type="date" min={todayISO()} value={q.checkIn} onChange={(e) => setQ({ ...q, checkIn: e.target.value })} />
                </Field>
                <Field label={t('portal.checkOut')}>
                  <input className="input" type="date" min={addDays(q.checkIn, 1)} value={q.checkOut} onChange={(e) => setQ({ ...q, checkOut: e.target.value })} />
                </Field>
                <Field label={t('portal.guests')}>
                  <input className="input" type="number" min={1} max={6} value={q.guests} onChange={(e) => setQ({ ...q, guests: Number(e.target.value) })} />
                </Field>
                <Button variant="primary" loading={search.pending} onClick={() => search.execute()} disabled={nights < 1}>
                  {t('portal.search')}
                </Button>
              </div>
            </div>

            {results !== null && (
              <>
                <h3>{t('portal.availableRooms')}</h3>
                {results.length === 0 && (
                  <div className="card card-pad"><p className="muted">{t('portal.noAvailability')}</p></div>
                )}
                {results.map((r) => (
                  <div key={r.roomType.id} className="card card-pad portal-card">
                    <div>
                      <strong style={{ fontSize: 16 }}>{r.roomType.name[locale]}</strong>
                      <p className="muted small" style={{ marginBlock: '4px 8px' }}>{r.roomType.description[locale]}</p>
                      <div className="amenity-chips">
                        {r.roomType.amenities.slice(0, 6).map((a) => (
                          <span key={a} className="amenity-chip">{t(`amenities.${a}` as never)}</span>
                        ))}
                      </div>
                      <p className="muted small mt">
                        {t('portal.maxGuests', { count: r.roomType.maxGuests })} · {r.availableRooms.length} {t('common.rooms')}
                      </p>
                    </div>
                    <div className="portal-price">
                      <div className="amount">{formatMoney(r.totalPrice, currency, locale)}</div>
                      <p className="muted small">
                        {formatMoney(r.roomType.basePrice, currency, locale)} {t('portal.perNight')} · {t('portal.priceFor', { nights: r.nights })}
                      </p>
                      <Button
                        variant={picked === r ? 'primary' : 'outline'}
                        size="sm"
                        style={{ marginBlockStart: 8 }}
                        onClick={() => setPicked(r)}
                      >
                        {picked === r ? t('portal.selected') : t('portal.select')}
                      </Button>
                    </div>
                  </div>
                ))}
              </>
            )}

            {picked && (
              <div className="card card-pad">
                <h3 className="mb">{t('portal.guestDetails')}</h3>
                <div className="form-grid">
                  <Field label={t('common.name')}><input className="input" value={g.firstName} onChange={(e) => setG({ ...g, firstName: e.target.value })} /></Field>
                  <Field label=" "><input className="input" value={g.lastName} onChange={(e) => setG({ ...g, lastName: e.target.value })} /></Field>
                  <Field label={t('common.email')}><input className="input" type="email" value={g.email} onChange={(e) => setG({ ...g, email: e.target.value })} /></Field>
                  <Field label={t('common.phone')}><input className="input" value={g.phone} onChange={(e) => setG({ ...g, phone: e.target.value })} /></Field>
                  <Field label={t('portal.specialRequests')} full>
                    <textarea className="textarea" value={g.requests} onChange={(e) => setG({ ...g, requests: e.target.value })} />
                  </Field>
                </div>
                <div className="flex-between mt">
                  <span className="muted small">{t('portal.freeCancellation')}</span>
                  <Button variant="primary" loading={confirm.pending} onClick={() => confirm.execute()}>
                    {t('portal.confirmReservation')} — {formatMoney(picked.totalPrice, currency, locale)}
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
        <p className="portal-foot">{t('portal.poweredBy')}</p>
      </div>
    </div>
  );
}
