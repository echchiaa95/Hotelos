import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync } from '@/hooks/useAsync';
import { guestService, reservationService, roomService } from '@/services';
import { Button, Card, LoadingBlock } from '@/components/ui';
import { addDays, formatDateShort, todayISO } from '@/utils/format';
import { useIsMobile } from '@/hooks/useMediaQuery';
import type { Reservation } from '@/types';

type View = 'day' | 'week' | 'month';

function toISO(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export default function Calendar() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const navigate = useNavigate();
  const hotelId = hotel?.id ?? '';
  const isMobile = useIsMobile();
  // Mobile defaults to Day view — dozens of date columns never fit a phone.
  const [view, setView] = useState<View>(isMobile ? 'day' : 'month');
  useEffect(() => setView((v) => v), [isMobile]); // keep user's choice after first render
  const [anchor, setAnchor] = useState(todayISO());
  const [roomFilter, setRoomFilter] = useState<string>('all');

  const days = view === 'day' ? 1 : view === 'week' ? 7 : 30;

  const start = useMemo(() => {
    const d = new Date(anchor + 'T12:00:00');
    if (view === 'week') {
      const dow = (d.getDay() + 6) % 7; // Monday-start week
      return addDays(toISO(d), -dow);
    }
    if (view === 'month') {
      return toISO(new Date(d.getFullYear(), d.getMonth(), 1));
    }
    return anchor;
  }, [anchor, view]);

  const dateCols = useMemo(() => Array.from({ length: days }, (_, i) => addDays(start, i)), [start, days]);

  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const reservations = useAsync(() => (hotelId ? reservationService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const visibleRooms = (rooms.data ?? []).filter((r) => roomFilter === 'all' || r.id === roomFilter);
  const guestName = (id: string) => {
    const g = guests.data?.find((x) => x.id === id);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };

  const blocksFor = (roomId: string): Reservation[] =>
    (reservations.data ?? []).filter(
      (r) =>
        r.roomId === roomId &&
        r.checkIn < addDays(start, days) &&
        r.checkOut > start &&
        r.status !== 'cancelled',
    );

  const move = (dir: 1 | -1) => {
    const step = view === 'day' ? 1 : view === 'week' ? 7 : 30;
    setAnchor(addDays(anchor, dir * step));
  };

  const dowFmt = new Intl.DateTimeFormat(locale === 'ar' ? 'ar-MA' : locale === 'fr' ? 'fr-FR' : 'en-US', { weekday: 'short' });

  if (rooms.status === 'loading') return <LoadingBlock />;

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('calendar.title')}</h1>
        </div>
        <div className="page-actions">
          <div className="seg" role="group" aria-label={t('calendar.title')}>
            {(['day', 'week', 'month'] as View[]).map((v) => (
              <button key={v} className={view === v ? 'active' : ''} onClick={() => setView(v)}>
                {t(`calendar.${v}`)}
              </button>
            ))}
          </div>
          <Button onClick={() => move(-1)}>‹</Button>
          <Button onClick={() => setAnchor(todayISO())}>{t('common.today')}</Button>
          <Button onClick={() => move(1)}>›</Button>
          <Button variant="primary" onClick={() => navigate('/app/reservations')}>+ {t('calendar.createHere')}</Button>
        </div>
      </div>

      <div className="toolbar">
        <select className="select" value={roomFilter} onChange={(e) => setRoomFilter(e.target.value)} aria-label={t('calendar.room')}>
          <option value="all">{t('common.all')}</option>
          {(rooms.data ?? []).map((r) => (
            <option key={r.id} value={r.id}>{t('common.room')} {r.number}</option>
          ))}
        </select>
      </div>

      <Card pad={false}>
        <div className="cal-scroll">
          <div className="cal-grid">
            <div className="cal-header-row">
              <div className="cal-room-cell">{t('calendar.room')}</div>
              <div className="cal-days">
                {dateCols.map((d) => (
                  <div key={d} className={`cal-day-cell ${d === todayISO() ? 'today' : ''}`}>
                    <div className="dow">{dowFmt.format(new Date(d + 'T12:00:00'))}</div>
                    {formatDateShort(d, locale)}
                  </div>
                ))}
              </div>
            </div>
            {visibleRooms.map((room) => (
              <div key={room.id} className="cal-row">
                <div className="cal-room-cell">
                  {room.number} <span className="floor">· {t('common.floor')} {room.floor}</span>
                </div>
                <div className="cal-lane">
                  <div className="lane-bg" aria-hidden>
                    {dateCols.map((d) => (
                      <span key={d} className={d === todayISO() ? 'today' : ''} />
                    ))}
                  </div>
                  {blocksFor(room.id).map((r) => {
                    const s = Math.max(0, (new Date(r.checkIn).getTime() - new Date(start).getTime()) / 86400000);
                    const e = Math.min(days, (new Date(r.checkOut).getTime() - new Date(start).getTime()) / 86400000);
                    if (e <= 0) return null;
                    return (
                      <button
                        key={r.id}
                        className={`cal-block status-${r.status}`}
                        style={{ insetInlineStart: `${(s / days) * 100}%`, width: `${((e - s) / days) * 100}%` }}
                        title={`${guestName(r.guestId)} · ${r.reference}`}
                        onClick={() => navigate(`/app/reservations?search=${r.reference}`)}
                      >
                        <span className="ref">{r.reference}</span>
                        {e - s > 0.6 && <span>{guestName(r.guestId)}</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
