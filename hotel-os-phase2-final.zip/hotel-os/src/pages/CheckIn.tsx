import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { guestService, reservationService, roomService, roomTypeService } from '@/services';
import { Badge, Button, Card, EmptyBlock, Field, LoadingBlock, useToast } from '@/components/ui';
import { formatDate, formatMoney, todayISO } from '@/utils/format';
import type { Reservation } from '@/types';

const STEPS = ['stepGuest', 'stepRoom', 'stepDocuments', 'stepPayment', 'stepConfirm'] as const;

export default function CheckIn() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [selected, setSelected] = useState<Reservation | null>(null);
  const [step, setStep] = useState(0);
  const [docsVerified, setDocsVerified] = useState(false);

  const arrivals = useAsync(() => (hotelId ? reservationService.todayArrivals(hotelId, todayISO()) : Promise.resolve([])), [hotelId]);
  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const types = useAsync(() => (hotelId ? roomTypeService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const guest = guests.data?.find((g) => g.id === selected?.guestId);
  const room = rooms.data?.find((r) => r.id === selected?.roomId);
  const type = types.data?.find((x) => x.id === room?.roomTypeId);
  const balance = selected ? selected.totalAmount - selected.paidAmount : 0;

  const doCheckIn = useMutation(async () => {
    if (selected) await reservationService.checkIn(selected.id, user?.id ?? '');
  }, () => {
    toast.push('success', t('checkin.checkInSuccess'));
    setSelected(null);
    setStep(0);
    setDocsVerified(false);
    arrivals.reload();
  });

  if (!selected) {
    return (
      <div className="stack">
        <div className="page-head">
          <div>
            <h1>{t('checkin.title')}</h1>
            <p className="sub">{t('checkin.subtitle')}</p>
          </div>
        </div>
        <Card title={`${t('checkin.arrivalsToday')} — ${formatDate(todayISO(), locale)}`}>
          {arrivals.status === 'loading' && <LoadingBlock />}
          {arrivals.status === 'empty' && <EmptyBlock subtitle={t('checkin.noArrivals')} />}
          {arrivals.data?.map((r) => {
            const g = guests.data?.find((x) => x.id === r.guestId);
            const rm = rooms.data?.find((x) => x.id === r.roomId);
            const nights = Math.round((new Date(r.checkOut).getTime() - new Date(r.checkIn).getTime()) / 86400000);
            return (
              <div key={r.id} className="list-row">
                <div className="grow">
                  <div className="cell-main">{g?.firstName} {g?.lastName}</div>
                  <div className="cell-sub">
                    {r.reference} · {t('common.room')} {rm?.number} · {t('reservations.nightsCount', { count: nights })}
                  </div>
                </div>
                <Badge status={r.status} label={t(`statuses.reservation.${r.status}`)} />
                <Button variant="primary" size="sm" onClick={() => { setSelected(r); setStep(0); }}>{t('checkin.title')}</Button>
              </div>
            );
          })}
        </Card>
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="page-head">
        <div><h1>{t('checkin.title')} — {selected.reference}</h1></div>
        <Button onClick={() => setSelected(null)}>{t('common.back')}</Button>
      </div>
      <div className="steps" role="list">
        {STEPS.map((s, i) => (
          <div key={s} data-n={i + 1} className={`step ${i < step ? 'done' : ''} ${i === step ? 'current' : ''}`}>
            {t(`checkin.${s}`)}
          </div>
        ))}
      </div>
      <Card>
        {step === 0 && guest && (
          <dl className="kv">
            <dt>{t('common.name')}</dt><dd>{guest.firstName} {guest.lastName}</dd>
            <dt>{t('common.email')}</dt><dd>{guest.email}</dd>
            <dt>{t('common.phone')}</dt><dd>{guest.phone}</dd>
            <dt>{t('guests.nationality')}</dt><dd>{guest.nationality}</dd>
            <dt>{t('guests.documentNumber')}</dt><dd>{guest.documentNumber || '—'}</dd>
          </dl>
        )}
        {step === 1 && room && (
          <dl className="kv">
            <dt>{t('common.room')}</dt><dd>{room.number}</dd>
            <dt>{t('common.type')}</dt><dd>{type?.name[locale]}</dd>
            <dt>{t('common.floor')}</dt><dd>{room.floor}</dd>
            <dt>{t('common.status')}</dt><dd><Badge status={room.status} label={t(`statuses.room.${room.status}`)} /></dd>
          </dl>
        )}
        {step === 2 && (
          <Field label={t('checkin.stepDocuments')}>
            <div className="login-demo">
              <p className="muted small" style={{ marginBlockEnd: 10 }}>{t('checkin.verifyDocumentsHint')}</p>
              <label className="checkbox-row">
                <input type="checkbox" checked={docsVerified} onChange={(e) => setDocsVerified(e.target.checked)} />
                {t('checkin.documentsVerified')}
              </label>
            </div>
          </Field>
        )}
        {step === 3 && (
          <dl className="kv">
            <dt>{t('reservations.totalAmount')}</dt><dd className="money">{formatMoney(selected.totalAmount, currency, locale)}</dd>
            <dt>{t('common.paid')}</dt><dd className="money">{formatMoney(selected.paidAmount, currency, locale)}</dd>
            <dt>{t('checkin.remainingBalance')}</dt>
            <dd className={`money ${balance > 0 ? 'neg' : 'pos'}`}>{formatMoney(balance, currency, locale)}</dd>
            <dt>{t('checkin.paymentStatus')}</dt>
            <dd>
              <Badge
                status={balance === 0 ? 'paid' : selected.paidAmount > 0 ? 'partialPayment' : 'pending'}
                label={balance === 0 ? t('checkin.fullyPaid') : selected.paidAmount > 0 ? t('checkin.partialPayment') : t('checkin.unpaid')}
              />
            </dd>
          </dl>
        )}
        {step === 4 && (
          <dl className="kv">
            <dt>{t('common.guest')}</dt><dd>{guest?.firstName} {guest?.lastName}</dd>
            <dt>{t('common.room')}</dt><dd>{room?.number}</dd>
            <dt>{t('reservations.stay')}</dt>
            <dd>{formatDate(selected.checkIn, locale)} → {formatDate(selected.checkOut, locale)}</dd>
            <dt>{t('common.amount')}</dt><dd className="money">{formatMoney(selected.totalAmount, currency, locale)}</dd>
            <dt>{t('common.paid')}</dt><dd className="money">{formatMoney(selected.paidAmount, currency, locale)}</dd>
            <dt>{t('checkin.remainingBalance')}</dt><dd className="money">{formatMoney(balance, currency, locale)}</dd>
          </dl>
        )}
        <div className="flex mt" style={{ justifyContent: 'space-between' }}>
          <Button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>{t('common.back')}</Button>
          {step < 4 ? (
            <Button variant="primary" disabled={step === 2 && !docsVerified} onClick={() => setStep((s) => s + 1)}>
              {t('common.next')}
            </Button>
          ) : (
            <Button variant="primary" loading={doCheckIn.pending} onClick={() => doCheckIn.execute()}>
              {t('checkin.confirmCheckIn')}
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
