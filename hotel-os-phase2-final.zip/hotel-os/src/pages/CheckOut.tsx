import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { guestService, paymentService, reservationService, roomService, serviceService } from '@/services';
import { Button, Card, EmptyBlock, Field, LoadingBlock, Modal, useToast } from '@/components/ui';
import { formatDate, formatDateTime, formatMoney } from '@/utils/format';
import type { PaymentMethod, Reservation } from '@/types';

export default function CheckOut() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [selected, setSelected] = useState<Reservation | null>(null);
  const [payOpen, setPayOpen] = useState(false);
  const [svcOpen, setSvcOpen] = useState(false);
  const [receipt, setReceipt] = useState(false);

  const stays = useAsync(async () => {
    if (!hotelId) return [];
    const all = await reservationService.list(hotelId, { status: 'checked_in' });
    return all.sort((a, b) => a.checkOut.localeCompare(b.checkOut));
  }, [hotelId]);

  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const guestName = (id: string) => {
    const g = guests.data?.find((x) => x.id === id);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };
  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';

  const services = useAsync(() => (selected ? reservationService.servicesOf(selected.id) : Promise.resolve([])), [selected?.id]);
  const catalog = useAsync(() => serviceService.list(hotelId), [hotelId]);
  const catalogMap = new Map((catalog.data ?? []).map((s) => [s.id, s]));
  const payments = useAsync(() => (selected ? reservationService.paymentsOf(selected.id) : Promise.resolve([])), [selected?.id]);

  const doCheckout = useMutation(async () => {
    if (selected) await reservationService.checkOut(selected.id, user?.id ?? '');
  }, () => {
    toast.push('success', t('checkout.checkoutSuccess'));
    setReceipt(true);
    stays.reload();
  });

  if (!selected) {
    return (
      <div className="stack">
        <div className="page-head">
          <div>
            <h1>{t('checkout.title')}</h1>
            <p className="sub">{t('checkout.subtitle')}</p>
          </div>
        </div>
        <Card title={t('checkout.selectReservation')}>
          {stays.status === 'loading' && <LoadingBlock />}
          {stays.status === 'empty' && <EmptyBlock subtitle={t('checkout.noStays')} />}
          {stays.data?.map((r) => (
            <div key={r.id} className="list-row">
              <div className="grow">
                <div className="cell-main">{guestName(r.guestId)}</div>
                <div className="cell-sub">
                  {r.reference} · {t('common.room')} {roomNumber(r.roomId)} · {formatDate(r.checkIn, locale)} → {formatDate(r.checkOut, locale)}
                </div>
              </div>
              <Button variant="primary" size="sm" onClick={() => setSelected(r)}>{t('checkout.title')}</Button>
            </div>
          ))}
        </Card>
      </div>
    );
  }

  const servicesTotal = (services.data ?? []).reduce((s, x) => s + x.quantity * x.unitPrice, 0);
  const paidTotal = selected.paidAmount;
  const grandTotal = selected.totalAmount + servicesTotal;
  const balance = grandTotal - paidTotal;

  if (receipt) {
    return (
      <div className="stack">
        <Card>
          <div style={{ textAlign: 'center', paddingBlock: 20 }}>
            <h2>{t('checkout.receiptTitle')}</h2>
            <p className="muted">{hotel?.name} · {selected.reference}</p>
            <p className="muted small">{[hotel?.address, hotel?.city, hotel?.phone].filter(Boolean).join(' · ')}</p>
          </div>
          {(services.data ?? []).length > 0 && (
            <div style={{ maxWidth: 420, margin: '0 auto 16px' }}>
              {(services.data ?? []).map((x) => (
                <div key={x.id} className="flex-between" style={{ fontSize: 13, paddingBlock: 4 }}>
                  <span>{catalogMap.get(x.serviceId)?.name[locale] ?? '—'} × {x.quantity}</span>
                  <span className="money">{formatMoney(x.quantity * x.unitPrice, currency, locale)}</span>
                </div>
              ))}
            </div>
          )}
          <dl className="kv" style={{ maxWidth: 420, margin: '0 auto' }}>
            <dt>{t('common.guest')}</dt><dd>{guestName(selected.guestId)}</dd>
            <dt>{t('common.room')}</dt><dd>{roomNumber(selected.roomId)}</dd>
            <dt>{t('checkout.stayDates')}</dt>
            <dd>{formatDate(selected.checkIn, locale)} → {formatDate(selected.checkOut, locale)}</dd>
            <dt>{t('checkout.roomPrice')}</dt><dd>{formatMoney(selected.totalAmount, currency, locale)}</dd>
            <dt>{t('checkout.servicesTotal')}</dt><dd>{formatMoney(servicesTotal, currency, locale)}</dd>
            <dt>{t('checkout.paymentsTotal')}</dt><dd>{formatMoney(paidTotal, currency, locale)}</dd>
            <dt>{t('checkout.finalTotal')}</dt><dd className="money">{formatMoney(grandTotal, currency, locale)}</dd>
          </dl>
          <p style={{ textAlign: 'center', marginBlockStart: 20 }} className="muted">{t('checkout.thankYou')}</p>
          <div className="flex mt no-print" style={{ justifyContent: 'center', gap: 10 }}>
            <Button onClick={() => { setReceipt(false); setSelected(null); }}>{t('common.close')}</Button>
            <Button variant="primary" onClick={() => window.print()}>{t('checkout.generateReceipt')}</Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="stack">
      <div className="page-head">
        <div><h1>{t('checkout.title')} — {selected.reference}</h1></div>
        <div className="page-actions no-print">
          <Button onClick={() => setSelected(null)}>{t('common.back')}</Button>
        </div>
      </div>
      <Card title={t('checkout.stayDates')}>
        <p>
          {guestName(selected.guestId)} · {t('common.room')} {roomNumber(selected.roomId)} ·{' '}
          {formatDate(selected.checkIn, locale)} → {formatDate(selected.checkOut, locale)}
        </p>
      </Card>
      <Card title={t('reservations.services')}>
        <div className="flex-between mb">
          <span className="money">{formatMoney(servicesTotal, currency, locale)}</span>
          <Button size="sm" onClick={() => setSvcOpen(true)}>+ {t('checkout.addService')}</Button>
        </div>
        {(services.data ?? []).map((s) => (
          <div key={s.id} className="flex-between" style={{ fontSize: 13, paddingBlock: 4 }}>
            <span>{catalogMap.get(s.serviceId)?.name[locale] ?? '—'} × {s.quantity}</span>
            <span className="money">{formatMoney(s.quantity * s.unitPrice, currency, locale)}</span>
          </div>
        ))}
      </Card>
      <Card title={t('reservations.payments')}>
        <div className="flex-between mb">
          <span className="money">{formatMoney(paidTotal, currency, locale)}</span>
          <Button size="sm" onClick={() => setPayOpen(true)}>+ {t('checkout.addPayment')}</Button>
        </div>
        {(payments.data ?? []).map((p) => (
          <div key={p.id} className="flex-between" style={{ fontSize: 13, paddingBlock: 4 }}>
            <span>{t(`methods.${p.method}`)} · {formatDateTime(p.paidAt, locale)}</span>
            <span className="money">{formatMoney(p.amount, currency, locale)}</span>
          </div>
        ))}
      </Card>
      <Card>
        <dl className="kv">
          <dt>{t('checkout.roomPrice')}</dt><dd>{formatMoney(selected.totalAmount, currency, locale)}</dd>
          <dt>{t('checkout.servicesTotal')}</dt><dd>{formatMoney(servicesTotal, currency, locale)}</dd>
          <dt>{t('checkout.paymentsTotal')}</dt><dd>{formatMoney(paidTotal, currency, locale)}</dd>
          <dt>{t('checkout.finalTotal')}</dt><dd className="money">{formatMoney(grandTotal, currency, locale)}</dd>
          <dt>{balance > 0 ? t('checkout.balanceDue') : t('checkout.settled')}</dt>
          <dd className={`money ${balance > 0 ? 'neg' : 'pos'}`}>{formatMoney(Math.max(0, balance), currency, locale)}</dd>
        </dl>
        <Button
          variant="primary"
          className="mt"
          style={{ width: '100%' }}
          loading={doCheckout.pending}
          onClick={() => doCheckout.execute()}
          disabled={balance > 0}
        >
          {t('checkout.completeCheckout')}
        </Button>
      </Card>

      {payOpen && (
        <PaymentModal
          hotelId={hotelId}
          reservationId={selected.id}
          currency={currency}
          maxAmount={balance}
          onClose={() => setPayOpen(false)}
          onDone={() => { setPayOpen(false); payments.reload(); }}
        />
      )}
      {svcOpen && (
        <Modal title={t('checkout.addService')} onClose={() => setSvcOpen(false)}>
          <div className="stack">
            {(catalog.data ?? []).filter((s) => s.active).map((s) => (
              <div key={s.id} className="flex-between card" style={{ padding: '10px 14px' }}>
                <span>
                  {s.name[locale]} <span className="muted small">· {formatMoney(s.price, currency, locale)}</span>
                </span>
                <Button
                  size="sm"
                  variant="primary"
                  onClick={async () => {
                    await reservationService.addService(hotelId, selected.id, s.id, 1, '');
                    toast.push('success', t('services.attached'));
                    setSvcOpen(false);
                    services.reload();
                  }}
                >
                  {t('services.attach')}
                </Button>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}

export function PaymentModal({ hotelId, reservationId, currency, maxAmount, onClose, onDone }: {
  hotelId: string;
  reservationId: string;
  currency: string;
  maxAmount?: number;
  onClose: () => void;
  onDone: () => void;
}) {
  const { t } = useTranslation();
  const toast = useToast();
  const [amount, setAmount] = useState(maxAmount ?? 0);
  const [method, setMethod] = useState<PaymentMethod>('card');
  const save = useMutation(async () => {
    await paymentService.record(hotelId, reservationId, {
      amount,
      method,
      status: 'paid',
      transactionReference: `TX-${Math.floor(100000 + Math.random() * 899999)}`,
      notes: '',
      paidAt: new Date().toISOString(),
    });
  }, () => { toast.push('success', t('payments.paymentSaved')); onDone(); });
  return (
    <Modal
      title={t('payments.add')}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" disabled={amount <= 0} loading={save.pending} onClick={() => save.execute()}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label={t('common.amount')}>
          <input className="input" type="number" min={1} max={maxAmount} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
        </Field>
        <Field label={t('payments.method')}>
          <select className="select" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
            {(['cash', 'card', 'bank_transfer', 'online', 'other'] as const).map((m) => (
              <option key={m} value={m}>{t(`methods.${m}`)}</option>
            ))}
          </select>
        </Field>
      </div>
    </Modal>
  );
}
