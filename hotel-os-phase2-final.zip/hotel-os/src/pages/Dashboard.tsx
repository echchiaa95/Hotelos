import { Link } from 'react-router-dom';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync } from '@/hooks/useAsync';
import { reportService, reservationService, guestService, roomService, roomTypeService } from '@/services';
import { Badge, Card, ErrorBlock, LoadingBlock, StatCard } from '@/components/ui';
import { DonutChart, LineChart, dayPoints } from '@/components/charts';
import { addDays, formatDate, formatMoney, todayISO } from '@/utils/format';

export default function Dashboard() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const hotelId = hotel?.id ?? '';

  const stats = useAsync(() => (hotelId ? reportService.dashboard(hotelId) : Promise.resolve(null)), [hotelId]);
  const revenue = useAsync(
    () => (hotelId ? reportService.revenueByDay(hotelId, todayISO().slice(0, 8) + '01', todayISO()) : Promise.resolve([])),
    [hotelId],
  );
  const sources = useAsync(() => (hotelId ? reportService.bySource(hotelId, todayISO().slice(0, 8) + '01', todayISO()) : Promise.resolve([])), [hotelId]);
  const arrivals = useAsync(() => (hotelId ? reservationService.todayArrivals(hotelId, todayISO()) : Promise.resolve([])), [hotelId, stats.status]);
  const departures = useAsync(() => (hotelId ? reservationService.todayDepartures(hotelId, todayISO()) : Promise.resolve([])), [hotelId, stats.status]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const guests = useAsync(() => (hotelId ? guestService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const types = useAsync(() => (hotelId ? roomTypeService.list(hotelId) : Promise.resolve([])), [hotelId]);

  if (stats.status === 'loading') return <LoadingBlock />;
  if (stats.status === 'error' || !stats.data) return <ErrorBlock code={stats.error} onRetry={stats.reload} />;
  const s = stats.data;
  const currency = s.currency;
  // Bars are relative to the real room count (was hard-coded to 14 = mock data).
  const totalRooms = Math.max(1, (Object.values(s.rooms) as number[]).reduce((a, b) => a + b, 0));
  const guestName = (id: string) => {
    const g = guests.data?.find((x) => x.id === id);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };
  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('dashboard.title')}</h1>
          <p className="sub">{formatDate(todayISO(), locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })} · {hotel?.name}</p>
        </div>
      </div>

      <Card title={t('dashboard.roomStatus')}>
        <div className="stat-grid">
          <StatCard label={t('dashboard.availableRooms')} value={s.rooms.available} bar={(s.rooms.available / totalRooms) * 100} barColor="#15803d" />
          <StatCard label={t('dashboard.occupiedRooms')} value={s.rooms.occupied} bar={(s.rooms.occupied / totalRooms) * 100} barColor="#7c3aed" />
          <StatCard label={t('dashboard.reservedRooms')} value={s.rooms.reserved} bar={(s.rooms.reserved / totalRooms) * 100} barColor="#2563eb" />
          <StatCard label={t('dashboard.cleaning')} value={s.rooms.cleaning} bar={(s.rooms.cleaning / totalRooms) * 100} barColor="#b45309" />
          <StatCard label={t('dashboard.maintenance')} value={s.rooms.maintenance} bar={(s.rooms.maintenance / totalRooms) * 100} barColor="#b45309" />
          <StatCard label={t('dashboard.outOfService')} value={s.rooms.out_of_service} bar={(s.rooms.out_of_service / totalRooms) * 100} barColor="#b91c1c" />
        </div>
      </Card>

      <div className="grid-3">
        <Card title={t('dashboard.reservationStats')}>
          <div className="stat-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <StatCard label={t('dashboard.todaysCheckIns')} value={s.todayCheckIns} tone="accent" />
            <StatCard label={t('dashboard.todaysCheckOuts')} value={s.todayCheckOuts} />
            <StatCard label={t('dashboard.newReservations')} value={s.newReservations} />
            <StatCard label={t('dashboard.pendingReservations')} value={s.pendingReservations} />
          </div>
        </Card>
        <Card title={t('dashboard.financialStats')}>
          <div className="stat-grid" style={{ gridTemplateColumns: '1fr' }}>
            <StatCard label={t('dashboard.todaysRevenue')} value={formatMoney(s.todayRevenue, currency, locale)} tone="accent" />
            <StatCard label={t('dashboard.monthRevenue')} value={formatMoney(s.monthRevenue, currency, locale)} />
            <StatCard label={t('dashboard.outstandingPayments')} value={formatMoney(s.outstandingPayments, currency, locale)} />
          </div>
        </Card>
        <Card title={t('dashboard.occupancyStats')}>
          <div className="stat-grid" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
            <StatCard label={t('dashboard.occupancyRate')} value={`${s.occupancyRate}%`} tone="accent" />
            <StatCard label={t('dashboard.adr')} value={formatMoney(s.adr, currency, locale)} />
            <StatCard label={t('dashboard.revpar')} value={formatMoney(s.revpar, currency, locale)} />
          </div>
          <p className="muted small mt">{t('dashboard.vsYesterday')}</p>
        </Card>
      </div>

      <div className="grid-2">
        <Card title={t('dashboard.revenueTrend')}>
          {revenue.status === 'success' && revenue.data ? (
            <LineChart data={dayPoints(revenue.data, locale)} formatValue={(v) => formatMoney(v, currency, locale)} />
          ) : (
            <LoadingBlock />
          )}
        </Card>
        <Card title={t('dashboard.reservationsBySource')}>
          {sources.status === 'success' && sources.data ? (
            <DonutChart data={sources.data.map((x) => ({ label: t(`sources.${x.source}` as never), value: x.count }))} />
          ) : (
            <LoadingBlock />
          )}
        </Card>
      </div>

      <div className="grid-2">
        <Card
          title={t('dashboard.arrivals')}
          actions={<Link to="/app/check-in" className="btn btn-ghost btn-sm">{t('dashboard.viewAll')}</Link>}
        >
          {arrivals.status === 'loading' && <LoadingBlock />}
          {arrivals.status === 'empty' && <p className="muted small">{t('dashboard.noArrivals')}</p>}
          {arrivals.data?.map((r) => (
            <div key={r.id} className="list-row">
              <div className="grow">
                <div className="cell-main">{guestName(r.guestId)}</div>
                <div className="cell-sub">{t('common.room')} {roomNumber(r.roomId)} · {r.reference}</div>
              </div>
              <Badge status={r.status} label={t(`statuses.reservation.${r.status}` as never)} />
            </div>
          ))}
        </Card>
        <Card
          title={t('dashboard.departures')}
          actions={<Link to="/app/check-out" className="btn btn-ghost btn-sm">{t('dashboard.viewAll')}</Link>}
        >
          {departures.status === 'loading' && <LoadingBlock />}
          {departures.status === 'empty' && <p className="muted small">{t('dashboard.noDepartures')}</p>}
          {departures.data?.map((r) => (
            <div key={r.id} className="list-row">
              <div className="grow">
                <div className="cell-main">{guestName(r.guestId)}</div>
                <div className="cell-sub">{t('common.room')} {roomNumber(r.roomId)} · {r.reference}</div>
              </div>
              <span className="money">{formatMoney(r.totalAmount - r.paidAmount, currency, locale)}</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

/* Local helper to avoid an extra import dance */
import { addDays as addDaysSafe } from '@/utils/format';
import { useAsync as useAsyncData } from '@/hooks/useAsync';
