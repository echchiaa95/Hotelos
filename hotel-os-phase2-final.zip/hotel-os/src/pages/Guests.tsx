import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { guestService, roomService } from '@/services';
import {
  Badge, Button, Card, EmptyBlock, Field, LoadingBlock, Modal, StatCard, useToast,
} from '@/components/ui';
import { IconEdit, IconPlus } from '@/components/icons';
import { formatDate, formatMoney } from '@/utils/format';
import type { Guest, Locale, Reservation } from '@/types';
import { validate, focusFirstInvalid, type FieldErrors } from '@/utils/validation';

export default function Guests() {
  const { t } = useTranslation();
  const { hotel } = useHotel();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Guest | null | 'new'>(null);
  const [viewing, setViewing] = useState<Guest | null>(null);

  const guests = useAsync(() => (hotelId ? guestService.list(hotelId, search) : Promise.resolve([])), [hotelId, search]);

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('guests.title')}</h1>
        <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('guests.add')}</Button>
      </div>
      <div className="toolbar">
        <input
          className="input"
          style={{ minWidth: 260 }}
          placeholder={t('guests.searchPlaceholder')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label={t('common.search')}
        />
      </div>
      {guests.status === 'loading' && <Card><LoadingBlock /></Card>}
      {guests.status === 'empty' && <Card><EmptyBlock /></Card>}
      {guests.status === 'success' && guests.data && (
        <div className="mobile-cards">
          {guests.data.map((g) => (
            <div className="m-card" key={g.id}>
              <div className="row">
                <span className="main">{g.firstName} {g.lastName}</span>
                <span className="sub">{g.nationality}</span>
              </div>
              <div className="sub">{g.email}</div>
              <div className="sub">{g.phone}</div>
              <div className="actions">
                <Button size="sm" onClick={() => setViewing(g)}>{t('common.view')}</Button>
                <Button size="sm" onClick={() => setEditing(g)}>{t('common.edit')}</Button>
              </div>
            </div>
          ))}
        </div>
      )}
      {guests.status === 'success' && guests.data && (
        <div className="table-wrap hide-mobile">
          <table className="table">
            <thead>
              <tr>
                <th>{t('common.name')}</th>
                <th>{t('common.email')}</th>
                <th>{t('common.phone')}</th>
                <th>{t('guests.nationality')}</th>
                <th style={{ textAlign: 'end' }}>{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {guests.data.map((g) => (
                <tr key={g.id}>
                  <td className="cell-main">{g.firstName} {g.lastName}</td>
                  <td className="muted">{g.email}</td>
                  <td>{g.phone}</td>
                  <td>{g.nationality}</td>
                  <td>
                    <div className="row-actions">
                      <Button size="sm" onClick={() => setViewing(g)}>{t('common.view')}</Button>
                      <Button size="sm" className="btn-icon" onClick={() => setEditing(g)} aria-label={t('common.edit')}><IconEdit /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editing !== null && (
        <GuestForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); guests.reload(); toast.push('success', t('guests.guestSaved')); }}
        />
      )}
      {viewing && <GuestProfile guest={viewing} hotelId={hotelId} onClose={() => setViewing(null)} />}
    </div>
  );
}

function GuestForm({ hotelId, initial, onClose, onSaved }: {
  hotelId: string;
  initial: Guest | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const toast = useToast();
  const bodyRef = React.useRef<HTMLDivElement>(null);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [f, setF] = useState({
    firstName: initial?.firstName ?? '',
    lastName: initial?.lastName ?? '',
    email: initial?.email ?? '',
    phone: initial?.phone ?? '',
    nationality: initial?.nationality ?? '',
    documentType: (initial?.documentType ?? 'passport') as Guest['documentType'],
    documentNumber: initial?.documentNumber ?? '',
    dateOfBirth: initial?.dateOfBirth ?? '',
    notes: initial?.notes ?? '',
  });
  const save = useMutation(async () => {
    // Minimum viable guest: first name only. Optional fields fall back
    // to safe empty strings so DB NOT NULL columns never block creation.
    const data = {
      firstName: f.firstName.trim(),
      lastName: f.lastName.trim(),
      email: f.email.trim(),
      phone: f.phone.trim(),
      nationality: f.nationality.trim(),
      documentType: f.documentType,
      documentNumber: f.documentNumber.trim(),
      dateOfBirth: f.dateOfBirth || null,
      notes: f.notes,
    };
    if (initial) await guestService.update(initial.id, data);
    else await guestService.create(hotelId, data);
  }, onSaved);

  const submit = async () => {
    const errs = validate({
      firstName: { valid: f.firstName.trim().length > 0, message: t('errors.requiredField') },
      email: { valid: !f.email.trim() || f.email.includes('@'), message: t('errors.invalidEmail') },
    });
    setErrors(errs);
    if (Object.keys(errs).length) {
      focusFirstInvalid(bodyRef.current);
      return;
    }
    const ok = await save.execute();
    if (!ok && save.error) toast.push('error', t(`errors.${save.error}` as never));
  };

  return (
    <Modal
      title={t(initial ? 'guests.edit' : 'guests.add')}
      wide
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" loading={save.pending} onClick={submit} data-testid="form-save">
            {save.pending ? t('common.saving') : t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" ref={bodyRef}>
        {Object.keys(errors).length > 0 && (
          <div className="form-error-summary full" role="alert">{t('validation.fixErrors')}</div>
        )}
        <Field label={t('common.name')} required error={errors.firstName}>
          <input className="input" value={f.firstName} onChange={(e) => setF({ ...f, firstName: e.target.value })} aria-required="true" data-testid="field-guest-firstname" />
        </Field>
        <Field label=" " optional><input className="input" value={f.lastName} placeholder="—" onChange={(e) => setF({ ...f, lastName: e.target.value })} /></Field>
        <Field label={t('common.email')} optional error={errors.email}><input className="input" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label={t('common.phone')} optional><input className="input" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label={t('guests.nationality')} optional><input className="input" value={f.nationality} onChange={(e) => setF({ ...f, nationality: e.target.value })} /></Field>
        <Field label={t('guests.dateOfBirth')} optional><input className="input" type="date" value={f.dateOfBirth ?? ''} onChange={(e) => setF({ ...f, dateOfBirth: e.target.value })} /></Field>
        <Field label={t('guests.documentType')}>
          <select className="select" value={f.documentType} onChange={(e) => setF({ ...f, documentType: e.target.value as Guest['documentType'] })}>
            {(['passport', 'national_id', 'driver_license', 'other'] as const).map((d) => (
              <option key={d} value={d}>{t(`docTypes.${d}`)}</option>
            ))}
          </select>
        </Field>
        <Field label={t('guests.documentNumber')} optional><input className="input" value={f.documentNumber} onChange={(e) => setF({ ...f, documentNumber: e.target.value })} /></Field>
        <Field label={t('common.notes')} full optional><textarea className="textarea" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}

function GuestProfile({ guest, hotelId, onClose }: { guest: Guest; hotelId: string; onClose: () => void }) {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const stats = useAsync(() => guestService.stats(hotelId, guest.id), [hotelId, guest.id]);
  const rooms = useAsync(() => roomService.list(hotelId), [hotelId]);
  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';
  const currency = hotel?.currency ?? 'MAD';
  return (
    <Modal title={t('guests.profile')} wide onClose={onClose}>
      {stats.status === 'loading' && <LoadingBlock />}
      {stats.data && (
        <div className="stack">
          <div className="flex">
            <strong style={{ fontSize: 17 }}>{guest.firstName} {guest.lastName}</strong>
            <span className="muted small">
              {guest.nationality} · {t(`docTypes.${guest.documentType}`)} {guest.documentNumber}
            </span>
          </div>
          <div className="stat-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <StatCard label={t('guests.totalStays')} value={stats.data.totalStays} />
            <StatCard label={t('guests.totalSpending')} value={formatMoney(stats.data.totalSpending, currency, locale)} tone="accent" />
          </div>
          {stats.data.current && (
            <Card title={t('guests.currentReservation')}>
              <ReservationRow r={stats.data.current} room={roomNumber(stats.data.current.roomId)} locale={locale} currency={currency} t={t} />
            </Card>
          )}
          <Card title={t('guests.previousReservations')}>
            {stats.data.past.length === 0 && <p className="muted small">{t('guests.noReservations')}</p>}
            {stats.data.past.slice(0, 8).map((r) => (
              <ReservationRow key={r.id} r={r} room={roomNumber(r.roomId)} locale={locale} currency={currency} t={t} />
            ))}
          </Card>
        </div>
      )}
    </Modal>
  );
}

function ReservationRow({ r, room, locale, currency, t }: {
  r: Reservation;
  room: string;
  locale: Locale;
  currency: string;
  t: (k: string, vars?: Record<string, string | number>) => string;
}) {
  return (
    <div className="list-row">
      <div className="grow">
        <div className="cell-main">{t('common.room')} {room} · {r.reference}</div>
        <div className="cell-sub">{formatDate(r.checkIn, locale)} → {formatDate(r.checkOut, locale)}</div>
      </div>
      <span className="money">{formatMoney(r.totalAmount, currency, locale)}</span>
      <Badge status={r.status} label={t(`statuses.reservation.${r.status}`)} />
    </div>
  );
}
