import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { housekeepingService, roomService, userService } from '@/services';
import { Badge, Button, Field, LoadingBlock, Modal, useToast } from '@/components/ui';
import { IconPlus } from '@/components/icons';
import { formatDateTime } from '@/utils/format';
import type { HousekeepingStatus, HousekeepingTask, TaskType } from '@/types';

const COLS: HousekeepingStatus[] = ['pending', 'in_progress', 'completed'];

export default function Housekeeping() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [addOpen, setAddOpen] = useState(false);

  const tasks = useAsync(() => (hotelId ? housekeepingService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const users = useAsync(() => (hotelId ? userService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';
  const userName = (id: string | null) => {
    const u = users.data?.find((x) => x.id === id);
    return u ? `${u.firstName} ${u.lastName}` : t('common.none');
  };

  const advance = useMutation(async (task: HousekeepingTask) => {
    if (task.status === 'pending') await housekeepingService.start(task.id);
    else if (task.status === 'in_progress') await housekeepingService.complete(task.id);
  }, () => { toast.push('success', t('housekeeping.taskUpdated')); tasks.reload(); });

  const release = useMutation(async (task: HousekeepingTask) => {
    await housekeepingService.completeAndRelease(task.id, user?.id ?? '');
  }, () => { toast.push('success', t('housekeeping.roomAvailableNow')); tasks.reload(); rooms.reload(); });

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('housekeeping.title')}</h1>
          <p className="sub">{t('housekeeping.subtitle')} · {t('housekeeping.workflowHint')}</p>
        </div>
        <Button variant="primary" onClick={() => setAddOpen(true)}><IconPlus /> {t('housekeeping.addTask')}</Button>
      </div>
      {tasks.status === 'loading' && <LoadingBlock />}
      {tasks.status === 'success' && tasks.data && (
        <div className="kanban">
          {COLS.map((col) => {
            const items = tasks.data!.filter((x) => x.status === col);
            return (
              <div key={col} className="kanban-col">
                <div className="kanban-col-head">
                  {t(`housekeeping.${col === 'in_progress' ? 'inProgress' : col}`)}
                  <span className="count">{items.length}</span>
                </div>
                <div className="kanban-items">
                  {items.length === 0 && <p className="muted small" style={{ padding: 10 }}>{t('housekeeping.noTasks')}</p>}
                  {items.map((task) => (
                    <div key={task.id} className="task-card">
                      <div className="flex-between">
                        <span className="room">{t('common.room')} {roomNumber(task.roomId)}</span>
                        <Badge
                          status={task.taskType === 'cleaning' ? 'cleaning' : 'maintenance'}
                          label={t(`taskTypes.${task.taskType}`)}
                        />
                      </div>
                      <div className="meta">{t('housekeeping.assignedTo')}: {userName(task.assignedTo)}</div>
                      {task.notes && <div className="notes">{task.notes}</div>}
                      {task.completedAt && (
                        <div className="meta">{t('housekeeping.completedAt')}: {formatDateTime(task.completedAt, locale)}</div>
                      )}
                      <div className="actions">
                        {task.status !== 'completed' && (
                          <Button size="sm" variant="primary" onClick={() => advance.execute(task)}>
                            {task.status === 'pending' ? t('housekeeping.startTask') : t('housekeeping.completeTask')}
                          </Button>
                        )}
                        {task.status === 'completed' && (
                          <Button size="sm" onClick={() => release.execute(task)}>{t('housekeeping.roomBackToAvailable')}</Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {addOpen && (
        <TaskForm
          hotelId={hotelId}
          rooms={rooms.data ?? []}
          users={users.data ?? []}
          onClose={() => setAddOpen(false)}
          onSaved={() => { setAddOpen(false); tasks.reload(); toast.push('success', t('housekeeping.taskCreated')); }}
        />
      )}
    </div>
  );
}

function TaskForm({ hotelId, rooms, users, onClose, onSaved }: {
  hotelId: string;
  rooms: import('@/types').Room[];
  users: import('@/types').Profile[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [f, setF] = useState({
    roomId: '',
    assignedTo: '',
    taskType: 'cleaning' as TaskType,
    notes: '',
  });
  const save = useMutation(async () => {
    await housekeepingService.create(hotelId, {
      roomId: f.roomId,
      assignedTo: f.assignedTo || null,
      taskType: f.taskType,
      status: 'pending',
      notes: f.notes,
      completedAt: null,
    });
  }, onSaved);
  return (
    <Modal
      title={t('housekeeping.addTask')}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" disabled={!f.roomId} loading={save.pending} onClick={() => save.execute()}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid">
        <Field label={t('common.room')}>
          <select className="select" value={f.roomId} onChange={(e) => setF({ ...f, roomId: e.target.value })}>
            <option value="">—</option>
            {rooms.map((r) => <option key={r.id} value={r.id}>{r.number}</option>)}
          </select>
        </Field>
        <Field label={t('housekeeping.assignedTo')}>
          <select className="select" value={f.assignedTo} onChange={(e) => setF({ ...f, assignedTo: e.target.value })}>
            <option value="">{t('common.none')}</option>
            {users.map((u) => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>)}
          </select>
        </Field>
        <Field label={t('housekeeping.taskType')}>
          <select className="select" value={f.taskType} onChange={(e) => setF({ ...f, taskType: e.target.value as TaskType })}>
            {(['cleaning', 'maintenance', 'inspection', 'other'] as const).map((x) => (
              <option key={x} value={x}>{t(`taskTypes.${x}`)}</option>
            ))}
          </select>
        </Field>
        <Field label={t('common.notes')}>
          <input className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}
