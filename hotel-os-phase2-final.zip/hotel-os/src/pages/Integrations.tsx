import React from 'react';
import { useTranslation } from '@/i18n';
import { Badge, Button, Card } from '@/components/ui';
import { channelRegistry } from '@/integrations';

export default function Integrations() {
  const { t } = useTranslation();
  const providers = channelRegistry.list();
  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('integrations.title')}</h1>
          <p className="sub">{t('integrations.subtitle')}</p>
        </div>
      </div>
      <div className="integ-grid">
        {providers.map((p) => (
          <Card key={p.id} className="integ-card">
            <div className="flex">
              <span className="integ-logo" style={{ background: p.color }}>{p.name.charAt(0)}</span>
              <div>
                <strong>{p.name}</strong>
                <div>
                  <Badge
                    status={p.connected ? 'available' : 'pending'}
                    label={p.connected ? t('integrations.connected') : t('integrations.notConnected')}
                  />
                </div>
              </div>
            </div>
            <p className="muted small">{t(p.descriptionKey as never)}</p>
            <p className="muted small">{t('integrations.lastSync')}: {t('integrations.neverSynced')}</p>
            <Button size="sm" disabled>{t('integrations.connect')}</Button>
          </Card>
        ))}
      </div>
      <Card>
        <p className="muted small">{t('integrations.architectureHint')}</p>
      </Card>
    </div>
  );
}
