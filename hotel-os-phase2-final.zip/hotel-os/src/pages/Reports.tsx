import React, { useMemo, useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync } from '@/hooks/useAsync';
import { guestService, reportService, roomService } from '@/services';
import { Badge, Card, LoadingBlock } from '@/components/ui';
import { DonutChart, LineChart, dayPoints } from '@/components/charts';
import { addDays, formatDate, formatMoney, todayISO } from '@/utils/format';

type PeriodKey = 'today' | 'yesterday' | 'thisWeek' | 'thisMonth';

export default function Reports() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [period, setPeriod] = useState<PeriodKey>('thisMonth');

  const range = useMemo(() => {
    const today = todayISO();
    switch (period) {
      case 'today': return { from: today, to: addDays(today, 1) };
      case 'yesterday': return { from: addDays(today, -1), to: today };
      case 'thisWeek': return { from: addDays(today, -6), to: addDays(today, 1) };
      case 'thisMonth': return { from: today.slice(0, 8) + '01', to: addDays(today, 1) };
    }
  }, [period]);

  const revenue = useAsync(() => reportService.revenueByDay(hotelId, range.from, range.to), [hotelId, range]);
  const sources = useAsync(() => reportService.bySource(hotelId, range.from, range.to), [hotelId, range]);
  const statuses = useAsync(() => reportService.byStatus(hotelId, range.from, range.to), [hotelId, range]);
  const perf = useAsync(() => reportService.roomPerformance(hotelId, range.from, range.to), [hotelId, range]);
  const paySum = useAsync(() => reportService.paymentsSummary(hotelId, range.from, range.to), [hotelId, range]);
  const outstanding = useAsync(() => reportService.outstanding(hotelId), [hotelId]);
  const guestStats = useAsync(() => reportService.guestStats(hotelId), [hotelId]);
  const guests = useAsync(() => guestService.list(hotelId), [hotelId]);
  const rooms = useAsync(() => roomService.list(hotelId), [hotelId]);

  const guestName = (id: string) => {
    const g = guests.data?.find((x) => x.id === id);
    return g ? `${g.firstName} ${g.lastName}` : '—';
  };
  const roomNumber = (id: string) => rooms.data?.find((r) => r.id === id)?.number ?? '—';

  const exportCsv = () => {
    const rows = [
      ['Room', 'Bookings', 'Room nights', 'Revenue'],
      ...(perf.data ?? []).map((r) => [r.number, String(r.bookings), String(r.roomNights), String(r.revenue)]),
    ];
    const csv = rows.map((r) => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = `hotelos-report-${range.from}-${range.to}.csv`;
    a.click();
  };

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>{t('reports.title')}</h1>
          <p className="sub">{t('reports.generated', { date: formatDate(todayISO(), locale) })}</p>
        </div>
        <div className="page-actions">
          <div className="seg">
            {(['today', 'yesterday', 'thisWeek', 'thisMonth'] as PeriodKey[]).map((p) => (
              <button key={p} className={period === p ? 'active' : ''} onClick={() => setPeriod(p)}>
                {t(`reports.period.${p}`)}
              </button>
            ))}
          </div>
          <button className="btn" onClick={exportCsv}>{t('common.exportCsv')}</button>
        </div>
      </div>

      <div className="grid-2">
        <Card title={t('reports.revenueByDay')}>
          {revenue.status === 'success' && revenue.data ? (
            <LineChart data={dayPoints(revenue.data, locale)} formatValue={(v) => formatMoney(v, currency, locale)} />
          ) : <LoadingBlock />}
        </Card>
        <Card title={t('reports.bookingSources')}>
          {sources.status === 'success' && sources.data ? (
            <DonutChart data={sources.data.map((x) => ({ label: t(`sources.${x.source}` as never), value: x.count }))} />
          ) : <LoadingBlock />}
        </Card>
      </div>

      <Card title={t('reports.roomPerformance')}>
        <div className="table-wrap" style={{ border: 0 }}>
          <table className="table">
            <thead>
              <tr><th>{t('common.room')}</th><th>{t('reports.reservationsReport')}</th><th>{t('reports.occupancy')}</th><th>{t('reports.revenue')}</th></tr>
            </thead>
            <tbody>
              {(perf.data ?? []).map((r) => (
                <tr key={r.roomId}>
                  <td className="cell-main">{r.number} <span className="cell-sub">{r.roomTypeName}</span></td>
                  <td>{r.bookings}</td>
                  <td>{r.roomNights}</td>
                  <td className="num">{formatMoney(r.revenue, currency, locale)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid-2">
        <Card title={t('reports.paymentsReport')}>
          {paySum.data && (
            <dl className="kv">
              <dt>{t('payments.totalPaid')}</dt><dd className="money">{formatMoney(paySum.data.paid, currency, locale)}</dd>
              <dt>{t('payments.outstanding')}</dt><dd>{formatMoney(paySum.data.pending, currency, locale)}</dd>
              <dt>{t('payments.refunded')}</dt><dd>{formatMoney(paySum.data.refunded, currency, locale)}</dd>
            </dl>
          )}
        </Card>
        <Card title={t('reports.guestStats')}>
          {guestStats.data && (
            <dl className="kv">
              <dt>{t('reports.totalGuests')}</dt><dd>{guestStats.data.totalGuests}</dd>
              <dt>{t('reports.newVsReturning')}</dt><dd>{guestStats.data.returning}</dd>
              <dt>{t('reports.avgStay')}</dt><dd>{guestStats.data.avgStay}</dd>
            </dl>
          )}
        </Card>
      </div>

      <Card title={t('reports.outstandingList')}>
        {(outstanding.data ?? []).length === 0 && <p className="muted small">{t('reports.noData')}</p>}
        {(outstanding.data ?? []).map((r) => (
          <div key={r.id} className="list-row">
            <div className="grow">
              <div className="cell-main">{guestName(r.guestId)} · {r.reference}</div>
              <div className="cell-sub">{t('common.room')} {roomNumber(r.roomId)}</div>
            </div>
            <span className="money neg">{formatMoney(r.totalAmount - r.paidAmount, currency, locale)}</span>
            <Badge status={r.status} label={t(`statuses.reservation.${r.status}` as never)} />
          </div>
        ))}
      </Card>
      <p className="muted small">{t('reports.exportHint')}</p>
    </div>
  );
}
