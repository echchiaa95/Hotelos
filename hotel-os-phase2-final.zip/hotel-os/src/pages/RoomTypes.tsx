import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { roomTypeService } from '@/services';
import {
  Badge, Button, Card, ConfirmDialog, EmptyBlock, Field, LoadingBlock, Modal, useToast,
} from '@/components/ui';
import { IconEdit, IconPlus, IconTrash } from '@/components/icons';
import { formatMoney } from '@/utils/format';
import type { LocalizedText, RoomType } from '@/types';

const AMENITIES = [
  'wifi', 'tv', 'ac', 'minibar', 'safe', 'bathtub', 'shower', 'seaView', 'cityView',
  'balcony', 'coffee', 'hairdryer', 'desk', 'breakfast', 'parking', 'pool', 'gym', 'spa', 'roomService',
];
const EMPTY_LOC: LocalizedText = { fr: '', ar: '', en: '' };

export default function RoomTypes() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [editing, setEditing] = useState<RoomType | null | 'new'>(null);
  const [deleting, setDeleting] = useState<RoomType | null>(null);

  const types = useAsync(() => (hotelId ? roomTypeService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const doDelete = useMutation(async (id: string) => {
    await roomTypeService.remove(id);
  }, () => { toast.push('success', t('roomTypes.typeDeleted')); setDeleting(null); types.reload(); });

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('roomTypes.title')}</h1>
        <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('roomTypes.add')}</Button>
      </div>

      {types.status === 'loading' && <Card><LoadingBlock /></Card>}
      {types.status === 'empty' && <Card><EmptyBlock /></Card>}
      {types.status === 'success' && types.data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('common.name')}</th>
                <th>{t('roomTypes.basePrice')}</th>
                <th>{t('roomTypes.maxGuests')}</th>
                <th>{t('roomTypes.size')}</th>
                <th>{t('roomTypes.amenities')}</th>
                <th>{t('common.status')}</th>
                <th style={{ textAlign: 'end' }}>{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {types.data.map((rt) => (
                <tr key={rt.id}>
                  <td>
                    <div className="cell-main">{rt.name[locale]}</div>
                    <div className="cell-sub">{rt.name.fr} · {rt.name.ar} · {rt.name.en}</div>
                  </td>
                  <td className="num">
                    {formatMoney(rt.basePrice, hotel?.currency ?? 'MAD', locale)}
                    <span className="muted small"> {t('roomTypes.perNight')}</span>
                  </td>
                  <td>{rt.maxGuests}</td>
                  <td>{rt.size} m²</td>
                  <td className="muted">
                    {rt.amenities.slice(0, 3).map((a) => t(`amenities.${a}` as never)).join(', ')}
                    {rt.amenities.length > 3 ? '…' : ''}
                  </td>
                  <td>
                    <Badge status={rt.active ? 'available' : 'out_of_service'} label={rt.active ? t('common.active') : t('common.inactive')} />
                  </td>
                  <td>
                    <div className="row-actions">
                      <Button size="sm" className="btn-icon" onClick={() => setEditing(rt)} aria-label={t('common.edit')}><IconEdit /></Button>
                      <Button size="sm" className="btn-icon" onClick={() => setDeleting(rt)} aria-label={t('common.delete')}><IconTrash /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing !== null && (
        <TypeForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); types.reload(); toast.push('success', t('roomTypes.typeSaved')); }}
        />
      )}
      {deleting && (
        <ConfirmDialog
          title={t('common.deleteConfirm')}
          message={t('roomTypes.deleteBlocked')}
          danger
          onCancel={() => setDeleting(null)}
          onConfirm={() => doDelete.execute(deleting.id)}
        />
      )}
    </div>
  );
}

function TypeForm({ hotelId, initial, onClose, onSaved }: {
  hotelId: string;
  initial: RoomType | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [f, setF] = useState({
    name: initial?.name ?? { ...EMPTY_LOC },
    description: initial?.description ?? { ...EMPTY_LOC },
    basePrice: initial?.basePrice ?? 500,
    maxGuests: initial?.maxGuests ?? 2,
    beds: initial?.beds ?? [{ type: 'queen' as const, count: 1 }],
    size: initial?.size ?? 20,
    amenities: initial?.amenities ?? ['wifi', 'tv', 'ac'],
    active: initial?.active ?? true,
  });

  const save = useMutation(async () => {
    const data = { ...f, images: initial?.images ?? [] };
    if (initial) await roomTypeService.update(initial.id, data);
    else await roomTypeService.create(hotelId, data);
  }, onSaved);

  const setLoc = (field: 'name' | 'description', lang: 'fr' | 'ar' | 'en', v: string) =>
    setF((s) => ({ ...s, [field]: { ...s[field], [lang]: v } }));

  const toggleAmenity = (a: string) =>
    setF((s) => ({ ...s, amenities: s.amenities.includes(a) ? s.amenities.filter((x) => x !== a) : [...s.amenities, a] }));

  const valid = Boolean(f.name.fr.trim() && f.basePrice > 0);

  return (
    <Modal
      title={t(initial ? 'roomTypes.edit' : 'roomTypes.add')}
      wide
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" disabled={!valid} loading={save.pending} onClick={() => save.execute()}>{t('common.save')}</Button>
        </>
      }
    >
      <div className="stack">
        <div className="form-grid">
          <Field label={t('roomTypes.nameFr')}><input className="input" value={f.name.fr} onChange={(e) => setLoc('name', 'fr', e.target.value)} /></Field>
          <Field label={t('roomTypes.nameAr')}><input className="input" dir="rtl" value={f.name.ar} onChange={(e) => setLoc('name', 'ar', e.target.value)} /></Field>
          <Field label={t('roomTypes.nameEn')}><input className="input" value={f.name.en} onChange={(e) => setLoc('name', 'en', e.target.value)} /></Field>
          <Field label={t('roomTypes.basePrice')}><input className="input" type="number" min={0} value={f.basePrice} onChange={(e) => setF({ ...f, basePrice: Number(e.target.value) })} /></Field>
          <Field label={t('roomTypes.maxGuests')}><input className="input" type="number" min={1} value={f.maxGuests} onChange={(e) => setF({ ...f, maxGuests: Number(e.target.value) })} /></Field>
          <Field label={t('roomTypes.size')}><input className="input" type="number" min={0} value={f.size} onChange={(e) => setF({ ...f, size: Number(e.target.value) })} /></Field>
          <Field label={t('roomTypes.descFr')} full><textarea className="textarea" value={f.description.fr} onChange={(e) => setLoc('description', 'fr', e.target.value)} /></Field>
          <Field label={t('roomTypes.descAr')} full><textarea className="textarea" dir="rtl" value={f.description.ar} onChange={(e) => setLoc('description', 'ar', e.target.value)} /></Field>
          <Field label={t('roomTypes.descEn')} full><textarea className="textarea" value={f.description.en} onChange={(e) => setLoc('description', 'en', e.target.value)} /></Field>
        </div>
        <Field label={t('roomTypes.amenities')}>
          <div className="chip-row">
            {AMENITIES.map((a) => (
              <button key={a} type="button" className={`chip ${f.amenities.includes(a) ? 'active' : ''}`} onClick={() => toggleAmenity(a)}>
                {t(`amenities.${a}` as never)}
              </button>
            ))}
          </div>
        </Field>
        <label className="checkbox-row">
          <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />
          {t('common.active')}
        </label>
      </div>
    </Modal>
  );
}
