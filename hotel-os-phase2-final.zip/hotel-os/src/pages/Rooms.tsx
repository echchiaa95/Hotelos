import React, { useMemo, useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { roomService, roomTypeService } from '@/services';
import {
  Badge, Button, Card, ConfirmDialog, EmptyBlock, ErrorBlock, Field, LoadingBlock, Modal, useToast,
} from '@/components/ui';
import { IconEdit, IconGrid, IconList, IconPlus, IconTrash } from '@/components/icons';
import type { Room, RoomStatus } from '@/types';
import { validate, focusFirstInvalid, type FieldErrors } from '@/utils/validation';

const STATUSES: RoomStatus[] = ['available', 'reserved', 'occupied', 'cleaning', 'maintenance', 'out_of_service'];

export default function Rooms() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const { user } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [search, setSearch] = useState('');
  const [floor, setFloor] = useState<number | 'all'>('all');
  const [status, setStatus] = useState<RoomStatus | 'all'>('all');
  const [typeId, setTypeId] = useState<string>('all');
  const [editing, setEditing] = useState<Room | null | 'new'>(null);
  const [deleting, setDeleting] = useState<Room | null>(null);
  const [statusTarget, setStatusTarget] = useState<Room | null>(null);

  const filters = useMemo(() => ({ search, floor, status, roomTypeId: typeId }), [search, floor, status, typeId]);
  const rooms = useAsync(() => (hotelId ? roomService.list(hotelId, filters) : Promise.resolve([])), [hotelId, filters]);
  const types = useAsync(() => (hotelId ? roomTypeService.list(hotelId) : Promise.resolve([])), [hotelId]);

  const floors = useMemo(() => [...new Set((rooms.data ?? []).map((r) => r.floor))].sort((a, b) => a - b), [rooms.data]);
  const typeName = (id: string) => types.data?.find((x) => x.id === id)?.name[locale] ?? '—';

  const doDelete = useMutation(async (id: string) => {
    await roomService.remove(id);
  }, () => { toast.push('success', t('rooms.deleted')); setDeleting(null); rooms.reload(); });

  const changeStatus = useMutation(async (room: Room, s: RoomStatus) => {
    await roomService.setStatus(room.id, s, user?.id ?? null, 'manual update');
  }, () => { setStatusTarget(null); rooms.reload(); });

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('rooms.title')}</h1>
        <div className="page-actions">
          <div className="seg" role="group">
            <button className={view === 'grid' ? 'active' : ''} onClick={() => setView('grid')} aria-label={t('rooms.gridView')}><IconGrid /></button>
            <button className={view === 'list' ? 'active' : ''} onClick={() => setView('list')} aria-label={t('rooms.listView')}><IconList /></button>
          </div>
          <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('rooms.addRoom')}</Button>
        </div>
      </div>

      <div className="toolbar">
        <input className="input" placeholder={t('common.searchPlaceholder')} value={search} onChange={(e) => setSearch(e.target.value)} aria-label={t('common.search')} />
        <select className="select" value={floor} onChange={(e) => setFloor(e.target.value === 'all' ? 'all' : Number(e.target.value))} aria-label={t('common.floor')}>
          <option value="all">{t('common.allFloors')}</option>
          {floors.map((f) => <option key={f} value={f}>{t('common.floor')} {f}</option>)}
        </select>
        <select className="select" value={status} onChange={(e) => setStatus(e.target.value as RoomStatus | 'all')} aria-label={t('common.status')}>
          <option value="all">{t('common.allStatuses')}</option>
          {STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.room.${s}`)}</option>)}
        </select>
        <select className="select" value={typeId} onChange={(e) => setTypeId(e.target.value)} aria-label={t('common.type')}>
          <option value="all">{t('common.allTypes')}</option>
          {(types.data ?? []).map((x) => <option key={x.id} value={x.id}>{x.name[locale]}</option>)}
        </select>
      </div>

      {rooms.status === 'loading' && <Card><LoadingBlock /></Card>}
      {rooms.status === 'error' && <Card><ErrorBlock code={rooms.error} onRetry={rooms.reload} /></Card>}
      {rooms.status === 'empty' && <Card><EmptyBlock /></Card>}

      {rooms.status === 'success' && rooms.data && view === 'grid' && (
        <div className="room-grid">
          {rooms.data.map((r) => (
            <div
              key={r.id}
              className={`room-card status-${r.status}`}
              onClick={() => setStatusTarget(r)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setStatusTarget(r)}
            >
              <div className="num">{r.number}</div>
              <div className="type">{typeName(r.roomTypeId)}</div>
              <div className="meta">
                <Badge status={r.status} label={t(`statuses.room.${r.status}`)} />
                <span className="muted small">{t('common.floor')} {r.floor}</span>
              </div>
              {r.notes && <div className="muted small" style={{ marginBlockStart: 8 }}>{r.notes}</div>}
            </div>
          ))}
        </div>
      )}

      {rooms.status === 'success' && rooms.data && view === 'list' && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('rooms.roomNumber')}</th>
                <th>{t('common.type')}</th>
                <th>{t('common.floor')}</th>
                <th>{t('common.status')}</th>
                <th>{t('common.notes')}</th>
                <th style={{ textAlign: 'end' }}>{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {rooms.data.map((r) => (
                <tr key={r.id}>
                  <td className="cell-main">{r.number}</td>
                  <td>{typeName(r.roomTypeId)}</td>
                  <td>{r.floor}</td>
                  <td><Badge status={r.status} label={t(`statuses.room.${r.status}`)} /></td>
                  <td className="muted">{r.notes}</td>
                  <td>
                    <div className="row-actions">
                      <Button size="sm" className="btn-icon" onClick={() => setEditing(r)} aria-label={t('common.edit')}><IconEdit /></Button>
                      <Button size="sm" className="btn-icon" onClick={() => setDeleting(r)} aria-label={t('common.delete')}><IconTrash /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing !== null && (
        <RoomForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          types={types.data ?? []}
          onClose={() => setEditing(null)}
          onSaved={() => {
            const wasNew = editing === 'new';
            setEditing(null);
            rooms.reload();
            toast.push('success', t(wasNew ? 'rooms.created' : 'rooms.updated'));
          }}
        />
      )}

      {statusTarget && (
        <Modal title={`${t('rooms.changeStatus')} — ${statusTarget.number}`} onClose={() => setStatusTarget(null)}>
          <div className="stack">
            <p className="muted small">{typeName(statusTarget.roomTypeId)} · {t('common.floor')} {statusTarget.floor}</p>
            <div className="chip-row">
              {STATUSES.map((s) => (
                <button
                  key={s}
                  className={`chip ${statusTarget.status === s ? 'active' : ''}`}
                  onClick={() => changeStatus.execute(statusTarget, s)}
                >
                  {t(`statuses.room.${s}`)}
                </button>
              ))}
            </div>
          </div>
        </Modal>
      )}

      {deleting && (
        <ConfirmDialog
          title={t('common.deleteConfirm')}
          message={t('common.deleteWarning')}
          danger
          onCancel={() => setDeleting(null)}
          onConfirm={() => doDelete.execute(deleting.id)}
        />
      )}
    </div>
  );
}

function RoomForm({ hotelId, initial, types, onClose, onSaved }: {
  hotelId: string;
  initial: Room | null;
  types: import('@/types').RoomType[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t, locale } = useTranslation();
  const toast = useToast();
  const bodyRef = React.useRef<HTMLDivElement>(null);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [f, setF] = useState({
    number: initial?.number ?? '',
    roomTypeId: initial?.roomTypeId ?? '',
    floor: initial?.floor ?? 1,
    status: (initial?.status ?? 'available') as RoomStatus,
    notes: initial?.notes ?? '',
  });
  const save = useMutation(async () => {
    const data = { number: f.number.trim(), roomTypeId: f.roomTypeId, floor: f.floor, status: f.status, notes: f.notes };
    if (initial) await roomService.update(initial.id, data);
    else await roomService.create(hotelId, data);
  }, onSaved);

  const submit = async () => {
    const errs = validate({
      number: { valid: f.number.trim().length > 0, message: t('errors.requiredField') },
      roomTypeId: { valid: !!f.roomTypeId, message: t('errors.requiredSelect') },
    });
    setErrors(errs);
    if (Object.keys(errs).length) {
      focusFirstInvalid(bodyRef.current);
      return;
    }
    const ok = await save.execute();
    if (!ok && save.error) toast.push('error', t(`errors.${save.error}` as never));
  };

  return (
    <Modal
      title={t(initial ? 'rooms.editRoom' : 'rooms.addRoom')}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" loading={save.pending} onClick={submit} data-testid="form-save">
            {save.pending ? t('common.saving') : t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" ref={bodyRef}>
        {Object.keys(errors).length > 0 && (
          <div className="form-error-summary full" role="alert">{t('validation.fixErrors')}</div>
        )}
        <Field label={t('rooms.roomNumber')} required error={errors.number}>
          <input className="input" value={f.number} onChange={(e) => setF({ ...f, number: e.target.value })} aria-required="true" data-testid="field-room-number" />
        </Field>
        <Field label={t('common.floor')} optional>
          <input className="input" type="number" min={0} value={f.floor} onChange={(e) => setF({ ...f, floor: Number(e.target.value) })} />
        </Field>
        <Field label={t('common.type')} required error={errors.roomTypeId}>
          <select className="select" value={f.roomTypeId} onChange={(e) => setF({ ...f, roomTypeId: e.target.value })} aria-required="true" data-testid="field-room-type">
            <option value="">—</option>
            {types.map((x) => <option key={x.id} value={x.id}>{x.name[locale]}</option>)}
          </select>
        </Field>
        <Field label={t('common.status')}>
          <select className="select" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as RoomStatus })}>
            {STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.room.${s}`)}</option>)}
          </select>
        </Field>
        <Field label={t('common.notes')} full optional><textarea className="textarea" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      </div>
    </Modal>
  );
}
