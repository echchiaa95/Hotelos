import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { serviceService } from '@/services';
import { Badge, Button, Card, Field, LoadingBlock, Modal, useToast } from '@/components/ui';
import { IconEdit, IconPlus } from '@/components/icons';
import { formatMoney } from '@/utils/format';
import { validate, focusFirstInvalid, type FieldErrors } from '@/utils/validation';
import type { HotelService, LocalizedText } from '@/types';

export default function Services() {
  const { t, locale } = useTranslation();
  const { hotel } = useHotel();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const currency = hotel?.currency ?? 'MAD';
  const [editing, setEditing] = useState<HotelService | null | 'new'>(null);

  const services = useAsync(() => (hotelId ? serviceService.list(hotelId) : Promise.resolve([])), [hotelId]);
  const toggle = useMutation(async (id: string) => {
    await serviceService.toggleActive(id);
  }, () => services.reload());

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('services.title')}</h1>
        <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('services.add')}</Button>
      </div>
      {services.status === 'loading' && <LoadingBlock />}
      <div className="integ-grid">
        {(services.data ?? []).map((s) => (
          <Card key={s.id} className="integ-card">
            <div className="flex-between">
              <strong style={{ fontSize: 15 }}>{s.name[locale]}</strong>
              <Badge status={s.active ? 'available' : 'out_of_service'} label={s.active ? t('common.active') : t('common.inactive')} />
            </div>
            <p className="muted small">{s.description[locale]}</p>
            <div className="flex-between">
              <span className="money">{formatMoney(s.price, currency, locale)}</span>
              <div className="flex">
                <Button size="sm" className="btn-icon" onClick={() => setEditing(s)} aria-label={t('common.edit')}><IconEdit /></Button>
                <Button size="sm" onClick={() => toggle.execute(s.id)}>
                  {s.active ? t('common.inactive') : t('common.active')}
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
      {editing !== null && (
        <ServiceForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); services.reload(); toast.push('success', t('services.serviceSaved')); }}
        />
      )}
    </div>
  );
}

function ServiceForm({ hotelId, initial, onClose, onSaved }: {
  hotelId: string;
  initial: HotelService | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const toast = useToast();
  const bodyRef = React.useRef<HTMLDivElement>(null);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [f, setF] = useState({
    name: initial?.name ?? ({ fr: '', ar: '', en: '' } as LocalizedText),
    description: initial?.description ?? ({ fr: '', ar: '', en: '' } as LocalizedText),
    price: initial?.price ?? 100,
    active: initial?.active ?? true,
  });
  const save = useMutation(async () => {
    // French name is the source of truth; empty ar/en fall back to it
    // so DB jsonb NOT NULL columns never block creation.
    const name = { fr: f.name.fr.trim(), ar: f.name.ar.trim() || f.name.fr.trim(), en: f.name.en.trim() || f.name.fr.trim() };
    const description = {
      fr: f.description.fr.trim(), ar: f.description.ar.trim() || f.description.fr.trim(), en: f.description.en.trim() || f.description.fr.trim(),
    };
    const payload = { name, description, price: f.price, active: f.active };
    if (initial) await serviceService.update(initial.id, payload);
    else await serviceService.create(hotelId, payload);
  }, onSaved);
  const setLoc = (field: 'name' | 'description', lang: 'fr' | 'ar' | 'en', v: string) =>
    setF((s) => ({ ...s, [field]: { ...s[field], [lang]: v } }));

  const submit = async () => {
    const errs = validate({
      nameFr: { valid: f.name.fr.trim().length > 0, message: t('errors.requiredField') },
      price: { valid: f.price > 0, message: t('errors.requiredField') },
    });
    setErrors(errs);
    if (Object.keys(errs).length) {
      focusFirstInvalid(bodyRef.current);
      return;
    }
    const ok = await save.execute();
    if (!ok && save.error) toast.push('error', t(`errors.${save.error}` as never));
  };

  return (
    <Modal
      title={t(initial ? 'services.edit' : 'services.add')}
      wide
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" loading={save.pending} onClick={submit} data-testid="form-save">
            {save.pending ? t('common.saving') : t('common.save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" ref={bodyRef}>
        {Object.keys(errors).length > 0 && (
          <div className="form-error-summary full" role="alert">{t('validation.fixErrors')}</div>
        )}
        <Field label={t('services.nameFr')} required error={errors.nameFr}><input className="input" value={f.name.fr} onChange={(e) => setLoc('name', 'fr', e.target.value)} aria-required="true" data-testid="field-service-name" /></Field>
        <Field label={t('services.nameAr')}><input className="input" dir="rtl" value={f.name.ar} onChange={(e) => setLoc('name', 'ar', e.target.value)} /></Field>
        <Field label={t('services.nameEn')}><input className="input" value={f.name.en} onChange={(e) => setLoc('name', 'en', e.target.value)} /></Field>
        <Field label={t('common.price')} required error={errors.price}><input className="input" type="number" min={0} value={f.price} onChange={(e) => setF({ ...f, price: Number(e.target.value) })} aria-required="true" /></Field>
        <Field label={t('services.descFr')} full><textarea className="textarea" value={f.description.fr} onChange={(e) => setLoc('description', 'fr', e.target.value)} /></Field>
        <Field label={t('services.descAr')} full><textarea className="textarea" dir="rtl" value={f.description.ar} onChange={(e) => setLoc('description', 'ar', e.target.value)} /></Field>
        <Field label={t('services.descEn')} full><textarea className="textarea" value={f.description.en} onChange={(e) => setLoc('description', 'en', e.target.value)} /></Field>
      </div>
      <label className="checkbox-row mt">
        <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />
        {t('common.active')}
      </label>
    </Modal>
  );
}
