import React, { useEffect, useState } from 'react';
import { useTranslation, LOCALE_NAMES } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { Button, Card, Field, useToast } from '@/components/ui';
import type { Locale } from '@/types';
import { HotelError } from '@/types';

export default function Settings() {
  const { t } = useTranslation();
  const { hotel, updateHotel } = useHotel();
  const toast = useToast();
  const [f, setF] = useState(hotel);
  const [saving, setSaving] = useState(false);

  useEffect(() => setF(hotel), [hotel]);
  if (!f) return null;

  const save = async () => {
    setSaving(true);
    const { id: _id, createdAt: _c, ...patch } = f;
    try {
      await updateHotel(patch);
      toast.push('success', t('settings.settingsSaved'));
    } catch (e) {
      const code = e instanceof HotelError ? e.code : 'generic';
      toast.push('error', t(`errors.${code}` as never));
    } finally {
      setSaving(false);
    }
  };
  const set = (k: string, v: unknown) => setF((s) => s && { ...s, [k]: v });
  const toggleLang = (l: Locale) => {
    const has = f.enabledLanguages.includes(l);
    set('enabledLanguages', has ? f.enabledLanguages.filter((x) => x !== l) : [...f.enabledLanguages, l]);
  };

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('settings.title')}</h1>
        <Button variant="primary" loading={saving} onClick={save}>{t('common.save')}</Button>
      </div>
      <Card title={t('settings.hotelInfo')}>
        <div className="form-grid">
          <Field label={t('settings.hotelName')} full>
            <input className="input" value={f.name} onChange={(e) => set('name', e.target.value)} />
          </Field>
          <Field label={t('settings.address')}><input className="input" value={f.address} onChange={(e) => set('address', e.target.value)} /></Field>
          <Field label={t('settings.city')}><input className="input" value={f.city} onChange={(e) => set('city', e.target.value)} /></Field>
          <Field label={t('settings.country')}><input className="input" value={f.country} onChange={(e) => set('country', e.target.value)} /></Field>
          <Field label={t('common.phone')}><input className="input" value={f.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
          <Field label={t('common.email')}><input className="input" type="email" value={f.email} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label={t('settings.currency')}><input className="input" value={f.currency} onChange={(e) => set('currency', e.target.value.toUpperCase())} /></Field>
          <Field label={t('settings.timezone')}><input className="input" value={f.timezone} onChange={(e) => set('timezone', e.target.value)} /></Field>
          <Field label={t('settings.checkInTime')}><input className="input" type="time" value={f.checkInTime} onChange={(e) => set('checkInTime', e.target.value)} /></Field>
          <Field label={t('settings.checkOutTime')}><input className="input" type="time" value={f.checkOutTime} onChange={(e) => set('checkOutTime', e.target.value)} /></Field>
        </div>
      </Card>
      <Card title={t('settings.branding')}>
        <div className="form-grid">
          <Field label={t('settings.logo')} hint={t('settings.uploadHint')}>
            <input className="input" placeholder="https://…" value={f.logoUrl ?? ''} onChange={(e) => set('logoUrl', e.target.value || null)} />
          </Field>
          <Field label={t('settings.cover')} hint={t('settings.uploadHint')}>
            <input className="input" placeholder="https://…" value={f.coverUrl ?? ''} onChange={(e) => set('coverUrl', e.target.value || null)} />
          </Field>
        </div>
      </Card>
      <Card title={t('common.language')}>
        <div className="form-grid">
          <Field label={t('settings.defaultLanguage')}>
            <select className="select" value={f.defaultLanguage} onChange={(e) => set('defaultLanguage', e.target.value)}>
              {(['fr', 'ar', 'en'] as Locale[]).map((l) => <option key={l} value={l}>{LOCALE_NAMES[l]}</option>)}
            </select>
          </Field>
          <Field label={t('settings.enabledLanguages')}>
            <div className="flex" style={{ paddingBlockStart: 8 }}>
              {(['fr', 'ar', 'en'] as Locale[]).map((l) => (
                <label key={l} className="checkbox-row">
                  <input type="checkbox" checked={f.enabledLanguages.includes(l)} onChange={() => toggleLang(l)} />
                  {LOCALE_NAMES[l]}
                </label>
              ))}
            </div>
          </Field>
        </div>
      </Card>
      <Card title={t('settings.dangerZone')}>
        <p className="muted small">{t('settings.dangerZoneHint')}</p>
      </Card>
    </div>
  );
}
