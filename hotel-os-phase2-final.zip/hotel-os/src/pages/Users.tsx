import React, { useState } from 'react';
import { useTranslation } from '@/i18n';
import { useHotel } from '@/contexts/HotelContext';
import { useAuth } from '@/contexts/AuthContext';
import { useAsync, useMutation } from '@/hooks/useAsync';
import { userService } from '@/services';
import { Avatar, Badge, Button, Card, Field, LoadingBlock, Modal, useToast } from '@/components/ui';
import { IconPlus } from '@/components/icons';
import type { Profile, Role } from '@/types';

const ROLES: Role[] = ['owner', 'manager', 'receptionist', 'housekeeping', 'accountant'];
const AVATAR_COLORS = ['#0f766e', '#7c3aed', '#b45309', '#0369a1', '#be185d'];

export default function Users() {
  const { t } = useTranslation();
  const { hotel } = useHotel();
  const { user: me } = useAuth();
  const toast = useToast();
  const hotelId = hotel?.id ?? '';
  const [editing, setEditing] = useState<Profile | null | 'new'>(null);

  const users = useAsync(() => userService.list(hotelId), [hotelId]);

  const toggleActive = useMutation(async (u: Profile) => {
    if (u.role === 'owner' && u.active) {
      const owners = (users.data ?? []).filter((x) => x.role === 'owner' && x.active);
      if (owners.length <= 1) {
        toast.push('error', t('users.lastAdminWarning'));
        return;
      }
    }
    await userService.update(u.id, { active: !u.active });
  }, () => users.reload());

  return (
    <div className="stack">
      <div className="page-head">
        <h1>{t('users.title')}</h1>
        <Button variant="primary" onClick={() => setEditing('new')}><IconPlus /> {t('users.add')}</Button>
      </div>
      {users.status === 'loading' && <LoadingBlock />}
      {users.status === 'success' && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('common.name')}</th>
                <th>{t('common.email')}</th>
                <th>{t('users.role')}</th>
                <th>{t('common.status')}</th>
                <th style={{ textAlign: 'end' }}>{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {(users.data ?? []).map((u) => (
                <tr key={u.id}>
                  <td>
                    <div className="flex">
                      <Avatar name={`${u.firstName} ${u.lastName}`} color={u.avatarColor} size="sm" />
                      <span className="cell-main">
                        {u.firstName} {u.lastName}
                        {u.id === me?.id && <span className="muted small"> ({t('common.profile')})</span>}
                      </span>
                    </div>
                  </td>
                  <td className="muted">{u.email}</td>
                  <td><span className="badge reserved">{t(`roles.${u.role}`)}</span></td>
                  <td>
                    <Badge status={u.active ? 'available' : 'out_of_service'} label={u.active ? t('common.active') : t('common.inactive')} />
                  </td>
                  <td>
                    <div className="row-actions">
                      <Button size="sm" onClick={() => setEditing(u)}>{t('common.edit')}</Button>
                      <Button size="sm" onClick={() => toggleActive.execute(u)}>
                        {u.active ? t('users.deactivate') : t('users.activate')}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editing !== null && (
        <UserForm
          hotelId={hotelId}
          initial={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); users.reload(); toast.push('success', t('users.inviteSent')); }}
        />
      )}
    </div>
  );
}

function UserForm({ hotelId, initial, onClose, onSaved }: {
  hotelId: string;
  initial: Profile | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useTranslation();
  const [f, setF] = useState({
    firstName: initial?.firstName ?? '',
    lastName: initial?.lastName ?? '',
    email: initial?.email ?? '',
    role: (initial?.role ?? 'receptionist') as Role,
  });
  const save = useMutation(async () => {
    if (initial) await userService.update(initial.id, f);
    else {
      await userService.create(hotelId, {
        ...f,
        active: true,
        avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
      });
    }
  }, onSaved);
  const valid = Boolean(f.firstName && f.email.includes('@'));
  return (
    <Modal
      title={t(initial ? 'users.edit' : 'users.add')}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="primary" disabled={!valid} loading={save.pending} onClick={() => save.execute()}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      {save.error && <div className="login-error" role="alert">{t(`errors.${save.error}` as never)}</div>}
      <div className="form-grid">
        <Field label={t('common.name')}><input className="input" value={f.firstName} onChange={(e) => setF({ ...f, firstName: e.target.value })} /></Field>
        <Field label=" "><input className="input" value={f.lastName} placeholder="—" onChange={(e) => setF({ ...f, lastName: e.target.value })} /></Field>
        <Field label={t('common.email')}><input className="input" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label={t('users.role')}>
          <select className="select" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
            {ROLES.map((r) => <option key={r} value={r}>{t(`roles.${r}`)}</option>)}
          </select>
        </Field>
      </div>
    </Modal>
  );
}
