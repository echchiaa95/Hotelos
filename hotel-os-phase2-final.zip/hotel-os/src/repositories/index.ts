// ── Repository wiring ─────────────────────────────────────────
// Single switching point between data sources:
//
//   VITE_DATA_SOURCE=mock     → in-memory demo repositories (default)
//   VITE_DATA_SOURCE=supabase → live Supabase repositories (RLS-protected)
//
// The service layer and every UI component are identical in both
// modes — only the exports below change.

import { DATA_SOURCE } from '@/lib/env';
import {
  mockGuestRepository,
  mockHotelRepository,
  mockHousekeepingRepository,
  mockNotificationRepository,
  mockPaymentRepository,
  mockReservationRepository,
  mockRoomRepository,
  mockRoomTypeRepository,
  mockServiceRepository,
  mockUserRepository,
} from './mock';
import {
  supabaseGuestRepository,
  supabaseHotelRepository,
  supabaseHousekeepingRepository,
  supabasePaymentRepository,
  supabaseReservationRepository,
  supabaseRoomRepository,
  supabaseRoomTypeRepository,
  supabaseServiceRepository,
  supabaseUserRepository,
} from './supabase';
import type {
  GuestRepository,
  HotelRepository,
  HousekeepingRepository,
  NotificationRepository,
  PaymentRepository,
  ReservationRepository,
  RoomRepository,
  RoomTypeRepository,
  ServiceRepository,
  UserRepository,
} from './interfaces';

export type {
  GuestRepository,
  HotelRepository,
  HousekeepingRepository,
  NotificationRepository,
  PaymentRepository,
  ReservationRepository,
  RoomRepository,
  RoomTypeRepository,
  ServiceRepository,
  UserRepository,
} from './interfaces';

const useSupabase = DATA_SOURCE === 'supabase';

export const hotelRepository: HotelRepository = useSupabase ? supabaseHotelRepository : mockHotelRepository;
export const roomTypeRepository: RoomTypeRepository = useSupabase ? supabaseRoomTypeRepository : mockRoomTypeRepository;
export const roomRepository: RoomRepository = useSupabase ? supabaseRoomRepository : mockRoomRepository;
export const guestRepository: GuestRepository = useSupabase ? supabaseGuestRepository : mockGuestRepository;
export const reservationRepository: ReservationRepository = useSupabase ? supabaseReservationRepository : mockReservationRepository;
export const paymentRepository: PaymentRepository = useSupabase ? supabasePaymentRepository : mockPaymentRepository;
export const serviceRepository: ServiceRepository = useSupabase ? supabaseServiceRepository : mockServiceRepository;
export const housekeepingRepository: HousekeepingRepository = useSupabase ? supabaseHousekeepingRepository : mockHousekeepingRepository;
export const userRepository: UserRepository = useSupabase ? supabaseUserRepository : mockUserRepository;

// Notifications have no database table yet. In supabase mode this is an
// explicit empty implementation (NO mock records); only mock mode reads
// the in-memory demo notifications.
const emptyNotificationRepository: NotificationRepository = {
  async list() {
    return [];
  },
  async markAllRead() {
    /* no notifications table yet */
  },
};

export const notificationRepository: NotificationRepository = useSupabase
  ? emptyNotificationRepository
  : mockNotificationRepository;
