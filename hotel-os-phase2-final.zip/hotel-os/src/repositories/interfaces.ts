// ── Repository interfaces ────────────────────────────────────
// The UI + service layer depend ONLY on these interfaces.
// Swap `repositories/mock` for `repositories/supabase` (same
// signatures, backed by PostgREST + RLS) without touching any
// component.

import type {
  Guest,
  Hotel,
  HotelService,
  HousekeepingTask,
  Payment,
  Profile,
  Reservation,
  ReservationFilters,
  ReservationService,
  Room,
  RoomFilters,
  RoomStatus,
  RoomStatusHistory,
  RoomType,
  UUID,
} from '@/types';

export interface HotelRepository {
  list(): Promise<Hotel[]>;
  getById(id: UUID): Promise<Hotel | null>;
  getBySlug(slug: string): Promise<Hotel | null>;
  update(id: UUID, patch: Partial<Omit<Hotel, 'id'>>): Promise<Hotel>;
}

export interface RoomTypeRepository {
  list(hotelId: UUID): Promise<RoomType[]>;
  get(id: UUID): Promise<RoomType | null>;
  create(hotelId: UUID, data: Omit<RoomType, 'id' | 'hotelId' | 'createdAt'>): Promise<RoomType>;
  update(id: UUID, patch: Partial<Omit<RoomType, 'id' | 'hotelId'>>): Promise<RoomType>;
  remove(id: UUID): Promise<void>;
}

export interface RoomRepository {
  list(hotelId: UUID, filters?: RoomFilters): Promise<Room[]>;
  get(id: UUID): Promise<Room | null>;
  create(hotelId: UUID, data: Omit<Room, 'id' | 'hotelId' | 'createdAt'>): Promise<Room>;
  update(id: UUID, patch: Partial<Omit<Room, 'id' | 'hotelId'>>): Promise<Room>;
  setStatus(id: UUID, status: RoomStatus, changedBy: UUID | null, reason: string): Promise<Room>;
  remove(id: UUID): Promise<void>;
  statusHistory(roomId: UUID): Promise<RoomStatusHistory[]>;
}

export interface GuestRepository {
  list(hotelId: UUID, search?: string): Promise<Guest[]>;
  get(id: UUID): Promise<Guest | null>;
  create(hotelId: UUID, data: Omit<Guest, 'id' | 'hotelId' | 'createdAt'>): Promise<Guest>;
  update(id: UUID, patch: Partial<Omit<Guest, 'id' | 'hotelId'>>): Promise<Guest>;
}

export interface ReservationRepository {
  list(hotelId: UUID, filters?: ReservationFilters): Promise<Reservation[]>;
  get(id: UUID): Promise<Reservation | null>;
  /** Throws HotelError('room_no_longer_available') on overlap — mirrors the DB constraint. */
  create(hotelId: UUID, data: Omit<Reservation, 'id' | 'hotelId' | 'createdAt' | 'updatedAt' | 'reference'>): Promise<Reservation>;
  update(id: UUID, patch: Partial<Omit<Reservation, 'id' | 'hotelId'>>): Promise<Reservation>;
  cancel(id: UUID): Promise<Reservation>;
  servicesOf(reservationId: UUID): Promise<ReservationService[]>;
  addService(hotelId: UUID, reservationId: UUID, serviceId: UUID, quantity: number, notes: string): Promise<ReservationService>;
  paymentsOf(reservationId: UUID): Promise<Payment[]>;
}

export interface PaymentRepository {
  list(hotelId: UUID, status?: Payment['status'] | 'all'): Promise<Payment[]>;
  create(hotelId: UUID, data: Omit<Payment, 'id' | 'hotelId' | 'createdAt'>): Promise<Payment>;
  update(id: UUID, patch: Partial<Omit<Payment, 'id' | 'hotelId'>>): Promise<Payment>;
}

export interface ServiceRepository {
  list(hotelId: UUID): Promise<HotelService[]>;
  get(id: UUID): Promise<HotelService | null>;
  create(hotelId: UUID, data: Omit<HotelService, 'id' | 'hotelId' | 'createdAt'>): Promise<HotelService>;
  update(id: UUID, patch: Partial<Omit<HotelService, 'id' | 'hotelId'>>): Promise<HotelService>;
}

export interface HousekeepingRepository {
  list(hotelId: UUID): Promise<HousekeepingTask[]>;
  create(hotelId: UUID, data: Omit<HousekeepingTask, 'id' | 'hotelId' | 'createdAt'>): Promise<HousekeepingTask>;
  update(id: UUID, patch: Partial<Omit<HousekeepingTask, 'id' | 'hotelId'>>): Promise<HousekeepingTask>;
}

export interface UserRepository {
  list(hotelId: UUID): Promise<Profile[]>;
  getById(id: UUID): Promise<Profile | null>;
  getByEmail(email: string): Promise<Profile | null>;
  create(hotelId: UUID, data: Omit<Profile, 'id' | 'hotelId' | 'createdAt'>): Promise<Profile>;
  update(id: UUID, patch: Partial<Omit<Profile, 'id' | 'hotelId'>>): Promise<Profile>;
}

export interface NotificationRepository {
  list(hotelId: UUID): Promise<{ id: UUID; title: { fr: string; ar: string; en: string }; read: boolean; createdAt: string }[]>;
  markAllRead(hotelId: UUID): Promise<void>;
}
