// ── Mock repositories (demo mode) ─────────────────────────────
// In-memory implementations of the repository interfaces.
// They enforce the same invariants the Supabase layer will
// enforce via PostgreSQL constraints (e.g. no overlapping
// active reservations for the same room).

import { getDB } from '@/mock/db';
import type {
  Guest,
  Hotel,
  HotelService,
  HousekeepingTask,
  Payment,
  Profile,
  Reservation,
  ReservationFilters,
  ReservationService,
  Room,
  RoomFilters,
  RoomStatusHistory,
  RoomType,
  UUID,
} from '@/types';
import { HotelError } from '@/types';
import { bookingReference, rangesOverlap, todayISO, uuid } from '@/utils/format';
import type {
  GuestRepository,
  HotelRepository,
  HousekeepingRepository,
  NotificationRepository,
  PaymentRepository,
  ReservationRepository,
  RoomRepository,
  RoomTypeRepository,
  ServiceRepository,
  UserRepository,
} from './interfaces';

const delay = (ms = 140) => new Promise((r) => setTimeout(r, ms));

export const ACTIVE_RESERVATION_STATUSES: Reservation['status'][] = ['pending', 'confirmed', 'checked_in'];

export const mockHotelRepository: HotelRepository = {
  async list() {
    await delay();
    return getDB().hotels;
  },
  async getById(id) {
    await delay();
    return getDB().hotels.find((h) => h.id === id) ?? null;
  },
  async getBySlug(slug) {
    await delay();
    return getDB().hotels.find((h) => h.slug === slug) ?? null;
  },
  async update(id, patch) {
    await delay();
    const h = getDB().hotels.find((x) => x.id === id);
    if (!h) throw new HotelError('not_found');
    Object.assign(h, patch);
    return h;
  },
};

export const mockRoomTypeRepository: RoomTypeRepository = {
  async list(hotelId) {
    await delay();
    return getDB().roomTypes.filter((t) => t.hotelId === hotelId);
  },
  async get(id) {
    await delay();
    return getDB().roomTypes.find((t) => t.id === id) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    const t: RoomType = { ...data, id: uuid(), hotelId, createdAt: todayISO() };
    getDB().roomTypes.push(t);
    return t;
  },
  async update(id, patch) {
    await delay();
    const t = getDB().roomTypes.find((x) => x.id === id);
    if (!t) throw new HotelError('not_found');
    Object.assign(t, patch);
    return t;
  },
  async remove(id) {
    await delay();
    const db = getDB();
    if (db.rooms.some((r) => r.roomTypeId === id)) throw new HotelError('room_type_in_use');
    db.roomTypes = db.roomTypes.filter((t) => t.id !== id);
  },
};

export const mockRoomRepository: RoomRepository = {
  async list(hotelId, filters) {
    await delay();
    let rooms = getDB().rooms.filter((r) => r.hotelId === hotelId);
    if (filters) {
      const { search, floor, status, roomTypeId } = filters;
      if (search) {
        const q = search.toLowerCase();
        rooms = rooms.filter((r) => r.number.toLowerCase().includes(q) || r.notes.toLowerCase().includes(q));
      }
      if (floor !== undefined && floor !== 'all') rooms = rooms.filter((r) => r.floor === floor);
      if (status && status !== 'all') rooms = rooms.filter((r) => r.status === status);
      if (roomTypeId && roomTypeId !== 'all') rooms = rooms.filter((r) => r.roomTypeId === roomTypeId);
    }
    return rooms.sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));
  },
  async get(id) {
    await delay();
    return getDB().rooms.find((r) => r.id === id) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    const r: Room = { ...data, id: uuid(), hotelId, createdAt: todayISO() };
    getDB().rooms.push(r);
    return r;
  },
  async update(id, patch) {
    await delay();
    const r = getDB().rooms.find((x) => x.id === id);
    if (!r) throw new HotelError('not_found');
    Object.assign(r, patch);
    return r;
  },
  async setStatus(id, status, changedBy, reason) {
    await delay();
    const db = getDB();
    const r = db.rooms.find((x) => x.id === id);
    if (!r) throw new HotelError('not_found');
    const from = r.status;
    r.status = status;
    const entry: RoomStatusHistory = {
      id: uuid(), hotelId: r.hotelId, roomId: r.id, fromStatus: from, toStatus: status,
      changedBy, reason, changedAt: new Date().toISOString(),
    };
    db.roomStatusHistory.push(entry);
    return r;
  },
  async remove(id) {
    await delay();
    const db = getDB();
    const blocked = db.reservations.some(
      (r) => r.roomId === id && ACTIVE_RESERVATION_STATUSES.includes(r.status),
    );
    if (blocked) throw new HotelError('room_in_use');
    db.rooms = db.rooms.filter((r) => r.id !== id);
  },
  async statusHistory(roomId) {
    await delay();
    return getDB().roomStatusHistory.filter((h) => h.roomId === roomId).sort((a, b) => b.changedAt.localeCompare(a.changedAt));
  },
};

export const mockGuestRepository: GuestRepository = {
  async list(hotelId, search) {
    await delay();
    let guests = getDB().guests.filter((g) => g.hotelId === hotelId);
    if (search) {
      const q = search.toLowerCase();
      guests = guests.filter(
        (g) =>
          g.firstName.toLowerCase().includes(q) ||
          g.lastName.toLowerCase().includes(q) ||
          g.email.toLowerCase().includes(q) ||
          g.phone.toLowerCase().includes(q),
      );
    }
    return guests.sort((a, b) => a.lastName.localeCompare(b.lastName));
  },
  async get(id) {
    await delay();
    return getDB().guests.find((g) => g.id === id) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    const g: Guest = { ...data, id: uuid(), hotelId, createdAt: todayISO() };
    getDB().guests.push(g);
    return g;
  },
  async update(id, patch) {
    await delay();
    const g = getDB().guests.find((x) => x.id === id);
    if (!g) throw new HotelError('not_found');
    Object.assign(g, patch);
    return g;
  },
};

function assertNoOverlap(roomId: UUID, checkIn: string, checkOut: string, ignoreId?: UUID) {
  const db = getDB();
  const clash = db.reservations.some(
    (r) =>
      r.roomId === roomId &&
      r.id !== ignoreId &&
      ACTIVE_RESERVATION_STATUSES.includes(r.status) &&
      rangesOverlap(checkIn, checkOut, r.checkIn, r.checkOut),
  );
  if (clash) throw new HotelError('room_no_longer_available');
}

export const mockReservationRepository: ReservationRepository = {
  async list(hotelId, filters) {
    await delay();
    let list = getDB().reservations.filter((r) => r.hotelId === hotelId);
    if (filters) {
      const { search, status, source, dateFrom, dateTo } = filters;
      if (search) {
        const q = search.toLowerCase();
        const db = getDB();
        list = list.filter((r) => {
          const g = db.guests.find((x) => x.id === r.guestId);
          const room = db.rooms.find((x) => x.id === r.roomId);
          return (
            r.reference.toLowerCase().includes(q) ||
            g?.firstName.toLowerCase().includes(q) ||
            g?.lastName.toLowerCase().includes(q) ||
            room?.number.includes(q)
          );
        });
      }
      if (status && status !== 'all') list = list.filter((r) => r.status === status);
      if (source && source !== 'all') list = list.filter((r) => r.source === source);
      if (dateFrom) list = list.filter((r) => r.checkOut > dateFrom);
      if (dateTo) list = list.filter((r) => r.checkIn < dateTo);
    }
    return list.sort((a, b) => b.checkIn.localeCompare(a.checkIn));
  },
  async get(id) {
    await delay();
    return getDB().reservations.find((r) => r.id === id) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    assertNoOverlap(data.roomId, data.checkIn, data.checkOut);
    const r: Reservation = {
      ...data,
      id: uuid(),
      hotelId,
      reference: bookingReference(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    getDB().reservations.push(r);
    return r;
  },
  async update(id, patch) {
    await delay();
    const r = getDB().reservations.find((x) => x.id === id);
    if (!r) throw new HotelError('not_found');
    const next = { ...r, ...patch };
    if (
      (patch.roomId || patch.checkIn || patch.checkOut) &&
      ACTIVE_RESERVATION_STATUSES.includes(next.status)
    ) {
      assertNoOverlap(next.roomId, next.checkIn, next.checkOut, id);
    }
    Object.assign(r, patch, { updatedAt: new Date().toISOString() });
    return r;
  },
  async cancel(id) {
    await delay();
    const r = getDB().reservations.find((x) => x.id === id);
    if (!r) throw new HotelError('not_found');
    r.status = 'cancelled';
    r.updatedAt = new Date().toISOString();
    return r;
  },
  async servicesOf(reservationId) {
    await delay();
    return getDB().reservationServices.filter((s) => s.reservationId === reservationId);
  },
  async addService(hotelId, reservationId, serviceId, quantity, notes) {
    await delay();
    const svc = getDB().services.find((s) => s.id === serviceId);
    if (!svc) throw new HotelError('not_found');
    const entry: ReservationService = {
      id: uuid(), hotelId, reservationId, serviceId, quantity,
      unitPrice: svc.price, notes, createdAt: new Date().toISOString(),
    };
    getDB().reservationServices.push(entry);
    return entry;
  },
  async paymentsOf(reservationId) {
    await delay();
    return getDB().payments.filter((p) => p.reservationId === reservationId).sort((a, b) => b.paidAt.localeCompare(a.paidAt));
  },
};

export const mockPaymentRepository: PaymentRepository = {
  async list(hotelId, status) {
    await delay();
    let list = getDB().payments.filter((p) => p.hotelId === hotelId);
    if (status && status !== 'all') list = list.filter((p) => p.status === status);
    return list.sort((a, b) => b.paidAt.localeCompare(a.paidAt));
  },
  async create(hotelId, data) {
    await delay();
    const p: Payment = { ...data, id: uuid(), hotelId, createdAt: new Date().toISOString() };
    getDB().payments.push(p);
    return p;
  },
  async update(id, patch) {
    await delay();
    const p = getDB().payments.find((x) => x.id === id);
    if (!p) throw new HotelError('not_found');
    Object.assign(p, patch);
    return p;
  },
};

export const mockServiceRepository: ServiceRepository = {
  async list(hotelId) {
    await delay();
    return getDB().services.filter((s) => s.hotelId === hotelId);
  },
  async get(id) {
    await delay();
    return getDB().services.find((s) => s.id === id) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    const s: HotelService = { ...data, id: uuid(), hotelId, createdAt: todayISO() };
    getDB().services.push(s);
    return s;
  },
  async update(id, patch) {
    await delay();
    const s = getDB().services.find((x) => x.id === id);
    if (!s) throw new HotelError('not_found');
    Object.assign(s, patch);
    return s;
  },
};

export const mockHousekeepingRepository: HousekeepingRepository = {
  async list(hotelId) {
    await delay();
    return getDB().housekeepingTasks.filter((t) => t.hotelId === hotelId);
  },
  async create(hotelId, data) {
    await delay();
    const t: HousekeepingTask = { ...data, id: uuid(), hotelId, createdAt: new Date().toISOString() };
    getDB().housekeepingTasks.push(t);
    return t;
  },
  async update(id, patch) {
    await delay();
    const t = getDB().housekeepingTasks.find((x) => x.id === id);
    if (!t) throw new HotelError('not_found');
    Object.assign(t, patch, {
      completedAt: patch.status === 'completed' ? new Date().toISOString() : patch.status ? null : t.completedAt,
    });
    return t;
  },
};

export const mockUserRepository: UserRepository = {
  async list(hotelId) {
    await delay();
    return getDB().profiles.filter((p) => p.hotelId === hotelId);
  },
  async getById(id) {
    await delay();
    return getDB().profiles.find((p) => p.id === id) ?? null;
  },
  async getByEmail(email) {
    await delay(60);
    return getDB().profiles.find((p) => p.email.toLowerCase() === email.toLowerCase()) ?? null;
  },
  async create(hotelId, data) {
    await delay();
    const p: Profile = { ...data, id: uuid(), hotelId, createdAt: todayISO() };
    getDB().profiles.push(p);
    return p;
  },
  async update(id, patch) {
    await delay();
    const p = getDB().profiles.find((x) => x.id === id);
    if (!p) throw new HotelError('not_found');
    Object.assign(p, patch);
    return p;
  },
};

export const mockNotificationRepository: NotificationRepository = {
  async list(hotelId) {
    await delay(80);
    return getDB()
      .notifications.filter((n) => n.hotelId === hotelId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  },
  async markAllRead(hotelId) {
    await delay(80);
    getDB().notifications.forEach((n) => {
      if (n.hotelId === hotelId) n.read = true;
    });
  },
};
