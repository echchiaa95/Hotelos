// ── Availability engine ───────────────────────────────────────
// Two implementations behind one interface:
//
//   mock     → demo calculation over the in-memory store.
//   supabase → RPC `search_available_rooms` — the DATABASE is the
//              authority against double bookings (exclusion
//              constraint), never the browser.
//
// The UI always handles HotelError('room_no_longer_available')
// gracefully, in FR / AR / EN.

import type { AvailabilityQuery, RoomTypeAvailability, UUID } from '@/types';
import { HotelError } from '@/types';
import { DATA_SOURCE } from '@/lib/env';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';
import { guard } from '@/lib/errors';
import { mapRoomType } from '@/lib/mappers';
import type { Room } from '@/types';
import { getDB } from '@/mock/db';
import { ACTIVE_RESERVATION_STATUSES } from '@/repositories/mock';
import { rangesOverlap, nightsBetween } from '@/utils/format';

/* ── Supabase: RPC search_available_rooms ── */
async function searchViaRpc(hotelId: UUID, query: AvailabilityQuery): Promise<RoomTypeAvailability[]> {
  if (!supabase || !isSupabaseConfigured) {
    throw new HotelError('supabase_not_configured');
  }
  const nights = nightsBetween(query.checkIn, query.checkOut);
  if (nights < 1) return [];

  const { data, error } = await supabase.rpc('search_available_rooms', {
    p_hotel_id: hotelId,
    p_check_in: query.checkIn,
    p_check_out: query.checkOut,
    p_guests: query.guests,
  });
  if (error) {
    await guard(Promise.reject(error));
    throw new HotelError('generic');
  }

  // The RPC returns one row per available room, carrying its room type.
  // Group by room type and attach the available room list.
  type RpcRow = Record<string, unknown>;
  const groups = new Map<string, { typeRow: RpcRow; rooms: Room[] }>();
  for (const raw of (data ?? []) as RpcRow[]) {
    const typeId = String(raw.room_type_id ?? '');
    if (!groups.has(typeId)) {
      groups.set(typeId, { typeRow: raw, rooms: [] });
    }
    groups.get(typeId)!.rooms.push({
      id: String(raw.room_id ?? raw.id),
      hotelId: String(raw.hotel_id ?? hotelId),
      number: String(raw.number ?? ''),
      roomTypeId: typeId,
      floor: Number(raw.floor ?? 0),
      status: (String(raw.status ?? 'available')) as Room['status'],
      notes: String(raw.notes ?? ''),
      createdAt: String(raw.created_at ?? ''),
    });
  }

  const results: RoomTypeAvailability[] = [];
  for (const { typeRow, rooms } of groups.values()) {
    const roomType = mapRoomType({
      id: typeRow.room_type_id ?? typeRow.id,
      hotel_id: hotelId,
      name: typeRow.name,
      description: typeRow.description,
      base_price: typeRow.base_price,
      max_guests: typeRow.max_guests,
      beds: typeRow.beds,
      size: typeRow.size,
      amenities: typeRow.amenities,
      images: typeRow.images,
      active: typeRow.active ?? true,
      created_at: typeRow.created_at,
    });
    const totalPrice = Number(typeRow.total_price ?? roomType.basePrice * nights);
    results.push({
      roomType,
      availableRooms: rooms.sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true })),
      totalPrice,
      nights: Number(typeRow.nights ?? nights),
    });
  }
  return results.sort((a, b) => a.totalPrice - b.totalPrice);
}

/* ── Mock: demo availability over the in-memory store ── */
async function searchMock(hotelId: UUID, query: AvailabilityQuery): Promise<RoomTypeAvailability[]> {
  await new Promise((r) => setTimeout(r, 250));
  const db = getDB();
  const nights = nightsBetween(query.checkIn, query.checkOut);
  if (nights < 1) return [];

  const blocking = (room: Room): boolean => {
    if (room.status === 'out_of_service') return true;
    const today = new Date().toISOString().slice(0, 10);
    const touchesToday = query.checkIn <= today && today < query.checkOut;
    if (touchesToday && room.status === 'maintenance') return true;
    return db.reservations.some(
      (r) =>
        r.roomId === room.id &&
        r.hotelId === hotelId &&
        ACTIVE_RESERVATION_STATUSES.includes(r.status) &&
        rangesOverlap(query.checkIn, query.checkOut, r.checkIn, r.checkOut),
    );
  };

  const rooms = db.rooms.filter((r) => r.hotelId === hotelId && !blocking(r));
  const types = db.roomTypes.filter((t) => t.hotelId === hotelId && t.active);

  const results: RoomTypeAvailability[] = [];
  for (const type of types) {
    if (type.maxGuests < query.guests) continue;
    const availableRooms = rooms
      .filter((r) => r.roomTypeId === type.id)
      .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));
    if (availableRooms.length === 0) continue;
    results.push({
      roomType: type,
      availableRooms,
      totalPrice: type.basePrice * nights,
      nights,
    });
  }
  return results.sort((a, b) => a.totalPrice - b.totalPrice);
}

export const availabilityService = {
  search(hotelId: UUID, query: AvailabilityQuery): Promise<RoomTypeAvailability[]> {
    return DATA_SOURCE === 'supabase' ? searchViaRpc(hotelId, query) : searchMock(hotelId, query);
  },
};
