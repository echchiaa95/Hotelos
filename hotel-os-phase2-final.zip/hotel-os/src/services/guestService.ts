import type { Guest, UUID } from '@/types';
import { guestRepository, reservationRepository } from '@/repositories';

export const guestService = {
  list(hotelId: UUID, search?: string): Promise<Guest[]> {
    return guestRepository.list(hotelId, search);
  },
  get(id: UUID): Promise<Guest | null> {
    return guestRepository.get(id);
  },
  create(hotelId: UUID, data: Omit<Guest, 'id' | 'hotelId' | 'createdAt'>): Promise<Guest> {
    return guestRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<Guest, 'id' | 'hotelId'>>): Promise<Guest> {
    return guestRepository.update(id, patch);
  },
  /** Full stay history + aggregates for the guest profile page. */
  async stats(hotelId: UUID, guestId: UUID) {
    const reservations = (await reservationRepository.list(hotelId)).filter(
      (r) => r.guestId === guestId && r.status !== 'cancelled',
    );
    const past = reservations.filter((r) => r.status === 'checked_out');
    const current = reservations.find((r) => r.status === 'checked_in') ?? null;
    const upcoming = reservations
      .filter((r) => r.status === 'confirmed' || r.status === 'pending')
      .sort((a, b) => a.checkIn.localeCompare(b.checkIn));
    return {
      reservations,
      past: past.sort((a, b) => b.checkIn.localeCompare(a.checkIn)),
      current,
      upcoming,
      totalStays: past.length + (current ? 1 : 0),
      totalSpending: past.reduce((s, r) => s + r.totalAmount, 0) + (current?.totalAmount ?? 0),
    };
  },
};
