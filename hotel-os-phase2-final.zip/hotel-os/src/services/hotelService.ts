import type { Hotel, UUID } from '@/types';
import { hotelRepository } from '@/repositories';

export const hotelService = {
  list(): Promise<Hotel[]> {
    return hotelRepository.list();
  },
  getById(id: UUID): Promise<Hotel | null> {
    return hotelRepository.getById(id);
  },
  getBySlug(slug: string): Promise<Hotel | null> {
    return hotelRepository.getBySlug(slug);
  },
  update(id: UUID, patch: Partial<Omit<Hotel, 'id'>>): Promise<Hotel> {
    return hotelRepository.update(id, patch);
  },
};
