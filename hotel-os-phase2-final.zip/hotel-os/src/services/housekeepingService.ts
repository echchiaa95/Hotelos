import type { HousekeepingTask, UUID } from '@/types';
import { housekeepingRepository, roomRepository } from '@/repositories';

export const housekeepingService = {
  list(hotelId: UUID): Promise<HousekeepingTask[]> {
    return housekeepingRepository.list(hotelId);
  },
  create(hotelId: UUID, data: Omit<HousekeepingTask, 'id' | 'hotelId' | 'createdAt'>): Promise<HousekeepingTask> {
    return housekeepingRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<HousekeepingTask, 'id' | 'hotelId'>>): Promise<HousekeepingTask> {
    return housekeepingRepository.update(id, patch);
  },
  async start(id: UUID): Promise<HousekeepingTask> {
    return housekeepingRepository.update(id, { status: 'in_progress' });
  },
  async complete(id: UUID): Promise<HousekeepingTask> {
    return housekeepingRepository.update(id, { status: 'completed' });
  },
  /** Final workflow step: housekeeping done → room available again. */
  async completeAndRelease(id: UUID, userId: UUID): Promise<HousekeepingTask> {
    const task = await housekeepingRepository.update(id, { status: 'completed' });
    await roomRepository.setStatus(task.roomId, 'available', userId, 'housekeeping completed');
    return task;
  },
};
