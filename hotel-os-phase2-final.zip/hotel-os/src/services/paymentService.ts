import type { Payment, UUID } from '@/types';
import { paymentRepository, reservationRepository } from '@/repositories';

export const paymentService = {
  list(hotelId: UUID, status?: Payment['status'] | 'all'): Promise<Payment[]> {
    return paymentRepository.list(hotelId, status);
  },
  create(hotelId: UUID, data: Omit<Payment, 'id' | 'hotelId' | 'createdAt'>): Promise<Payment> {
    return paymentRepository.create(hotelId, data);
  },
  /** Records a payment and updates the reservation's paid amount. */
  async record(hotelId: UUID, reservationId: UUID, data: Omit<Payment, 'id' | 'hotelId' | 'createdAt' | 'reservationId'>): Promise<Payment> {
    const payment = await paymentRepository.create(hotelId, { ...data, reservationId });
    const r = await reservationRepository.get(reservationId);
    if (r && payment.status === 'paid') {
      await reservationRepository.update(reservationId, { paidAmount: r.paidAmount + payment.amount });
    }
    return payment;
  },
};
