// ── Public booking creation ───────────────────────────────────
// supabase → RPC `create_public_booking` (SECURITY DEFINER). The
//            browser NEVER inserts into guests/reservations as anon;
//            price, availability and the booking reference are all
//            decided by the database.
// mock     → demo behaviour over the in-memory repositories.

import type { Hotel, RoomTypeAvailability } from '@/types';
import { HotelError } from '@/types';
import { DATA_SOURCE } from '@/lib/env';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';
import { guard } from '@/lib/errors';
import { guestRepository, reservationRepository } from '@/repositories';

export interface PublicBookingInput {
  hotel: Hotel;
  picked: RoomTypeAvailability;
  checkIn: string;
  checkOut: string;
  guests: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  requests: string;
}

export interface PublicBookingResult {
  reference: string;
}

async function viaRpc(i: PublicBookingInput): Promise<PublicBookingResult> {
  if (!supabase || !isSupabaseConfigured) throw new HotelError('supabase_not_configured');
  const { data, error } = await supabase.rpc('create_public_booking', {
    p_hotel_id: i.hotel.id,
    p_room_id: i.picked.availableRooms[0].id,
    p_check_in: i.checkIn,
    p_check_out: i.checkOut,
    p_guests: i.guests,
    p_first_name: i.firstName,
    p_last_name: i.lastName,
    p_email: i.email,
    p_phone: i.phone,
    p_special_requests: i.requests,
  });
  if (error) {
    await guard(Promise.reject(error));
    throw new HotelError('generic');
  }
  const ref = (data as { booking_reference?: string } | null)?.booking_reference;
  if (!ref) throw new HotelError('generic');
  return { reference: ref };
}

async function viaMock(i: PublicBookingInput): Promise<PublicBookingResult> {
  const guest = await guestRepository.create(i.hotel.id, {
    firstName: i.firstName,
    lastName: i.lastName,
    email: i.email,
    phone: i.phone,
    nationality: '',
    documentType: 'passport',
    documentNumber: '',
    dateOfBirth: null,
    notes: 'Portal booking',
  });
  const r = await reservationRepository.create(i.hotel.id, {
    guestId: guest.id,
    roomId: i.picked.availableRooms[0].id,
    checkIn: i.checkIn,
    checkOut: i.checkOut,
    adults: i.guests,
    children: 0,
    status: 'pending',
    source: 'direct',
    totalAmount: i.picked.totalPrice,
    paidAmount: 0,
    currency: i.hotel.currency,
    specialRequests: i.requests,
  });
  return { reference: r.reference };
}

export const publicBookingService = {
  create(input: PublicBookingInput): Promise<PublicBookingResult> {
    return DATA_SOURCE === 'supabase' ? viaRpc(input) : viaMock(input);
  },
};
