// ── Reporting service ─────────────────────────────────────────
// Aggregations computed over the REPOSITORY layer — identical
// logic in mock and Supabase modes, so dashboards/reports never
// leak demo data into production (and vice versa).

import type { DashboardStats, Payment, Reservation, Room, RoomStatus, UUID } from '@/types';
import { guestRepository, hotelRepository, paymentRepository, reservationRepository, roomRepository, roomTypeRepository } from '@/repositories';
import { addDays, todayISO } from '@/utils/format';

const ACTIVE: Reservation['status'][] = ['confirmed', 'checked_in'];

export interface DayPoint {
  date: string;
  value: number;
}

export interface SourcePoint {
  source: Reservation['source'];
  count: number;
}

export interface RoomPerfRow {
  roomId: UUID;
  number: string;
  roomTypeName: string;
  bookings: number;
  roomNights: number;
  revenue: number;
}

interface ReportData {
  rooms: Room[];
  reservations: Reservation[];
  payments: Payment[];
  currency: string;
}

/** Loads everything through repositories (respects VITE_DATA_SOURCE + RLS). */
async function loadData(hotelId: UUID): Promise<ReportData> {
  const [rooms, reservations, payments, hotel] = await Promise.all([
    roomRepository.list(hotelId),
    reservationRepository.list(hotelId),
    paymentRepository.list(hotelId, 'all'),
    hotelRepository.getById(hotelId),
  ]);
  return { rooms, reservations, payments, currency: hotel?.currency ?? 'MAD' };
}

export const reportService = {
  async dashboard(hotelId: UUID): Promise<DashboardStats> {
    const { rooms, reservations, payments, currency } = await loadData(hotelId);
    const today = todayISO();

    const roomCounts: Record<RoomStatus, number> = {
      available: 0, reserved: 0, occupied: 0, cleaning: 0, maintenance: 0, out_of_service: 0,
    };
    rooms.forEach((r) => { roomCounts[r.status] += 1; });

    const todayCheckIns = reservations.filter((r) => r.checkIn === today && (r.status === 'confirmed' || r.status === 'pending')).length;
    const todayCheckOuts = reservations.filter((r) => r.checkOut === today && r.status === 'checked_in').length;
    const weekAgo = addDays(today, -7);
    const newReservations = reservations.filter((r) => r.createdAt.slice(0, 10) >= weekAgo && r.status !== 'cancelled').length;
    const pendingReservations = reservations.filter((r) => r.status === 'pending').length;

    // Revenue comes from actual payment records.
    const todayRevenue = payments
      .filter((p) => p.status === 'paid' && p.paidAt.slice(0, 10) === today)
      .reduce((s, p) => s + p.amount, 0);
    const monthStart = today.slice(0, 8) + '01';
    const monthRevenue = reservations
      .filter((r) => r.checkIn >= monthStart && (r.status === 'checked_out' || r.status === 'checked_in' || r.status === 'confirmed'))
      .reduce((s, r) => s + r.totalAmount, 0);
    const outstandingPayments = reservations
      .filter((r) => ACTIVE.includes(r.status))
      .reduce((s, r) => s + Math.max(0, r.totalAmount - r.paidAmount), 0);

    const occupied = roomCounts.occupied;
    const sellable = rooms.length - roomCounts.out_of_service;
    const occupancyRate = sellable ? Math.round((occupied / sellable) * 100) : 0;

    const monthStays = reservations.filter(
      (r) => (r.status === 'checked_out' || r.status === 'checked_in') && r.checkIn >= monthStart,
    );
    const adr =
      monthStays.length > 0
        ? Math.round(monthStays.reduce((s, r) => s + r.totalAmount / Math.max(1, nights(r)), 0) / monthStays.length)
        : 0;

    return {
      rooms: roomCounts,
      todayCheckIns, todayCheckOuts, newReservations, pendingReservations,
      todayRevenue, monthRevenue, outstandingPayments,
      occupancyRate, adr, revpar: Math.round(adr * (occupancyRate / 100)),
      currency,
    };
  },

  async revenueByDay(hotelId: UUID, from: string, to: string): Promise<DayPoint[]> {
    const { reservations } = await loadData(hotelId);
    const points: DayPoint[] = [];
    for (let d = from; d < to; d = addDays(d, 1)) {
      const day = d;
      const revenue = reservations
        .filter(
          (r) =>
            r.status !== 'cancelled' &&
            r.status !== 'no_show' &&
            r.checkIn <= day &&
            day < r.checkOut,
        )
        .reduce((s, r) => s + r.totalAmount / Math.max(1, nights(r)), 0);
      points.push({ date: day, value: Math.round(revenue) });
    }
    return points;
  },

  async occupancyByDay(hotelId: UUID, from: string, to: string): Promise<DayPoint[]> {
    const { rooms, reservations } = await loadData(hotelId);
    const total = rooms.filter((r) => r.status !== 'out_of_service').length || 1;
    const points: DayPoint[] = [];
    for (let d = from; d < to; d = addDays(d, 1)) {
      const day = d;
      const occupied = reservations.filter(
        (r) => (r.status === 'checked_in' || r.status === 'checked_out') && r.checkIn <= day && day < r.checkOut,
      ).length;
      points.push({ date: day, value: Math.round((occupied / total) * 100) });
    }
    return points;
  },

  async bySource(hotelId: UUID, from: string, to: string): Promise<SourcePoint[]> {
    const { reservations } = await loadData(hotelId);
    const counts = new Map<Reservation['source'], number>();
    reservations
      .filter((r) => r.checkIn >= from && r.checkIn < to && r.status !== 'cancelled')
      .forEach((r) => counts.set(r.source, (counts.get(r.source) ?? 0) + 1));
    return [...counts.entries()].map(([source, count]) => ({ source, count })).sort((a, b) => b.count - a.count);
  },

  async byStatus(hotelId: UUID, from: string, to: string): Promise<{ status: Reservation['status']; count: number }[]> {
    const { reservations } = await loadData(hotelId);
    const counts = new Map<Reservation['status'], number>();
    reservations
      .filter((r) => r.checkIn >= from && r.checkIn < to)
      .forEach((r) => counts.set(r.status, (counts.get(r.status) ?? 0) + 1));
    return [...counts.entries()].map(([status, count]) => ({ status, count })).sort((a, b) => b.count - a.count);
  },

  async checkInOut(hotelId: UUID, from: string, to: string): Promise<{ date: string; checkIns: number; checkOuts: number }[]> {
    const { reservations } = await loadData(hotelId);
    const rows: { date: string; checkIns: number; checkOuts: number }[] = [];
    for (let d = from; d < to; d = addDays(d, 1)) {
      const day = d;
      const dayRes = reservations.filter((r) => r.status !== 'cancelled' && r.status !== 'no_show');
      rows.push({
        date: day,
        checkIns: dayRes.filter((r) => r.checkIn === day).length,
        checkOuts: dayRes.filter((r) => r.checkOut === day && (r.status === 'checked_out' || r.status === 'checked_in')).length,
      });
    }
    return rows;
  },

  async roomPerformance(hotelId: UUID, from: string, to: string): Promise<RoomPerfRow[]> {
    const { rooms, reservations } = await loadData(hotelId);
    const types = await roomTypeRepository.list(hotelId);
    const rows: RoomPerfRow[] = [];
    for (const room of rooms) {
      const type = types.find((t) => t.id === room.roomTypeId);
      const res = reservations.filter(
        (r) => r.roomId === room.id && r.status !== 'cancelled' && r.checkIn < to && r.checkOut > from,
      );
      const roomNights = res.reduce((s, r) => {
        const start = r.checkIn > from ? r.checkIn : from;
        const end = r.checkOut < to ? r.checkOut : to;
        return s + Math.max(0, Math.round((new Date(end).getTime() - new Date(start).getTime()) / 86400000));
      }, 0);
      const revenue = res.reduce((s, r) => s + r.totalAmount, 0);
      rows.push({ roomId: room.id, number: room.number, roomTypeName: type?.name.fr ?? '', bookings: res.length, roomNights, revenue });
    }
    return rows.sort((a, b) => b.revenue - a.revenue);
  },

  async paymentsSummary(hotelId: UUID, from: string, to: string) {
    const { payments } = await loadData(hotelId);
    const inRange = payments.filter((p) => p.paidAt.slice(0, 10) >= from && p.paidAt.slice(0, 10) < to);
    const by = (s: typeof inRange) => s.reduce((sum, p) => sum + p.amount, 0);
    return {
      paid: by(inRange.filter((p) => p.status === 'paid')),
      refunded: by(inRange.filter((p) => p.status === 'refunded')),
      pending: by(inRange.filter((p) => p.status === 'pending')),
      failed: by(inRange.filter((p) => p.status === 'failed')),
      byMethod: (['cash', 'card', 'bank_transfer', 'online', 'other'] as const).map((m) => ({
        method: m,
        amount: by(inRange.filter((p) => p.method === m && p.status === 'paid')),
      })),
    };
  },

  async outstanding(hotelId: UUID): Promise<Reservation[]> {
    const { reservations } = await loadData(hotelId);
    return reservations
      .filter((r) => ACTIVE.includes(r.status) && r.totalAmount - r.paidAmount > 0)
      .sort((a, b) => b.checkIn.localeCompare(a.checkIn));
  },

  async guestStats(hotelId: UUID) {
    const [guests, { reservations }] = await Promise.all([
      guestRepository.list(hotelId),
      loadData(hotelId),
    ]);
    const valid = reservations.filter((r) => r.status !== 'cancelled' && r.status !== 'no_show');
    const staysByGuest = new Map<UUID, number>();
    valid.forEach((r) => staysByGuest.set(r.guestId, (staysByGuest.get(r.guestId) ?? 0) + 1));
    const avgStay =
      valid.length > 0 ? Math.round((valid.reduce((s, r) => s + nights(r), 0) / valid.length) * 10) / 10 : 0;
    return {
      totalGuests: guests.length,
      returning: [...staysByGuest.values()].filter((n) => n > 1).length,
      avgStay,
    };
  },
};

function nights(r: Reservation): number {
  return Math.max(1, Math.round((new Date(r.checkOut).getTime() - new Date(r.checkIn).getTime()) / 86400000));
}
