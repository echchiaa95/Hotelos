import type {
  Payment,
  Reservation,
  ReservationFilters,
  ReservationService,
  UUID,
} from '@/types';
import { paymentRepository, reservationRepository, roomRepository } from '@/repositories';

export const reservationService = {
  list(hotelId: UUID, filters?: ReservationFilters): Promise<Reservation[]> {
    return reservationRepository.list(hotelId, filters);
  },
  get(id: UUID): Promise<Reservation | null> {
    return reservationRepository.get(id);
  },
  create(hotelId: UUID, data: Omit<Reservation, 'id' | 'hotelId' | 'createdAt' | 'updatedAt' | 'reference'>): Promise<Reservation> {
    return reservationRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<Reservation, 'id' | 'hotelId'>>): Promise<Reservation> {
    return reservationRepository.update(id, patch);
  },
  cancel(id: UUID): Promise<Reservation> {
    return reservationRepository.cancel(id);
  },
  servicesOf(reservationId: UUID): Promise<ReservationService[]> {
    return reservationRepository.servicesOf(reservationId);
  },
  addService(hotelId: UUID, reservationId: UUID, serviceId: UUID, quantity: number, notes: string): Promise<ReservationService> {
    return reservationRepository.addService(hotelId, reservationId, serviceId, quantity, notes);
  },
  paymentsOf(reservationId: UUID): Promise<Payment[]> {
    return reservationRepository.paymentsOf(reservationId);
  },

  async todayArrivals(hotelId: UUID, today: string): Promise<Reservation[]> {
    const all = await reservationRepository.list(hotelId);
    return all
      .filter((r) => r.checkIn === today && (r.status === 'confirmed' || r.status === 'pending'))
      .sort((a, b) => a.reference.localeCompare(b.reference));
  },

  async todayDepartures(hotelId: UUID, today: string): Promise<Reservation[]> {
    const all = await reservationRepository.list(hotelId);
    return all.filter((r) => r.checkOut === today && r.status === 'checked_in');
  },

  /** Check-in workflow: reservation → checked_in, room → occupied. */
  async checkIn(id: UUID, userId: UUID): Promise<Reservation> {
    const r = await reservationRepository.get(id);
    if (!r) throw new Error('not_found');
    if (r.status !== 'confirmed' && r.status !== 'pending') throw new Error('invalid_status');
    const updated = await reservationRepository.update(id, { status: 'checked_in' });
    await roomRepository.setStatus(r.roomId, 'occupied', userId, 'check-in');
    return updated;
  },

  /** Check-out workflow: reservation → checked_out, room → cleaning + housekeeping task. */
  async checkOut(id: UUID, userId: UUID): Promise<Reservation> {
    const r = await reservationRepository.get(id);
    if (!r) throw new Error('not_found');
    if (r.status !== 'checked_in') throw new Error('invalid_status');
    const updated = await reservationRepository.update(id, { status: 'checked_out' });
    await roomRepository.setStatus(r.roomId, 'cleaning', userId, 'check-out');
    return updated;
  },
};
