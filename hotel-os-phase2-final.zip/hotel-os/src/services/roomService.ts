import type { Room, RoomFilters, RoomStatus, RoomStatusHistory, UUID } from '@/types';
import { roomRepository } from '@/repositories';

export const roomService = {
  list(hotelId: UUID, filters?: RoomFilters): Promise<Room[]> {
    return roomRepository.list(hotelId, filters);
  },
  get(id: UUID): Promise<Room | null> {
    return roomRepository.get(id);
  },
  create(hotelId: UUID, data: Omit<Room, 'id' | 'hotelId' | 'createdAt'>): Promise<Room> {
    return roomRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<Room, 'id' | 'hotelId'>>): Promise<Room> {
    return roomRepository.update(id, patch);
  },
  setStatus(id: UUID, status: RoomStatus, changedBy: UUID | null, reason: string): Promise<Room> {
    return roomRepository.setStatus(id, status, changedBy, reason);
  },
  remove(id: UUID): Promise<void> {
    return roomRepository.remove(id);
  },
  statusHistory(roomId: UUID): Promise<RoomStatusHistory[]> {
    return roomRepository.statusHistory(roomId);
  },
};
