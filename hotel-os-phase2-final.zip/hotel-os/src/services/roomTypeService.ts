import type { RoomType, UUID } from '@/types';
import { roomTypeRepository } from '@/repositories';

export const roomTypeService = {
  list(hotelId: UUID): Promise<RoomType[]> {
    return roomTypeRepository.list(hotelId);
  },
  get(id: UUID): Promise<RoomType | null> {
    return roomTypeRepository.get(id);
  },
  create(hotelId: UUID, data: Omit<RoomType, 'id' | 'hotelId' | 'createdAt'>): Promise<RoomType> {
    return roomTypeRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<RoomType, 'id' | 'hotelId'>>): Promise<RoomType> {
    return roomTypeRepository.update(id, patch);
  },
  async toggleActive(id: UUID): Promise<RoomType> {
    const current = await roomTypeRepository.get(id);
    if (!current) throw new Error('not_found');
    return roomTypeRepository.update(id, { active: !current.active });
  },
  remove(id: UUID): Promise<void> {
    return roomTypeRepository.remove(id);
  },
};
