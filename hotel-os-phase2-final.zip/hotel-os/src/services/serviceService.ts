import type { HotelService, UUID } from '@/types';
import { serviceRepository } from '@/repositories';

export const serviceService = {
  list(hotelId: UUID): Promise<HotelService[]> {
    return serviceRepository.list(hotelId);
  },
  create(hotelId: UUID, data: Omit<HotelService, 'id' | 'hotelId' | 'createdAt'>): Promise<HotelService> {
    return serviceRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<HotelService, 'id' | 'hotelId'>>): Promise<HotelService> {
    return serviceRepository.update(id, patch);
  },
  async toggleActive(id: UUID): Promise<HotelService> {
    const s = await serviceRepository.get(id);
    if (!s) throw new Error('not_found');
    return serviceRepository.update(id, { active: !s.active });
  },
};
