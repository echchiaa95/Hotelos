import type { Profile, UUID } from '@/types';
import { userRepository } from '@/repositories';

export const userService = {
  list(hotelId: UUID): Promise<Profile[]> {
    return userRepository.list(hotelId);
  },
  getById(id: UUID): Promise<Profile | null> {
    return userRepository.getById(id);
  },
  create(hotelId: UUID, data: Omit<Profile, 'id' | 'hotelId' | 'createdAt'>): Promise<Profile> {
    return userRepository.create(hotelId, data);
  },
  update(id: UUID, patch: Partial<Omit<Profile, 'id' | 'hotelId'>>): Promise<Profile> {
    return userRepository.update(id, patch);
  },
};
