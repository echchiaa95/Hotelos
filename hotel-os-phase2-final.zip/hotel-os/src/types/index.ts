// ── HotelOS core domain types ─────────────────────────────────
// These models mirror the future Supabase schema:
// hotels, profiles, room_types, rooms, guests, reservations,
// payments, services, reservation_services, housekeeping_tasks,
// room_status_history. Hotel-specific records carry `hotelId`
// (mapped to `hotel_id` in Postgres). IDs are UUIDs.

export type UUID = string;

export type Locale = 'fr' | 'ar' | 'en';

/** Multilingual content field (stored as JSONB in Supabase). */
export interface LocalizedText {
  fr: string;
  ar: string;
  en: string;
}

// ── Enums ─────────────────────────────────────────────────────

export type RoomStatus =
  | 'available'
  | 'reserved'
  | 'occupied'
  | 'cleaning'
  | 'maintenance'
  | 'out_of_service';

export type ReservationStatus =
  | 'pending'
  | 'confirmed'
  | 'checked_in'
  | 'checked_out'
  | 'cancelled'
  | 'no_show';

export type ReservationSource =
  | 'direct'
  | 'booking_com'
  | 'expedia'
  | 'airbnb'
  | 'phone'
  | 'whatsapp'
  | 'walk_in'
  | 'other';

export type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'online' | 'other';

export type PaymentStatus = 'pending' | 'paid' | 'refunded' | 'failed' | 'cancelled';

export type Role = 'owner' | 'manager' | 'receptionist' | 'housekeeping' | 'accountant';

export type HousekeepingStatus = 'pending' | 'in_progress' | 'completed';

export type TaskType = 'cleaning' | 'maintenance' | 'inspection' | 'other';

export type BedType = 'single' | 'twin' | 'double' | 'queen' | 'king' | 'sofa';

// ── Entities ──────────────────────────────────────────────────

export interface Hotel {
  id: UUID;
  name: string;
  slug: string;
  logoUrl: string | null;
  coverUrl: string | null;
  address: string;
  city: string;
  country: string;
  phone: string;
  email: string;
  currency: string; // ISO 4217, default MAD
  timezone: string; // default Africa/Casablanca
  defaultLanguage: Locale;
  enabledLanguages: Locale[];
  checkInTime: string; // "15:00"
  checkOutTime: string; // "12:00"
  createdAt: string;
}

export interface Profile {
  id: UUID;
  hotelId: UUID;
  email: string;
  firstName: string;
  lastName: string;
  role: Role;
  active: boolean;
  avatarColor: string;
  createdAt: string;
}

export interface RoomType {
  id: UUID;
  hotelId: UUID;
  name: LocalizedText;
  description: LocalizedText;
  basePrice: number;
  maxGuests: number;
  beds: { type: BedType; count: number }[];
  size: number; // m²
  amenities: string[]; // amenity ids, translated via i18n `amenities.*`
  images: string[];
  active: boolean;
  createdAt: string;
}

export interface Room {
  id: UUID;
  hotelId: UUID;
  number: string;
  roomTypeId: UUID;
  floor: number;
  status: RoomStatus;
  notes: string;
  createdAt: string;
}

export interface Guest {
  id: UUID;
  hotelId: UUID;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  nationality: string;
  documentType: 'passport' | 'national_id' | 'driver_license' | 'other';
  documentNumber: string;
  dateOfBirth: string | null;
  notes: string;
  createdAt: string;
}

export interface Reservation {
  id: UUID;
  hotelId: UUID;
  reference: string; // e.g. "HOS-2026-AB12CD"
  guestId: UUID;
  roomId: UUID;
  checkIn: string; // ISO date
  checkOut: string; // ISO date
  adults: number;
  children: number;
  status: ReservationStatus;
  source: ReservationSource;
  totalAmount: number;
  paidAmount: number;
  currency: string;
  specialRequests: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: UUID;
  hotelId: UUID;
  reservationId: UUID;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  transactionReference: string;
  notes: string;
  paidAt: string;
  createdAt: string;
}

export interface HotelService {
  id: UUID;
  hotelId: UUID;
  name: LocalizedText;
  description: LocalizedText;
  price: number;
  active: boolean;
  createdAt: string;
}

export interface ReservationService {
  id: UUID;
  hotelId: UUID;
  reservationId: UUID;
  serviceId: UUID;
  quantity: number;
  unitPrice: number;
  notes: string;
  createdAt: string;
}

export interface HousekeepingTask {
  id: UUID;
  hotelId: UUID;
  roomId: UUID;
  assignedTo: UUID | null; // profile id
  taskType: TaskType;
  status: HousekeepingStatus;
  notes: string;
  completedAt: string | null;
  createdAt: string;
}

export interface RoomStatusHistory {
  id: UUID;
  hotelId: UUID;
  roomId: UUID;
  fromStatus: RoomStatus | null;
  toStatus: RoomStatus;
  changedBy: UUID | null;
  reason: string;
  changedAt: string;
}

// ── DTOs / query types ────────────────────────────────────────

export interface AvailabilityQuery {
  checkIn: string;
  checkOut: string;
  guests: number;
}

export interface RoomTypeAvailability {
  roomType: RoomType;
  availableRooms: Room[];
  totalPrice: number; // basePrice × nights
  nights: number;
}

export interface ReservationFilters {
  search?: string;
  status?: ReservationStatus | 'all';
  source?: ReservationSource | 'all';
  dateFrom?: string;
  dateTo?: string;
}

export interface RoomFilters {
  search?: string;
  floor?: number | 'all';
  status?: RoomStatus | 'all';
  roomTypeId?: UUID | 'all';
}

export interface DashboardStats {
  rooms: Record<RoomStatus, number>;
  todayCheckIns: number;
  todayCheckOuts: number;
  newReservations: number;
  pendingReservations: number;
  todayRevenue: number;
  monthRevenue: number;
  outstandingPayments: number;
  occupancyRate: number; // 0..100
  adr: number; // average daily rate
  revpar: number;
  currency: string;
}

export interface ReportPeriod {
  from: string;
  to: string;
  label: string;
}

// ── Async UI state ────────────────────────────────────────────

export type AsyncStatus = 'idle' | 'loading' | 'success' | 'error' | 'empty';

export interface AsyncState<T> {
  status: AsyncStatus;
  data: T | null;
  error: string | null;
}

/** Business error that maps to a translated message. */
export class HotelError extends Error {
  code: string;
  constructor(code: string) {
    super(code);
    this.code = code; // e.g. 'room_no_longer_available'
  }
}
