import type { Role } from '@/types';

/**
 * Centralised permission matrix. Never hardcode role checks in
 * components — always go through hasPermission().
 * Mirrors the future Supabase (custom claims / RLS) policy layer.
 */
export type Permission =
  | 'dashboard.view'
  | 'reservations.manage'
  | 'reservations.view'
  | 'calendar.view'
  | 'rooms.manage'
  | 'rooms.view'
  | 'room_types.manage'
  | 'guests.manage'
  | 'guests.view'
  | 'checkin.perform'
  | 'checkout.perform'
  | 'housekeeping.manage'
  | 'housekeeping.view'
  | 'payments.manage'
  | 'payments.view'
  | 'services.manage'
  | 'reports.view'
  | 'users.manage'
  | 'settings.manage'
  | 'integrations.manage';

const ALL: Permission[] = [
  'dashboard.view',
  'reservations.manage', 'reservations.view',
  'calendar.view',
  'rooms.manage', 'rooms.view',
  'room_types.manage',
  'guests.manage', 'guests.view',
  'checkin.perform', 'checkout.perform',
  'housekeeping.manage', 'housekeeping.view',
  'payments.manage', 'payments.view',
  'services.manage',
  'reports.view',
  'users.manage',
  'settings.manage',
  'integrations.manage',
];

const MATRIX: Record<Role, Permission[]> = {
  owner: ALL,
  manager: [
    'dashboard.view',
    'reservations.manage', 'reservations.view',
    'calendar.view',
    'rooms.manage', 'rooms.view',
    'room_types.manage',
    'guests.manage', 'guests.view',
    'checkin.perform', 'checkout.perform',
    'housekeeping.manage', 'housekeeping.view',
    'payments.view',
    'services.manage',
    'reports.view',
    'users.manage',
    'settings.manage',
  ],
  receptionist: [
    'dashboard.view',
    'reservations.manage', 'reservations.view',
    'calendar.view',
    'rooms.view',
    'guests.manage', 'guests.view',
    'checkin.perform', 'checkout.perform',
    'housekeeping.view',
  ],
  housekeeping: ['dashboard.view', 'rooms.view', 'housekeeping.manage', 'housekeeping.view'],
  accountant: ['dashboard.view', 'payments.manage', 'payments.view', 'reports.view'],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  return MATRIX[role]?.includes(permission) ?? false;
}

/** Routes visible per role for the sidebar. */
export const NAV_VISIBILITY: Record<string, Permission> = {
  '/app/dashboard': 'dashboard.view',
  '/app/reservations': 'reservations.view',
  '/app/calendar': 'calendar.view',
  '/app/rooms': 'rooms.view',
  '/app/room-types': 'room_types.manage',
  '/app/guests': 'guests.view',
  '/app/check-in': 'checkin.perform',
  '/app/check-out': 'checkout.perform',
  '/app/housekeeping': 'housekeeping.view',
  '/app/payments': 'payments.view',
  '/app/services': 'services.manage',
  '/app/reports': 'reports.view',
  '/app/users': 'users.manage',
  '/app/integrations': 'integrations.manage',
  '/app/settings': 'settings.manage',
};
