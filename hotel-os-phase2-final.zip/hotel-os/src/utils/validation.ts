// ── Form validation helpers ───────────────────────────────────
// Shared, translated validation for create/edit forms.
// Pattern: validate on submit, show per-field errors + summary,
// focus the first invalid field. Save is NEVER silently disabled.

export interface FieldErrors {
  [key: string]: string | undefined;
}

/** Returns an errors object; empty object means valid. */
export function validate(
  rules: { [field: string]: { valid: boolean; message: string } },
): FieldErrors {
  const errors: FieldErrors = {};
  for (const [field, rule] of Object.entries(rules)) {
    if (!rule.valid) errors[field] = rule.message;
  }
  return errors;
}

/** Focus the first field flagged invalid inside the modal. */
export function focusFirstInvalid(container: HTMLElement | null): void {
  if (!container) return;
  const el = container.querySelector<HTMLElement>('.field-error');
  if (!el) return;
  const field = el.closest('.field');
  const input = field?.querySelector<HTMLElement>('input, select, textarea');
  input?.focus();
  input?.scrollIntoView({ block: 'center', behavior: 'smooth' });
}
