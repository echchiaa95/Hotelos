-- ─────────────────────────────────────────────────────────────
-- HotelOS — create_public_booking RPC (public booking portal)
-- Run AFTER fix-42501-grants-and-policies.sql (needs hotels.is_public).
--
-- The portal NEVER inserts into guests/reservations directly: anon has
-- no table access. This SECURITY DEFINER function validates everything
-- server-side, computes the price from room_types (client prices are
-- ignored), and returns ONLY what the confirmation screen needs.
--
-- NOT executed against a live database by the author of this file.
-- Anti-abuse (CAPTCHA / rate limiting) is NOT included — add it at the
-- edge (e.g. Supabase Edge Function + Turnstile) before heavy public use.
-- ─────────────────────────────────────────────────────────────
DROP FUNCTION IF EXISTS public.create_public_booking(uuid, uuid, date, date, integer, text, text, text, text, text);

CREATE OR REPLACE FUNCTION public.create_public_booking(
  p_hotel_id         uuid,
  p_room_id          uuid,
  p_check_in         date,
  p_check_out        date,
  p_guests           integer,
  p_first_name       text,
  p_last_name        text,
  p_email            text,
  p_phone            text DEFAULT '',
  p_special_requests text DEFAULT ''
)
RETURNS jsonb
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_hotel      public.hotels%ROWTYPE;
  v_room       public.rooms%ROWTYPE;
  v_type       public.room_types%ROWTYPE;
  v_nights     integer;
  v_total      numeric;
  v_email      text;
  v_first      text := btrim(coalesce(p_first_name, ''));
  v_last       text := btrim(coalesce(p_last_name, ''));
  v_phone      text := btrim(coalesce(p_phone, ''));
  v_requests   text := btrim(coalesce(p_special_requests, ''));
  v_guest_id   uuid;
  v_ref        text;
  v_tries      integer := 0;
  v_alphabet   constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_suffix     text;
  v_i          integer;
BEGIN
  -- 1) Arguments ---------------------------------------------------
  IF p_hotel_id IS NULL OR p_room_id IS NULL OR p_check_in IS NULL
     OR p_check_out IS NULL OR p_guests IS NULL THEN
    RAISE EXCEPTION 'invalid_request: missing arguments' USING ERRCODE = '22023';
  END IF;
  v_email := lower(btrim(coalesce(p_email, '')));
  IF v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' OR length(v_email) > 254 THEN
    RAISE EXCEPTION 'invalid_request: email' USING ERRCODE = '22023';
  END IF;
  IF length(v_first) < 1 OR length(v_first) > 80 OR length(v_last) < 1 OR length(v_last) > 80 THEN
    RAISE EXCEPTION 'invalid_request: name' USING ERRCODE = '22023';
  END IF;
  IF length(v_phone) > 40 OR length(v_requests) > 1000 THEN
    RAISE EXCEPTION 'invalid_request: field too long' USING ERRCODE = '22023';
  END IF;

  -- 2) Dates / guests ----------------------------------------------
  IF p_check_out <= p_check_in THEN
    RAISE EXCEPTION 'invalid_request: check_out must be after check_in' USING ERRCODE = '22023';
  END IF;
  IF p_check_in < current_date - 1 THEN   -- 1-day tolerance for timezones
    RAISE EXCEPTION 'invalid_request: check_in in the past' USING ERRCODE = '22023';
  END IF;
  v_nights := p_check_out - p_check_in;
  IF v_nights > 90 THEN
    RAISE EXCEPTION 'invalid_request: stay too long' USING ERRCODE = '22023';
  END IF;
  IF p_guests < 1 OR p_guests > 50 THEN
    RAISE EXCEPTION 'invalid_request: guests' USING ERRCODE = '22023';
  END IF;

  -- 3) Hotel exists and is public ----------------------------------
  SELECT * INTO v_hotel FROM public.hotels h WHERE h.id = p_hotel_id AND h.is_public IS TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'invalid_request: hotel not available' USING ERRCODE = '22023';
  END IF;

  -- 4) Room belongs to the hotel (row lock serialises concurrent bookings) ─
  SELECT * INTO v_room FROM public.rooms r
    WHERE r.id = p_room_id AND r.hotel_id = p_hotel_id
    FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'invalid_request: room does not belong to this hotel' USING ERRCODE = '22023';
  END IF;

  -- 5) Room type belongs to the SAME hotel, active, capacity ok ----------
  SELECT * INTO v_type FROM public.room_types t
    WHERE t.id = v_room.room_type_id AND t.hotel_id = p_hotel_id;
  IF NOT FOUND OR v_type.active IS NOT TRUE THEN
    RAISE EXCEPTION 'invalid_request: room type not available' USING ERRCODE = '22023';
  END IF;
  IF v_type.max_guests < p_guests THEN
    RAISE EXCEPTION 'invalid_request: too many guests for this room' USING ERRCODE = '22023';
  END IF;

  -- 6) Availability + overlap (same rules as search_available_rooms) ─────
  -- Operational status allow-list — identical to search_available_rooms.sql.
  -- cleaning / maintenance / out_of_service (or any unlisted value) = not bookable.
  IF v_room.status::text NOT IN ('available', 'reserved', 'occupied') THEN
    RAISE EXCEPTION 'room_no_longer_available' USING ERRCODE = '23P01';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.reservations res
    WHERE res.room_id = v_room.id
      AND res.status IN ('pending', 'confirmed', 'checked_in')
      AND res.check_in < p_check_out
      AND res.check_out > p_check_in
  ) THEN
    RAISE EXCEPTION 'room_no_longer_available' USING ERRCODE = '23P01';
  END IF;

  -- 7) Price is computed here, never trusted from the client ──────────────
  v_total := v_type.base_price * v_nights;

  -- 8) Guest: reuse an existing guest of THIS hotel with the same e-mail,
  --    never overwrite its data; otherwise create a minimal one.
  SELECT g.id INTO v_guest_id FROM public.guests g
    WHERE g.hotel_id = p_hotel_id AND lower(g.email) = v_email
    ORDER BY g.created_at LIMIT 1;
  IF v_guest_id IS NULL THEN
    INSERT INTO public.guests
      (hotel_id, first_name, last_name, email, phone, nationality,
       document_type, document_number, date_of_birth, notes)
    VALUES
      (p_hotel_id, v_first, v_last, v_email, v_phone, '',
       'passport', '', NULL, 'Portal booking')
    RETURNING id INTO v_guest_id;
  END IF;

  -- 9) Booking reference: HOS-<year>-<6 chars>, retried on collision ──────
  LOOP
    v_suffix := '';
    FOR v_i IN 1..6 LOOP
      v_suffix := v_suffix || substr(v_alphabet, 1 + floor(random() * length(v_alphabet))::int, 1);
    END LOOP;
    v_ref := 'HOS-' || to_char(now(), 'YYYY') || '-' || v_suffix;
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.reservations x WHERE x.booking_reference = v_ref);
    v_tries := v_tries + 1;
    IF v_tries > 10 THEN
      RAISE EXCEPTION 'could not generate a booking reference' USING ERRCODE = '55000';
    END IF;
  END LOOP;

  -- 10) Reservation (the exclusion constraint, if present, is a 2nd barrier) ─
  INSERT INTO public.reservations
    (hotel_id, booking_reference, guest_id, room_id, check_in, check_out,
     adults, children, status, source, total_amount, paid_amount, currency, special_requests)
  VALUES
    (p_hotel_id, v_ref, v_guest_id, v_room.id, p_check_in, p_check_out,
     p_guests, 0, 'pending', 'direct', v_total, 0,
     coalesce(nullif(v_hotel.currency, ''), 'MAD'), v_requests);

  -- 11) Return ONLY what the confirmation screen needs ──────────────────
  RETURN jsonb_build_object(
    'booking_reference', v_ref,
    'status',            'pending',
    'check_in',          p_check_in,
    'check_out',         p_check_out,
    'nights',            v_nights,
    'total_amount',      v_total,
    'currency',          coalesce(nullif(v_hotel.currency, ''), 'MAD'),
    'room_type_name',    v_type.name
  );
END;
$$;

REVOKE ALL ON FUNCTION public.create_public_booking(uuid, uuid, date, date, integer, text, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_public_booking(uuid, uuid, date, date, integer, text, text, text, text, text)
  TO anon, authenticated;
