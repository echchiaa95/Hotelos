-- ─────────────────────────────────────────────────────────────
-- HotelOS — Phase 2 FINAL: grants + RLS + cross-hotel integrity
-- Run in: Supabase Dashboard → SQL Editor (one transaction).
-- Order: 1) this file  2) search_available_rooms.sql  3) create_public_booking.sql
--
-- Authorization = GRANT + RLS (+ triggers). A GRANT alone is never
-- treated as authorization.
--
-- NOT verified against the live DB by the author of this file
-- (no DB access). Assumed columns: hotel_id on every table below,
-- profiles(id, hotel_id, email, first_name, last_name, role, ...),
-- rooms.room_number. Run the verification queries at the bottom.
--
-- This script DROPS every existing policy on the listed tables and
-- recreates exact ones (permissive policies are OR-ed, so a stale
-- "USING (true)" policy would silently defeat the scoping).
-- It does NOT touch row data. Idempotent.
-- ─────────────────────────────────────────────────────────────
BEGIN;

-- 0) Columns the app already reads/writes (added only if missing) ─
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_color text;
-- Public-portal switch (default true = current behaviour preserved).
ALTER TABLE public.hotels   ADD COLUMN IF NOT EXISTS is_public boolean NOT NULL DEFAULT true;

-- 1) Helpers ─────────────────────────────────────────────────
-- SECURITY DEFINER so policies on profiles can resolve the caller's
-- hotel without recursing into profiles' own RLS.
CREATE OR REPLACE FUNCTION public.current_hotel_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.hotel_id FROM public.profiles p WHERE p.id = auth.uid() AND p.active IS TRUE
$$;

CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.role::text FROM public.profiles p WHERE p.id = auth.uid() AND p.active IS TRUE
$$;

REVOKE ALL ON FUNCTION public.current_hotel_id()  FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.current_user_role() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.current_hotel_id()  TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_user_role() TO authenticated;

-- 2) Grants: start from zero, then grant exactly what is needed ─
GRANT USAGE ON SCHEMA public TO anon, authenticated;

REVOKE ALL ON public.rooms, public.room_types, public.guests, public.reservations,
              public.payments, public.services, public.reservation_services,
              public.housekeeping_tasks, public.room_status_history,
              public.profiles, public.hotels
  FROM anon, authenticated;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.rooms                TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.room_types           TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.guests               TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservations         TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.payments             TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.services             TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservation_services TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.housekeeping_tasks   TO authenticated;
-- history is append-only from the client (room status changes)
GRANT SELECT, INSERT                 ON public.room_status_history  TO authenticated;
GRANT SELECT                         ON public.hotels               TO authenticated;
GRANT SELECT                         ON public.profiles             TO authenticated;
-- column-level: hotel_id and id can never be updated by clients
GRANT UPDATE (first_name, last_name, avatar_color, email, role, active)
  ON public.profiles TO authenticated;
-- anon: NOTHING on tables. Public portal uses the RPCs in section 7.

-- 3) Drop ALL existing policies on these tables ──────────────
DO $$
DECLARE pol record;
BEGIN
  FOR pol IN
    SELECT schemaname, tablename, policyname FROM pg_policies
    WHERE schemaname = 'public' AND tablename IN
      ('rooms','room_types','guests','reservations','payments','services',
       'reservation_services','housekeeping_tasks','room_status_history',
       'profiles','hotels')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', pol.policyname, pol.schemaname, pol.tablename);
  END LOOP;
END $$;

-- 4) Hotel-scoped tables: RLS ON + exact scoping ─────────────
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['rooms','room_types','guests','reservations','payments',
                           'services','reservation_services','housekeeping_tasks']
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($f$
      CREATE POLICY %I ON public.%I FOR ALL TO authenticated
        USING      (hotel_id = (SELECT public.current_hotel_id()))
        WITH CHECK (hotel_id = (SELECT public.current_hotel_id()))
    $f$, t || '_hotel_scope', t);
  END LOOP;
END $$;

-- room_status_history: read own hotel; insert own hotel, attributed to self
ALTER TABLE public.room_status_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY room_status_history_select ON public.room_status_history
  FOR SELECT TO authenticated
  USING (hotel_id = (SELECT public.current_hotel_id()));
CREATE POLICY room_status_history_insert ON public.room_status_history
  FOR INSERT TO authenticated
  WITH CHECK (hotel_id = (SELECT public.current_hotel_id())
              AND (changed_by IS NULL OR changed_by = auth.uid()));

-- 5) hotels: authenticated read own hotel only; anon has no access ─
ALTER TABLE public.hotels ENABLE ROW LEVEL SECURITY;
CREATE POLICY hotels_select_own ON public.hotels
  FOR SELECT TO authenticated
  USING (id = (SELECT public.current_hotel_id()));

-- 6) profiles ────────────────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
-- colleagues of the same hotel (Users page, housekeeping assignment)
CREATE POLICY profiles_select_same_hotel ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR hotel_id = (SELECT public.current_hotel_id()));
-- own row (safe columns only — enforced by trigger below)
CREATE POLICY profiles_update_self ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid() AND hotel_id = (SELECT public.current_hotel_id()));
-- owner/manager may manage colleagues of the SAME hotel
CREATE POLICY profiles_update_by_manager ON public.profiles
  FOR UPDATE TO authenticated
  USING (hotel_id = (SELECT public.current_hotel_id())
         AND (SELECT public.current_user_role()) IN ('owner','manager'))
  WITH CHECK (hotel_id = (SELECT public.current_hotel_id()));
-- No INSERT/DELETE policy and no grant: clients cannot create or delete
-- profiles (create via Supabase Auth + server-side / dashboard).

CREATE OR REPLACE FUNCTION public.protect_profile_columns()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE caller_role text;
BEGIN
  -- SQL editor / service_role (no JWT user) are trusted
  IF auth.uid() IS NULL THEN RETURN NEW; END IF;

  IF NEW.id IS DISTINCT FROM OLD.id OR NEW.hotel_id IS DISTINCT FROM OLD.hotel_id THEN
    RAISE EXCEPTION 'profile id/hotel_id are immutable' USING ERRCODE = '42501';
  END IF;

  IF NEW.role::text IS DISTINCT FROM OLD.role::text
     OR NEW.active  IS DISTINCT FROM OLD.active
     OR NEW.email   IS DISTINCT FROM OLD.email THEN
    caller_role := public.current_user_role();
    IF caller_role IS NULL OR caller_role NOT IN ('owner','manager') THEN
      RAISE EXCEPTION 'not allowed to change role/active/email' USING ERRCODE = '42501';
    END IF;
    IF OLD.id = auth.uid() AND (NEW.role::text IS DISTINCT FROM OLD.role::text
                                OR NEW.active IS DISTINCT FROM OLD.active) THEN
      RAISE EXCEPTION 'cannot change your own role/active status' USING ERRCODE = '42501';
    END IF;
    -- only an owner may grant owner or modify an owner
    IF caller_role <> 'owner'
       AND (NEW.role::text = 'owner' OR OLD.role::text = 'owner') THEN
      RAISE EXCEPTION 'only an owner can grant or modify the owner role' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.protect_profile_columns() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS trg_protect_profile_columns ON public.profiles;
CREATE TRIGGER trg_protect_profile_columns
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.protect_profile_columns();

-- 7) Public booking portal: controlled RPC instead of table access ─
CREATE OR REPLACE FUNCTION public.get_public_hotel_by_slug(p_slug text)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'id', h.id, 'name', h.name, 'slug', h.slug,
    'logo_url', h.logo_url, 'cover_url', h.cover_url,
    'address', h.address, 'city', h.city, 'country', h.country,
    'phone', h.phone, 'email', h.email,
    'currency', h.currency, 'timezone', h.timezone,
    'default_language', h.default_language, 'enabled_languages', h.enabled_languages,
    'check_in_time', h.check_in_time, 'check_out_time', h.check_out_time)
  FROM public.hotels h
  WHERE h.slug = p_slug AND h.is_public IS TRUE
  LIMIT 1
$$;
REVOKE ALL ON FUNCTION public.get_public_hotel_by_slug(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_hotel_by_slug(text) TO anon, authenticated;

-- 8) Cross-hotel integrity triggers ──────────────────────────
-- RLS on hotel_id alone cannot stop a row of hotel A from POINTING at a
-- record of hotel B. These BEFORE INSERT/UPDATE triggers (SECURITY
-- DEFINER, so they see other hotels' rows) reject such references.
CREATE OR REPLACE FUNCTION public._assert_same_hotel(p_tbl regclass, p_id uuid, p_hotel uuid, p_label text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE ok boolean;
BEGIN
  IF p_id IS NULL THEN RETURN; END IF;
  EXECUTE format('SELECT EXISTS (SELECT 1 FROM %s WHERE id = $1 AND hotel_id = $2)', p_tbl)
    INTO ok USING p_id, p_hotel;
  IF NOT ok THEN
    RAISE EXCEPTION 'cross_hotel_reference: % does not belong to this hotel', p_label
      USING ERRCODE = '23514';
  END IF;
END $$;
REVOKE ALL ON FUNCTION public._assert_same_hotel(regclass, uuid, uuid, text) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.trg_rooms_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.room_types', NEW.room_type_id, NEW.hotel_id, 'room_type_id');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.trg_reservations_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.rooms',  NEW.room_id,  NEW.hotel_id, 'room_id');
  PERFORM public._assert_same_hotel('public.guests', NEW.guest_id, NEW.hotel_id, 'guest_id');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.trg_reservation_services_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.reservations', NEW.reservation_id, NEW.hotel_id, 'reservation_id');
  PERFORM public._assert_same_hotel('public.services',     NEW.service_id,     NEW.hotel_id, 'service_id');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.trg_payments_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.reservations', NEW.reservation_id, NEW.hotel_id, 'reservation_id');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.trg_housekeeping_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.rooms',    NEW.room_id,     NEW.hotel_id, 'room_id');
  PERFORM public._assert_same_hotel('public.profiles', NEW.assigned_to, NEW.hotel_id, 'assigned_to');
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.trg_room_status_history_same_hotel() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public._assert_same_hotel('public.rooms', NEW.room_id, NEW.hotel_id, 'room_id');
  RETURN NEW;
END $$;

REVOKE ALL ON FUNCTION public.trg_rooms_same_hotel(), public.trg_reservations_same_hotel(),
  public.trg_reservation_services_same_hotel(), public.trg_payments_same_hotel(),
  public.trg_housekeeping_same_hotel(), public.trg_room_status_history_same_hotel()
  FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_same_hotel ON public.rooms;
CREATE TRIGGER trg_same_hotel BEFORE INSERT OR UPDATE ON public.rooms
  FOR EACH ROW EXECUTE FUNCTION public.trg_rooms_same_hotel();
DROP TRIGGER IF EXISTS trg_same_hotel ON public.reservations;
CREATE TRIGGER trg_same_hotel BEFORE INSERT OR UPDATE ON public.reservations
  FOR EACH ROW EXECUTE FUNCTION public.trg_reservations_same_hotel();
DROP TRIGGER IF EXISTS trg_same_hotel ON public.reservation_services;
CREATE TRIGGER trg_same_hotel BEFORE INSERT OR UPDATE ON public.reservation_services
  FOR EACH ROW EXECUTE FUNCTION public.trg_reservation_services_same_hotel();
DROP TRIGGER IF EXISTS trg_same_hotel ON public.payments;
CREATE TRIGGER trg_same_hotel BEFORE INSERT OR UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION public.trg_payments_same_hotel();
DROP TRIGGER IF EXISTS trg_same_hotel ON public.housekeeping_tasks;
CREATE TRIGGER trg_same_hotel BEFORE INSERT OR UPDATE ON public.housekeeping_tasks
  FOR EACH ROW EXECUTE FUNCTION public.trg_housekeeping_same_hotel();
DROP TRIGGER IF EXISTS trg_same_hotel ON public.room_status_history;
CREATE TRIGGER trg_same_hotel BEFORE INSERT ON public.room_status_history
  FOR EACH ROW EXECUTE FUNCTION public.trg_room_status_history_same_hotel();

-- 8b) Hotel settings: controlled RPC (no UPDATE grant on hotels) ─
-- Caller must be an active owner/manager. The target hotel is ALWAYS
-- current_hotel_id() — the client cannot choose it, and id / is_public
-- / created_at are not updatable through this function.
CREATE OR REPLACE FUNCTION public.update_hotel_settings(p_settings jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_hotel   uuid := public.current_hotel_id();
  v_role    text := public.current_user_role();
  k         text;
  v         text;
  allowed   text[] := ARRAY['name','slug','logo_url','cover_url','address','city','country',
                            'phone','email','currency','timezone','default_language',
                            'enabled_languages','check_in_time','check_out_time'];
  v_cur_def text;
  v_cur_langs jsonb;
  v_def     text;
  v_langs   jsonb;
  v_coltype text;
  v_result  jsonb;
BEGIN
  IF auth.uid() IS NULL OR v_hotel IS NULL THEN
    RAISE EXCEPTION 'not authenticated' USING ERRCODE = '42501';
  END IF;
  IF v_role IS NULL OR v_role NOT IN ('owner','manager') THEN
    RAISE EXCEPTION 'only owner/manager can update hotel settings' USING ERRCODE = '42501';
  END IF;
  IF p_settings IS NULL OR jsonb_typeof(p_settings) <> 'object' THEN
    RAISE EXCEPTION 'invalid_request: settings must be an object' USING ERRCODE = '22023';
  END IF;

  FOR k IN SELECT jsonb_object_keys(p_settings) LOOP
    IF NOT (k = ANY (allowed)) THEN
      RAISE EXCEPTION 'invalid_request: field "%" is not updatable', k USING ERRCODE = '22023';
    END IF;
  END LOOP;

  -- scalar validation (only for keys that are present)
  IF p_settings ? 'name' THEN
    v := btrim(coalesce(p_settings->>'name',''));
    IF length(v) < 1 OR length(v) > 120 THEN
      RAISE EXCEPTION 'invalid_request: name' USING ERRCODE = '22023';
    END IF;
  END IF;
  IF p_settings ? 'slug' THEN
    v := coalesce(p_settings->>'slug','');
    IF v !~ '^[a-z0-9]+(-[a-z0-9]+)*$' OR length(v) < 3 OR length(v) > 60 THEN
      RAISE EXCEPTION 'invalid_request: slug' USING ERRCODE = '22023';
    END IF;
    IF EXISTS (SELECT 1 FROM public.hotels h WHERE h.slug = v AND h.id <> v_hotel) THEN
      RAISE EXCEPTION 'slug already in use' USING ERRCODE = '23505';
    END IF;
  END IF;
  FOREACH k IN ARRAY ARRAY['address','city','country','phone'] LOOP
    IF p_settings ? k AND length(coalesce(p_settings->>k,'')) > 200 THEN
      RAISE EXCEPTION 'invalid_request: %', k USING ERRCODE = '22023';
    END IF;
  END LOOP;
  IF p_settings ? 'email' THEN
    v := coalesce(p_settings->>'email','');
    IF v <> '' AND (v !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' OR length(v) > 254) THEN
      RAISE EXCEPTION 'invalid_request: email' USING ERRCODE = '22023';
    END IF;
  END IF;
  IF p_settings ? 'currency' AND coalesce(p_settings->>'currency','') !~ '^[A-Z]{3}$' THEN
    RAISE EXCEPTION 'invalid_request: currency' USING ERRCODE = '22023';
  END IF;
  IF p_settings ? 'timezone' AND NOT EXISTS (
       SELECT 1 FROM pg_timezone_names z WHERE z.name = coalesce(p_settings->>'timezone','')) THEN
    RAISE EXCEPTION 'invalid_request: timezone' USING ERRCODE = '22023';
  END IF;
  FOREACH k IN ARRAY ARRAY['check_in_time','check_out_time'] LOOP
    IF p_settings ? k AND coalesce(p_settings->>k,'') !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' THEN
      RAISE EXCEPTION 'invalid_request: %', k USING ERRCODE = '22023';
    END IF;
  END LOOP;
  FOREACH k IN ARRAY ARRAY['logo_url','cover_url'] LOOP
    IF p_settings ? k THEN
      v := coalesce(p_settings->>k,'');
      IF v <> '' AND (v !~* '^https://[^\s]+$' OR length(v) > 2048) THEN
        RAISE EXCEPTION 'invalid_request: % must be an https URL', k USING ERRCODE = '22023';
      END IF;
    END IF;
  END LOOP;

  -- language pair validation
  IF p_settings ? 'default_language' OR p_settings ? 'enabled_languages' THEN
    SELECT h.default_language::text, to_jsonb(h.enabled_languages)
      INTO v_cur_def, v_cur_langs FROM public.hotels h WHERE h.id = v_hotel;
    v_def   := CASE WHEN p_settings ? 'default_language' THEN p_settings->>'default_language' ELSE v_cur_def END;
    v_langs := CASE WHEN p_settings ? 'enabled_languages' THEN p_settings->'enabled_languages' ELSE v_cur_langs END;
    IF v_def IS NULL OR v_def NOT IN ('fr','ar','en') THEN
      RAISE EXCEPTION 'invalid_request: default_language' USING ERRCODE = '22023';
    END IF;
    IF p_settings ? 'enabled_languages' THEN
      IF v_langs IS NULL OR jsonb_typeof(v_langs) <> 'array' OR jsonb_array_length(v_langs) = 0
         OR EXISTS (SELECT 1 FROM jsonb_array_elements(v_langs) e
                    WHERE jsonb_typeof(e) <> 'string' OR (e #>> '{}') NOT IN ('fr','ar','en')) THEN
        RAISE EXCEPTION 'invalid_request: enabled_languages' USING ERRCODE = '22023';
      END IF;
    END IF;
    IF v_langs IS NOT NULL AND jsonb_typeof(v_langs) = 'array' AND NOT (v_langs ? v_def) THEN
      RAISE EXCEPTION 'invalid_request: default language must be enabled' USING ERRCODE = '22023';
    END IF;
  END IF;

  UPDATE public.hotels h SET
    name             = CASE WHEN p_settings ? 'name'             THEN btrim(p_settings->>'name')              ELSE h.name END,
    slug             = CASE WHEN p_settings ? 'slug'             THEN p_settings->>'slug'                     ELSE h.slug END,
    logo_url         = CASE WHEN p_settings ? 'logo_url'         THEN NULLIF(p_settings->>'logo_url','')      ELSE h.logo_url END,
    cover_url        = CASE WHEN p_settings ? 'cover_url'        THEN NULLIF(p_settings->>'cover_url','')     ELSE h.cover_url END,
    address          = CASE WHEN p_settings ? 'address'          THEN coalesce(p_settings->>'address','')     ELSE h.address END,
    city             = CASE WHEN p_settings ? 'city'             THEN coalesce(p_settings->>'city','')        ELSE h.city END,
    country          = CASE WHEN p_settings ? 'country'          THEN coalesce(p_settings->>'country','')     ELSE h.country END,
    phone            = CASE WHEN p_settings ? 'phone'            THEN coalesce(p_settings->>'phone','')       ELSE h.phone END,
    email            = CASE WHEN p_settings ? 'email'            THEN coalesce(p_settings->>'email','')       ELSE h.email END,
    currency         = CASE WHEN p_settings ? 'currency'         THEN p_settings->>'currency'                 ELSE h.currency END,
    timezone         = CASE WHEN p_settings ? 'timezone'         THEN p_settings->>'timezone'                 ELSE h.timezone END,
    default_language = CASE WHEN p_settings ? 'default_language' THEN p_settings->>'default_language'         ELSE h.default_language END,
    check_in_time    = CASE WHEN p_settings ? 'check_in_time'    THEN p_settings->>'check_in_time'            ELSE h.check_in_time END,
    check_out_time   = CASE WHEN p_settings ? 'check_out_time'   THEN p_settings->>'check_out_time'           ELSE h.check_out_time END
  WHERE h.id = v_hotel;

  -- enabled_languages may be jsonb or text[] in the live schema
  IF p_settings ? 'enabled_languages' THEN
    SELECT c.data_type INTO v_coltype FROM information_schema.columns c
      WHERE c.table_schema = 'public' AND c.table_name = 'hotels' AND c.column_name = 'enabled_languages';
    IF v_coltype = 'ARRAY' THEN
      UPDATE public.hotels SET enabled_languages = ARRAY(SELECT jsonb_array_elements_text(p_settings->'enabled_languages'))
        WHERE id = v_hotel;
    ELSE
      UPDATE public.hotels SET enabled_languages = p_settings->'enabled_languages' WHERE id = v_hotel;
    END IF;
  END IF;

  SELECT to_jsonb(h) INTO v_result FROM public.hotels h WHERE h.id = v_hotel;
  RETURN v_result;
END $$;
REVOKE ALL ON FUNCTION public.update_hotel_settings(jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.update_hotel_settings(jsonb) TO authenticated;

-- 9) Self-check: abort the whole transaction if RLS or policies are missing ─
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['rooms','room_types','guests','reservations','payments','services',
    'reservation_services','housekeeping_tasks','room_status_history','profiles','hotels']
  LOOP
    IF NOT (SELECT relrowsecurity FROM pg_class WHERE oid = ('public.'||t)::regclass) THEN
      RAISE EXCEPTION 'RLS is not enabled on public.%', t;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename=t) THEN
      RAISE EXCEPTION 'No RLS policy exists on public.%', t;
    END IF;
  END LOOP;
END $$;

COMMIT;

-- ── Verification (run manually after the script) ─────────────
-- select tablename, policyname, cmd, roles, qual, with_check
--   from pg_policies where schemaname='public' order by 1,2;
-- select relname, relrowsecurity from pg_class
--   where relnamespace='public'::regnamespace and relkind='r' order by 1;
-- select grantee, table_name, privilege_type from information_schema.role_table_grants
--   where table_schema='public' and grantee in ('anon','authenticated') order by 2,1,3;
-- -- anon must return 'permission denied' on every PMS table:
-- --   set role anon; select * from rooms limit 1; reset role;
