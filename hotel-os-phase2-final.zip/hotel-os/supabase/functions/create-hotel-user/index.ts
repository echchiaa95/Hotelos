// Supabase Edge Function: create-hotel-user  (Deno runtime)
//
// Creates a staff member for the CALLER'S hotel: invites a new Auth user
// by e-mail (no password is ever set or returned) and creates the
// matching profile row.
//
// Security model
//  - The caller must send a valid user JWT (verified via auth.getUser).
//  - The caller's profile (hotel_id, role, active) is read server-side;
//    only an ACTIVE owner/manager may proceed.
//  - hotel_id is NEVER taken from the request: it is the caller's hotel.
//    If the body contains a hotelId that differs, the request is rejected.
//  - Only an owner can create an owner.
//  - If the e-mail already has an Auth user, the request is rejected
//    (no profile is ever attached to someone else's account / hotel).
//  - SUPABASE_SERVICE_ROLE_KEY exists only inside this function's
//    environment (injected by Supabase). It is never sent to the browser.
//
// Deploy:  supabase functions deploy create-hotel-user
//   (or paste into Dashboard → Edge Functions → New function)
// Keep "Verify JWT" ON.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const ROLES = ['owner', 'manager', 'receptionist', 'housekeeping', 'accountant'] as const;
type Role = (typeof ROLES)[number];

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json(405, { error: 'method_not_allowed' });

  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return json(500, { error: 'server_misconfigured' });

  // 1) Authenticate the caller ------------------------------------------
  const authHeader = req.headers.get('Authorization') ?? '';
  if (!authHeader.startsWith('Bearer ')) return json(401, { error: 'unauthorized' });

  const userClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false },
  });
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) return json(401, { error: 'unauthorized' });
  const callerId = userData.user.id;

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });

  // 2) Authorize: active owner/manager of a hotel -------------------------
  const { data: caller, error: callerErr } = await admin
    .from('profiles')
    .select('hotel_id, role, active')
    .eq('id', callerId)
    .maybeSingle();
  if (callerErr || !caller || caller.active !== true || !caller.hotel_id) {
    return json(403, { error: 'forbidden' });
  }
  if (caller.role !== 'owner' && caller.role !== 'manager') {
    return json(403, { error: 'forbidden' });
  }

  // 3) Validate input -----------------------------------------------------
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json(400, { error: 'invalid_request' });
  }
  const email = String(body.email ?? '').trim().toLowerCase();
  const firstName = String(body.firstName ?? '').trim();
  const lastName = String(body.lastName ?? '').trim();
  const role = String(body.role ?? '') as Role;
  const avatarColor = body.avatarColor ? String(body.avatarColor).slice(0, 16) : null;

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 254) return json(400, { error: 'invalid_request' });
  if (firstName.length < 1 || firstName.length > 80 || lastName.length > 80) return json(400, { error: 'invalid_request' });
  if (!ROLES.includes(role)) return json(400, { error: 'invalid_request' });

  // never trust a client-supplied hotel
  if (body.hotelId !== undefined && body.hotelId !== null && body.hotelId !== caller.hotel_id) {
    return json(403, { error: 'forbidden' });
  }
  // only an owner can create an owner
  if (role === 'owner' && caller.role !== 'owner') return json(403, { error: 'forbidden' });

  // 4) Refuse if an Auth user with this e-mail already exists -------------
  const { data: existing } = await admin.from('profiles').select('id').ilike('email', email).maybeSingle();
  if (existing) return json(409, { error: 'conflict' });

  // 5) Invite the Auth user (e-mail with a set-password link) -------------
  const redirectTo = typeof body.redirectTo === 'string' ? body.redirectTo : undefined;
  const { data: invited, error: inviteErr } = await admin.auth.admin.inviteUserByEmail(email, {
    data: { first_name: firstName, last_name: lastName },
    redirectTo,
  });
  if (inviteErr || !invited?.user) {
    const msg = String(inviteErr?.message ?? '');
    if (/already|registered|exists/i.test(msg)) return json(409, { error: 'conflict' });
    return json(502, { error: 'invite_failed' });
  }
  const newUser = invited.user;

  // 6) Create the profile for the caller's hotel (upsert: a DB trigger may
  //    already have created a bare profile for the new Auth user) --------
  const { data: profile, error: profileErr } = await admin
    .from('profiles')
    .upsert(
      {
        id: newUser.id,
        hotel_id: caller.hotel_id,
        email,
        first_name: firstName,
        last_name: lastName,
        role,
        active: true,
        avatar_color: avatarColor,
      },
      { onConflict: 'id' },
    )
    .select()
    .single();

  if (profileErr || !profile) {
    // roll back the Auth user we just created so no orphan remains
    await admin.auth.admin.deleteUser(newUser.id);
    return json(500, { error: 'profile_failed' });
  }

  return json(200, { profile });
});
